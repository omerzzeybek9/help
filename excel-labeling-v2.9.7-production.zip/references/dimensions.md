# Labeling Dimensions / Targets

## Why this exists
A single source row can be labeled from several independent angles. “Topic” and “sentiment” are not competing labels; they are separate targets and should produce separate output columns.

## When to ask
If the user gives only a generic request such as “bunu etiketle”, “classify this Excel”, or “yorumları kategorize et”, do not assume the desired target.

Inspect the likely source data first, then propose a few data-relevant options through `ask_user_question`.

## Suggest data-relevant targets
Examples only — do not force these everywhere:

Customer comments:
- topic/theme
- sentiment
- customer intent
- urgency
- resolution status

Service/ticket data:
- request type
- root cause
- priority
- responsible unit
- status/reason

Operational records:
- event type
- risk class
- exception reason
- process stage

Documents/notes:
- document type
- subject
- action required
- sensitivity/handling class if the user asks and policy permits

## Multiple targets
Create one independent target per chosen dimension. Each target has its own:
- purpose;
- source columns;
- context columns;
- output column;
- internal label-source path names;
- single/multi setting;
- labels/rules.

Apply the user’s shared choice to all chosen targets. Use different choices only when the user requests them; do not introduce an unsolicited per-target questionnaire.

## Avoid over-suggesting
Offer only a small number of useful options. Do not turn a simple job into an analytics workshop.
