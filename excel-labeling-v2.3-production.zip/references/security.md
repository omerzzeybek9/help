# Enterprise Data and Research Boundaries

## Default
Keep row-level business/customer data inside the available enterprise processing environment.
Do not use external research for routine label discovery or validation.

## If research is explicitly requested
Research only the unresolved terminology/schema/business concept necessary for the target.
Do not send or quote customer rows, account data, identifiers, confidential notes, or bulk source content to external web/research tools.

Prefer researching abstract questions such as:
- what a domain term means;
- how an external standard defines a category;
- how a public product/process is named.

Tell the user before performing the requested research.

## Logs and outputs
Do not add debug metadata, hashes, internal IDs, or full source excerpts to the exported workbook unless explicitly requested and appropriate.
