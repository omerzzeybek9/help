# Interaction and UX

## User experience goal
A branch/office user should feel they are making business decisions, not configuring an AI system.

Ideal experience:
1. “Bu veriyi hangi açıdan etiketlemek istiyorum?”
2. “Bu etiketler/kurallar uygun mu?”
3. “Bu örnek sonuçlar doğru mu?”
4. “Dosyam hazır.”

## Mandatory MCP gates
Use the real `ask_user_question` MCP tool for required decisions. Never substitute ordinary prose.

Required when not already explicit:
- ambiguous sheet;
- labeling target/dimension for generic requests;
- source/context columns when genuinely ambiguous;
- single vs multi for each target;
- setup approval;
- preview approval;
- business-rule change after a failed preview/QA;
- material free-form consolidation change;
- reusable prompt offer.

If MCP is unavailable at a required gate, stop at that gate rather than inventing approval.

## Ask fewer, better questions
Combine compatible choices when the MCP schema supports it. Do not ask one question per config field.

For one-vs-multiple labeling, recommend a sensible choice per target and ask for confirmation instead of asking an abstract configuration question. Example:
- `Konu/Tema: bir satırda birden fazla konu olabilir`
- `Duygu: her satır için tek duygu etiketi`
- `Bu yapı uygun mu?`

The user must still confirm the one/multiple behavior required by the workflow. Do not infer it silently.

Prefer plain language. Avoid user-facing terms such as taxonomy, cardinality, batch, chunk, token, lease, hash, queue, schema, JSON, audit threshold, or state machine.

## Skip redundant questions
If the user already specified source column, target, labels, and one/multiple behavior, do not ask again. Still require preview approval.

## Do not narrate internals
During full labeling do not tell the user:
- how many internal work items were fetched;
- that a JSON payload is being generated;
- that target queues are being drained;
- chunk/batch sizes;
- lease/hash details;
- repeated submit-loop progress.

Internal QA and repair should also stay silent unless they reveal a business-rule problem that requires user input.

## Fast default
If the user supplies no labels and does not request free-form, default to data-proposed labels (Path B) and show that in setup approval.
