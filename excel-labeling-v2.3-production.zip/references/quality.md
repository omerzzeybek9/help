# Quality Gates

## Before setup approval: coverage audit
For Path B, test proposed labels on a second varied sample that differs from discovery data.
Check recurring uncovered meanings, overlap, vague boundaries, rare-word overfitting, and cross-target redundancy.
Do this internally without making the user manage the iteration.

When multiple targets coexist, optimize them together. Topic labels should describe *what the record is about*; Sentiment labels should describe *how it is evaluated/felt*. Avoid a Topic vocabulary that merely repeats Sentiment.

## Preview quality
Preview should challenge the setup, not flatter it. Prefer a mix of:
- ordinary rows;
- boundary cases;
- multi-label-looking rows;
- irony/negation-like language where present;
- long/complex rows;
- semantically different themes.

Prefer the same source rows across selected targets so the user can see Topic + Sentiment + other dimensions side by side.

Approved preview results become semantic exemplars for later work and are forced into the independent audit sample.

If a rejected preview requires a rule/taxonomy/cardinality/source change, the current runtime job is stale. Start a fresh job after revised setup approval rather than mutating committed preview results in place.

## Structural validation is necessary but insufficient
Row counts, allowed labels, cardinality, file hashes and output integrity can all pass while labels are semantically wrong.
Therefore fixed-taxonomy jobs require an independent semantic audit before export.

## Pre-audit triage
Run `quality-report` after full labeling. A `TAXONOMY_GAP` means the business label set is incomplete, not that the row needs manual review. Revise the approved setup through MCP and start a fresh job before auditing. Investigate unexpectedly high REVIEW before audit as well.

## Independent semantic audit
Use:

```bash
python scripts/excel_labeling.py audit-start --job-dir JOB --count 60
python scripts/excel_labeling.py audit-next --job-dir JOB
python scripts/excel_labeling.py audit-submit --job-dir JOB --stdin
python scripts/excel_labeling.py audit-results --job-dir JOB
python scripts/excel_labeling.py audit-finalize --job-dir JOB
```

The audit classifier receives source content and target rules but not the existing production label. This reduces anchoring and catches orchestration drift.

Audit sampling deliberately covers the full row timeline, gives extra weight to later rows, includes long rows when present, and reports mismatch rates both overall and by target. A plausible aggregate label distribution is not evidence that row-level semantics are correct.

The mismatch threshold is a guardrail, not a claim of true model accuracy. If the audit is noisy because the business rule itself is ambiguous, fix the rule rather than simply relaxing the threshold.

## Repair
If audit fails:

```bash
python scripts/excel_labeling.py repair-start --job-dir JOB
python scripts/excel_labeling.py repair-next --job-dir JOB
python scripts/excel_labeling.py repair-submit --job-dir JOB --stdin
python scripts/excel_labeling.py repair-finalize --job-dir JOB
```

A failed audit can indicate drift beyond sampled rows. The runtime may therefore queue a broader affected scope from the earliest mismatch onward.

Repair shows source, production label, and independent audit label. Adjudicate from meaning and approved rules; do not blindly prefer either candidate.

Repair resets the audit. Rerun a fresh audit afterward.

If mismatches reveal that the approved business taxonomy itself is wrong or incomplete, do not silently change it. Ask the user through MCP, revise setup, and re-preview.

## REVIEW discipline
`REVIEW` means the row itself is genuinely unresolved. It is not “no keyword match”, “low confidence”, or “no obvious label”.

If REVIEW is unexpectedly high:
1. inspect problem samples;
2. distinguish true ambiguity from taxonomy gaps or weak rules;
3. repair the setup when possible;
4. only if ambiguity is genuinely inherent, explain it briefly and ask the user whether to accept those REVIEW rows.

The runtime blocks unusually high REVIEW unless explicitly acknowledged through the MCP-backed review acknowledgement command.

## Blocking conditions
- Any fixed-target `TAXONOMY_GAP` blocks export.
- Structural validation errors block export.
- Fixed-taxonomy semantic audit not passed blocks export.
- Uninvestigated high REVIEW blocks export.

## Distribution checks
Label distributions are useful diagnostics, not proof of semantic correctness. Wrong labels may still produce plausible aggregate counts.
