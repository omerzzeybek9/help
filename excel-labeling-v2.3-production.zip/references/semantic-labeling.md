# Semantic Labeling Contract

## Meaning over words
Classify from the meaning of the complete source plus approved context.

Never implement semantic labeling as ad-hoc keyword, substring, regex, or phrase matching.

A keyword can be evidence, but:
- its absence does not exclude a label;
- its presence does not force a label.

Examples:
- “Sipariş ertesi gün elimdeydi” can mean Delivery without the word “kargo”.
- “Kargo firması değil, ürünün kendisi kırık çıktı” should not automatically become Delivery.
- “Harika, sadece on gün bekledim” may be negative/ironic despite a positive-looking word.
- “Teşekkür ederim ama sorun çözülmedi” may be negative/unresolved despite polite language.

## Work provenance
Never label a row from its row number, prior distribution, a remembered pattern, or an assumed repetitive structure.
Only label source content actually present in the current runtime work payload.

The runtime lease/hash is a transport guard; it does not replace semantic reading. Read the source/context for every returned task before deciding.

## Approved preview exemplars
After preview approval, the runtime may include approved preview examples in target rules. Treat them as binding semantic guidance unless the user later changes the setup.

Apply the same meaning consistently to paraphrases and formatting variants; do not require exact wording.

## REVIEW vs TAXONOMY_GAP
Use `REVIEW` only when the row itself is genuinely unresolved because of ambiguity, missing essential context, unintelligible source, or materially indistinguishable choices.

Use `TAXONOMY_GAP` when the meaning is clear but no approved label covers it.

A taxonomy gap is a setup problem and blocks export until repaired.

## Empty rows
If all primary source columns are empty, leave output blank. Do not mark REVIEW.

## Single label
Choose the one label best supported by the target purpose and definitions.

## Multi label
Return every materially supported label, but avoid weak or incidental labels.

## Context
Context can disambiguate source meaning. It must not override an explicit source statement without a clear reason.

## Multi-target row consistency
When a row bundle contains multiple targets, reason about the row once, then answer every target independently under its own purpose.

Do not let one target substitute for another. For example:
- Topic = `Kargo/Teslimat`
- Sentiment = `Olumsuz`

A sentiment word is not itself a topic. A topic mention is not itself a sentiment.

Return every pending target in the bundle together. If one target is genuinely unresolved, mark only that target REVIEW rather than omitting it.
