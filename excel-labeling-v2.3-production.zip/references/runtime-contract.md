# Runtime Contract — Protocol 2.3

Use this reference when calling the Python runtime. If any field name is uncertain, prefer:

```bash
python scripts/excel_labeling.py contract
```

Do not inspect implementation source merely to rediscover public field names.

## Config enums
`label_source`: `user`, `proposed`, `freeform`

`cardinality`: `single`, `multi`

## Work delivery guarantee
`preview-next` and `next` return bundles. A normal bundle has:

```json
{
  "mode": "row_bundle",
  "bundle_id": "full:row:42:...",
  "source_row": 42,
  "row_fields": [
    {"ref":"B","name":"yorum","text":"Sipariş ertesi gün elimdeydi"},
    {"ref":"C","name":"kanal","text":"Mobil"}
  ],
  "tasks": [
    {
      "unit_id": "t001:r00000042",
      "target_id": "t001",
      "source_refs": ["B"],
      "context_refs": ["C"],
      "bundle_id": "full:row:42:...",
      "lease_id": "...",
      "source_hash": "..."
    },
    {
      "unit_id": "t002:r00000042",
      "target_id": "t002",
      "source_refs": ["B"],
      "context_refs": [],
      "bundle_id": "full:row:42:...",
      "lease_id": "...",
      "source_hash": "..."
    }
  ]
}
```

`row_fields` is deliberately shared once per physical row to reduce context duplication in multi-target jobs. For each task, use only the fields referenced by `source_refs` + `context_refs`; do not silently use unrelated columns.

### Atomic bundle rule
A returned bundle is atomic. Submit every pending task in that bundle together. The runtime rejects a partial bundle with `INCOMPLETE_BUNDLE`.

This prevents one target (for example Topic) from moving ahead while another target (for example Sentiment) silently falls behind on the same row.

Canonical final decision:

```json
{
  "unit_id": "t001:r00000042",
  "bundle_id": "full:row:42:...",
  "lease_id": "<exact returned value>",
  "source_hash": "<exact returned value>",
  "labels": ["Kargo/Teslimat"]
}
```

For genuine ambiguity use `review: true` + `review_reason`.
For a clear missing approved category use `taxonomy_gap: true` + `gap_reason`.

The runtime rejects unleased work, wrong hashes, wrong bundle ids, incomplete bundles, wrong scopes, expired leases, unknown labels, and cardinality violations.

## Long text
Long-text segment bundles are also atomic for the segments returned in that call. Complete all segments before the aggregate decision. Never infer the aggregate from only the visible prefix.

## Independent audit
`audit-next` returns source + target rule but intentionally not the production label. Submit independent labels with the audit item's exact lease/hash.

The default audit is larger and stricter than protocol 2.1, reports per-target mismatch rates, and blocks when overall or any target exceeds the semantic mismatch guardrail.

If `audit-finalize` fails:

```bash
python scripts/excel_labeling.py repair-start --job-dir JOB
python scripts/excel_labeling.py repair-next --job-dir JOB
python scripts/excel_labeling.py repair-submit --job-dir JOB --stdin
python scripts/excel_labeling.py repair-finalize --job-dir JOB
```

Then start a fresh audit.

## High REVIEW gate
`REVIEW` is not a generic fallback. If REVIEW exceeds the runtime warning threshold for a target, `validate` blocks unless the cause is fixed or the user explicitly accepts genuinely unavoidable ambiguity through:

```bash
python scripts/excel_labeling.py acknowledge-review \
  --job-dir JOB --targets TARGET_ID \
  --approval-source ask_user_question
```

Do not use this command to hide a poor taxonomy.
