---
name: excel-labeling
description: Semantically labels, classifies, categorizes, tags, or codes rows in Excel/CSV data. Use when a user asks to label spreadsheet rows, classify comments/tickets/records, create labels from data, apply an existing label list, perform sentiment/topic/intent or other row-level labeling, or add one or more semantic label columns. Supports multiple labeling dimensions, user-provided/data-proposed/free-form labels, ask_user_question approvals, large files, long text, semantic QA, safe repair, and workbook-preserving export. Do not use for simple filtering, formulas, formatting, sorting, or non-semantic spreadsheet edits.
---

# Excel Labeling
Version: 2.3

## Product goal
Make high-quality data labeling feel simple to a non-technical employee.

The user should normally experience only:
1. **What do you want to label for?**
2. **Are these labels/rules right?**
3. **Do these examples look right?**
4. **Here is the finished file.**

Do not expose internal batching, chunks, hashes, leases, JSON, token limits, queue state, sampling mechanics, or audit internals unless the user explicitly asks.

## Responsibility split
**Agent / model:** understand meaning, propose dimensions and labels, make semantic labeling decisions, adjudicate ambiguous QA cases, and interact with the user.

**Runtime script:** inspect files, preserve row identity, retrieve bounded work, prove that work was actually delivered to the model, handle exact duplicates and long text, validate structure, run semantic-audit workflow, and export safely.

Never replace semantic classification with keyword/substring/regex rules for speed.

## Non-negotiable rules
- Use the real `ask_user_question` MCP tool for every required user decision or approval gate.
- Never invent approval or replace a required MCP interaction with a normal chat question.
- If the user merely says “label this”, do **not** assume one dimension. First determine which angle(s) they want.
- Support multiple independent targets in the same file, such as Topic + Sentiment + Intent.
- Never full-label before explicit preview approval from `ask_user_question`.
- Every semantic decision must come from work actually returned by `preview-next`, `next`, `audit-next`, or `repair-next`. Never create labels for rows whose source content is not present in the current work payload.
- Every submit must copy the exact `bundle_id`, `lease_id`, and `source_hash` returned for that work item. Never guess or reuse them across work items.
- Treat every returned row/segment bundle as atomic: submit every pending task in that bundle together. Never leave one target from a row behind while submitting another.
- Approved preview examples are binding semantic guidance unless the user later changes the rules.
- Treat clear missing categories as `TAXONOMY_GAP`, not `REVIEW`.
- Never silently truncate source text used for final classification.
- Never place an entire large dataset in conversational context.
- Preserve the original workbook, sheets, row order, and source columns.
- External research is not part of normal labeling.
- Do not claim success until structural validation **and semantic audit** pass.
- After preview approval, do not send user-visible progress about work queues, payload construction, retry loops, audits, or repair. Continue internally until completion or until a genuine business decision is required.
- Recover from technical/runtime-contract mistakes internally when possible. Use `contract` instead of asking the user to troubleshoot implementation details.
- If REVIEW becomes unexpectedly high, investigate before export. Do not normalize a weak taxonomy by sending large portions of the file to REVIEW.

Load references only when relevant:
- `references/interaction.md` — user-friendly MCP interaction
- `references/dimensions.md` — deciding labeling angle(s)
- `references/label-discovery.md` — Path A/B/C and taxonomy design
- `references/semantic-labeling.md` — semantic decision contract
- `references/quality.md` — preview, independent semantic audit, repair
- `references/large-data.md` — large/long data and exact duplicates
- `references/security.md` — enterprise/research boundaries
- `references/runtime-contract.md` — exact runtime protocol and payload shapes

# Workflow

## 1. Inspect before asking
For an Excel/CSV input:

```bash
python scripts/excel_labeling.py inspect INPUT [--sheet SHEET]
```

Learn sheets, row count, columns, missingness, likely text/category/id roles, and long-text risk. Do not ask the user for facts the file already reveals.

If the relevant sheet is ambiguous, resolve it with `ask_user_question`.

If a user is about to paste hundreds of rows into chat, briefly recommend uploading Excel/CSV because it is more reliable. Do not block small pasted datasets.

## 2. Determine the labeling dimension(s)
A **target** is one independent meaning assigned to a row: Topic, Sentiment, Intent, Urgency, Root Cause, Risk, Status, etc.

If targets are explicit, use them without asking again.

If the user only says “label/classify this”, inspect a small varied sample and use `ask_user_question` to offer a small set of data-relevant dimensions. Multi-select when appropriate.

Do not show a generic analytics menu if the data suggests more useful domain-specific targets.

See `references/dimensions.md`.

## 3. Resolve source/context/output columns
For each target determine:
- primary source column(s) that carry the meaning;
- optional context column(s) that disambiguate meaning;
- output column.

Recommend likely columns. Ask only if ambiguous. If obvious, include the proposed column use in setup approval so the user still gets column-level visibility without another interruption.

Never silently use every column.

## 4. Resolve labels: Path A / B / C
Each target independently uses:
- **A — user labels:** use the user's existing label list;
- **B — proposed from data:** discover labels from varied data and test coverage;
- **C — free-form:** create semantic labels during labeling, then consolidate near-duplicates.

Fast default: if no label list is supplied and free-form is not requested, use **Path B** and show that choice in setup approval. Do not ask an unnecessary extra question merely to select B.

See `references/label-discovery.md`.

## 5. Resolve one vs multiple labels
For every target, determine whether each row can receive:
- one label; or
- multiple labels.

Use `ask_user_question` unless already explicit. When possible ask for all selected targets in one MCP interaction.

## 6. Build a strong Path-B taxonomy
Do not build the label set from 3–5 easy rows.

Choose discovery size from the non-empty row count while keeping the work hidden from the user:
- up to 100 rows: about 20 discovery + 12 fresh coverage rows;
- 101–1,000 rows: about 32 + 20;
- above 1,000 rows: about 48 + 32;
- never exceed the runtime sample limit, and use fewer when the file has fewer unique non-empty records.

Discovery sample example:

```bash
python scripts/excel_labeling.py sample INPUT \
  --columns SOURCE_COL1 [SOURCE_COL2 ...] \
  [--context-columns CONTEXT_COL1 ...] \
  --count DISCOVERY_COUNT --strategy diverse --seed 23 [--sheet SHEET]
```

Then test the proposal on a different coverage sample:

```bash
python scripts/excel_labeling.py sample INPUT \
  --columns SOURCE_COL1 [SOURCE_COL2 ...] \
  [--context-columns CONTEXT_COL1 ...] \
  [--exclude-rows DISCOVERY_ROWS ...] \
  --count COVERAGE_COUNT --strategy diverse --seed 91 [--sheet SHEET]
```

Before presenting labels, check:
- coverage of recurring meanings;
- distinctness / overlap;
- consistent boundaries;
- usefulness for the user's selected target;
- unnecessary cross-target redundancy (for example, a Topic label that merely duplicates Sentiment).

When Topic and Sentiment are both selected, keep the targets orthogonal: a pure evaluative concept such as “Memnuniyet/Olumsuzluk” normally belongs to Sentiment, not Topic. If a general-topic fallback is truly useful, prefer a neutral business concept such as “Genel Deneyim” and define when it applies.

If the coverage sample reveals a recurring meaning that is missing or poorly separated, refine the proposal and test a fresh sample again. Do not present the taxonomy to the user until material recurring gaps stop appearing or additional labels would only represent rare/trivial wording variants.

For fixed labels maintain internal definitions, useful include/exclude boundaries, and a few examples where helpful. They are semantic guidance, not keyword lists.

## 7. Setup approval
Show a concise setup per target:
- target meaning;
- source/context columns;
- output column;
- one/multiple rule;
- label list with brief definitions for A/B.

Then use `ask_user_question` for approval or changes.

Research policy:
- approved target → continue, no research;
- user correction → apply it, no research unless requested;
- explicit research request → tell the user first, research only the unresolved business concept, and never send row-level customer data externally.

## 8. Create runtime config and initialize
If unsure about config fields, call:

```bash
python scripts/excel_labeling.py contract
```

Do **not** grep the script or guess field names when the contract command provides them.

Canonical config fields include:
- `label_source`: `user` | `proposed` | `freeform`
- `cardinality`: `single` | `multi`

Initialize only after MCP setup approval:

```bash
python scripts/excel_labeling.py init INPUT \
  --job-dir JOB --config CONFIG.json \
  --setup-approval-source ask_user_question [--sheet SHEET]
```

Never ask the user to edit config/JSON.

## 9. Meaningful preview
Preview should test the rules, not just show easy cases. Prefer 5–7 source rows covering ordinary, boundary, multi-label-looking, irony/negation-like, long/complex, and semantically varied examples when present.

```bash
python scripts/excel_labeling.py preview-start --job-dir JOB --count 5 [--rows ROW1 ROW2 ...]
```

Then repeat:

```bash
python scripts/excel_labeling.py preview-next --job-dir JOB
```

A response may contain `row_bundle` items. Each bundle groups the pending targets for the same source row. Read the bundle's `row_fields` once, then use each task's `source_refs` and `context_refs` to apply only the fields allowed for that target. Classify every pending target semantically.

Submit only returned tasks. For each returned bundle, submit **all pending tasks in that bundle together**, copying each task's exact `unit_id`, `bundle_id`, `lease_id`, and `source_hash`:

```bash
python scripts/excel_labeling.py submit --job-dir JOB --stdin
```

Inspect:

```bash
python scripts/excel_labeling.py preview-results --job-dir JOB
```

If preview text is long, user-facing display may be shortened, but final preview classification must use the complete-source mechanism.

Use `ask_user_question` for mandatory preview approval.

If preview is rejected because labels, definitions, source/context use, or one/multiple behavior must change, do **not** continue the existing runtime job. Treat its state as stale: revise the proposed setup, obtain MCP approval for the revised setup, initialize a fresh job directory from the unchanged source file, and run a new preview. Do not try to patch already-written preview results in place.

If the user only asks to see different examples without changing the approved rules, a fresh preview selection may be shown without changing the setup.

Unlock full work only after explicit MCP approval:

```bash
python scripts/excel_labeling.py approve-preview \
  --job-dir JOB --approval-source ask_user_question
```

## 10. Full semantic labeling
Repeat until no work remains:

```bash
python scripts/excel_labeling.py next --job-dir JOB
```

For each returned row bundle:
1. read the bundle source/context fields referenced by that target;
2. apply the target rule by meaning;
3. use approved preview examples as guidance;
4. return labels for every pending task in the bundle in the same submit call;
5. copy the exact bundle/lease/hash values into submit.

If one target cannot be decided, use REVIEW/TAXONOMY_GAP for that target as appropriate rather than dropping it from the bundle.

Never produce a decision from a row number, previous distribution, guessed pattern, or unseen text.

Do not narrate internal loops, counts per batch, queue mechanics, or repeated submit operations to the user.

For long-text bundles, process all returned segments and then the aggregate item. Segment signals are not final row labels.

Use `REVIEW` only for genuinely unresolved rows. Use `TAXONOMY_GAP` when meaning is clear but the approved labels do not cover it.

## 11. Path-C consolidation
For free-form targets, consolidate after raw labeling:

```bash
python scripts/excel_labeling.py consolidation-next --job-dir JOB
python scripts/excel_labeling.py consolidation-submit --job-dir JOB --stdin
```

Merge synonyms/trivial variants, not materially different concepts. If consolidation changes business meaning, use `ask_user_question` before applying it.

## 12. Pre-audit quality triage
Before spending work on the semantic audit, run:

```bash
python scripts/excel_labeling.py quality-report --job-dir JOB
```

If any fixed target contains `TAXONOMY_GAP`, the approved label set is incomplete. Do not audit/export and do not convert those rows to REVIEW. Group the recurring gap meanings internally, use `ask_user_question` to approve the necessary business-rule/taxonomy change, then initialize a **fresh job** with the revised config and return to preview.

If REVIEW is unexpectedly high, inspect the examples now. If it is caused by weak rules/taxonomy, revise setup through the same fresh-job path. If ambiguity is genuinely inherent, keep it for the later REVIEW acknowledgement gate.

## 13. Independent semantic audit — mandatory for fixed-taxonomy targets
Structural completeness is not enough. Before export, run an independent audit that intentionally hides production labels from the audit classifier:

```bash
python scripts/excel_labeling.py audit-start --job-dir JOB --count 60
```

Then repeat:

```bash
python scripts/excel_labeling.py audit-next --job-dir JOB
python scripts/excel_labeling.py audit-submit --job-dir JOB --stdin
```

Classify audit rows independently from source meaning. Do not try to reconstruct or guess the existing production label.

Inspect:

```bash
python scripts/excel_labeling.py audit-results --job-dir JOB
python scripts/excel_labeling.py audit-finalize --job-dir JOB
```

The audit deliberately covers the whole file and over-samples later rows to catch long-running-loop drift.

If audit fails, do **not** export and do not ask the user to debug internals. Create a repair scope:

```bash
python scripts/excel_labeling.py repair-start --job-dir JOB
```

A failed audit may indicate drift beyond the sampled mismatch rows. The runtime therefore queues the affected target from the earliest audited mismatch through the end when appropriate.

Repeat:

```bash
python scripts/excel_labeling.py repair-next --job-dir JOB
python scripts/excel_labeling.py repair-submit --job-dir JOB --stdin
```

until `pending` is zero, then:

```bash
python scripts/excel_labeling.py repair-finalize --job-dir JOB
```

After repair, rerun audit from `audit-start`. If failures reveal a business-rule/taxonomy problem rather than execution drift, return to the user through `ask_user_question`, change the approved setup, and re-preview.

See `references/quality.md`.

## 14. Final validation and export
Run:

```bash
python scripts/excel_labeling.py quality-report --job-dir JOB
python scripts/excel_labeling.py validate --job-dir JOB
```

Do not export when validation fails, taxonomy gaps remain, semantic audit has not passed, or a high REVIEW rate still needs investigation.

If `quality-report` shows REVIEW above the runtime warning threshold, inspect the problem samples. Fix taxonomy/rules when possible. Only when the REVIEWs are genuinely unavoidable and the user accepts that outcome, use `ask_user_question` and then:

```bash
python scripts/excel_labeling.py acknowledge-review --job-dir JOB --targets TARGET_ID --approval-source ask_user_question
```

Never use acknowledgement merely to bypass a poor labeling setup.

Then export:

```bash
python scripts/excel_labeling.py export --job-dir JOB --out OUTPUT.xlsx
```

Return a concise user-facing summary:
- file completed;
- dimensions/output columns added;
- row count;
- REVIEW count only if nonzero and useful to mention;
- output file.

Do not dump internal QA metrics unless requested or unless a quality issue needs user action.

Finally, use `ask_user_question` to offer a reusable prompt for the approved rules.
