# Runtime Contract — Protocol 2.5

If a field name is uncertain, use:
```bash
python scripts/excel_labeling.py contract
```
Do not grep implementation source to rediscover public fields.

## Input inspection
`inspect` now reports:
- likely header row + confidence;
- CSV/TSV encoding and delimiter when relevant;
- row/column profile;
- long-text risk.

If header detection is genuinely ambiguous, confirm with the user and pass `--header-row N` to `sample` and `init`.

## Config enums
`label_source`: `user` | `proposed` | `freeform`

`cardinality`: `single` | `multi`

Runtime enforces resource limits for runaway configs (target/label/source/context counts and label text lengths).

## Work delivery
`preview-next` and `next` return atomic row bundles. `row_fields` appears once per physical row; each target task refers to permitted `source_refs` and `context_refs`.

Submit **all pending tasks in a returned bundle together** and copy exact:
- `unit_id`
- `bundle_id`
- `lease_id`
- `source_hash`

The runtime rejects unseen/unleased work, wrong source hashes, stale scopes, partial bundles, unknown labels, and cardinality violations.

## Preview correction path
If the user corrects the semantic label of a preview example but setup rules are otherwise unchanged:
```bash
python scripts/excel_labeling.py preview-correct \
  --job-dir JOB --approval-source ask_user_question --stdin
```
Payload:
```json
{
  "corrections": [
    {
      "unit_id": "t002:r00000185",
      "labels": ["Olumsuz"],
      "reason": "İronik olumlu kelime, olumsuz bekleme deneyimini tersine çevirmiyor."
    }
  ]
}
```
This command does not require the old work lease. It persists the user correction as a binding exemplar and invalidates prior preview approval/audit state. Run `approve-preview` again after showing the corrected preview.

If taxonomy/source/cardinality changes, do **not** use `preview-correct`; start a fresh job after new setup approval.

## Long text
Complete every segment before aggregate classification. Never classify from a truncated preview prefix.

## Semantic audit
All targets require audit after completion. Path C must first finish consolidation; audit then evaluates canonical labels.

Audit source is hidden-label work. Semantic decisions must be fresh model reasoning, not a generated classifier script or reused production helper.

Audit sampling covers approved exemplars, labels, context, timeline, long text, and unique content clusters.

If audit fails: repair → fresh audit → validation.

## Export safety
- spreadsheet formula-triggering generated text is escaped as literal text;
- source workbook is reopened with formulas preserved for export;
- CSV/TSV input encoding/delimiter is detected rather than assumed;
- detected non-row-1 headers are preserved.


## Job state / diagnostics
SQLite is the authoritative state source. Normal progression is:
`SETUP_APPROVED → PREVIEWING → PREVIEW_APPROVED → LABELING → (CONSOLIDATING) → AUDITING → AUDIT_PASSED → VALIDATED → EXPORTED`.
Failed audits move to `AUDIT_FAILED`; repair moves through `REPAIRING` and then requires a fresh audit.

For engineering diagnosis only:
```bash
python scripts/excel_labeling.py manifest --job-dir JOB
```
The manifest intentionally excludes raw row text.

## Output conflicts and delimited output
`export` accepts `--on-conflict error|overwrite|suffix`. Keep the default `error` until the user has made a choice through `ask_user_question`. CSV/TSV inputs may be exported directly to `.csv`/`.tsv`; their delimiter is preserved for CSV when possible, and generated formula-like text is escaped as literal text.

## Large mostly-unique workloads
`status` returns an internal `execution_hint.recommended_max_items` derived from row count, average text length, long-text exposure, and uniqueness. The agent may use it with `next --max-items ...` to reduce tool-call overhead, but must still obey the text budget and semantic-execution rules. This is an internal tuning hint, never a user-facing batch setting.
