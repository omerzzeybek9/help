# Wise integration: progress and context renewal

The skill can produce state; it cannot change an unknown Wise renderer or model context. This file defines a concrete integration contract, not an already installed MCP tool.

## One progress component
The adapter atomically updates JOB/progress.json after accepted work and on finish. It contains key (stable job identity), revision (monotonic change number), stage (Turkish display text), percent (stage-local percentage or null), completed_rows, total_rows (nonempty source rows), blank_rows and output_ready. It excludes source text and label decisions. Segment work advances labeling progress even while a long row has not yet finalized. Percent is stage-local, not a wall-clock estimate; do not display label-stage 100 as completed delivery.

In the actual Wise renderer, create one progress component for key and replace its state on each revision. assets/progress.html is a small accessible reference component. The host must feed parsed progress.json via setLabelingProgress(payload); it contains no timers, fake progress, polling endpoints or external URLs. It is not live when merely attached as a file. Bind only the authorized job to that component. A native progress MCP, if actually exposed, may use the same state through its real schema; do not invent tool names.

Collapse repetitive tool activity cards and prevent their captions from becoming extra assistant messages where the host supports it. The skill's short-title instructions cannot suppress platform-generated UI on their own. Progress events should reach the UI out of band rather than being appended to the model conversation. On successful real file attachment the host can show the delivery result. output_ready alone means the export is ready, not already attached.

If no renderer integration is available: one start sentence, then the final file; no repeated text bars. Higher-priority status obligations remain applicable.

## Host context renewal
The adapter counts serialized work responses plus submitted answers per session in context_session.json. Default ceiling is 240000 characters, configurable by the host with --context-budget-chars. This is a tunable transport allowance, NOT a measured token count or proof of available model context. The host must also account for instructions, reasoning, earlier chat, other tools and its actual model limit.

Before another request exceeds that allowance, work/answer --next returns host_context_handoff and writes resume.json. Already accepted decisions remain committed; a leased but undisplayed request can be rebuilt. No source or approval is lost. A request larger than the configured allowance returns host_capacity_required without emitting its source into model context. Reduce retrieval size with --refresh, or verify real host capacity for an indivisible record; never truncate source.

Actual host sequence:
1. Persist original input and the entire job directory in authorized storage. Keep authentic user approvals bound to the current preview/configuration in the host.
2. On handoff or earlier real context-pressure signal, compact or create a fresh model worker. Retain the task, installed skill path, current job path, outstanding user choices and actual approval state, not previous raw work transcripts.
3. Reload SKILL.md; call adapter status and work --refresh --session-id ACTUAL_NEW_CONTEXT_ID. Pass the host-approved context budget if different. The same full original source remains accessible in the job; all previous segments/results are retained independently per target.
4. Continue model decisions and the same progress component. Do not re-init the job or ask already-granted unchanged approvals again.

Never change session-id merely to bypass the limit while retaining the same full history. If Wise has no compaction/new-worker facility, preserve the job and report one saved pause. The skill cannot autonomously guarantee completion of arbitrary long datasets in one finite conversation. Resume files must be accessible to the continuation worker; starting a fresh chat without persistent job storage is insufficient.

## Acceptance on Wise
Verify real tool cards are collapsed, progress updates replace rather than append, preview table rendering preserves four separate headers, source summaries remain 1–2 sentences, current preview is genuinely approved, reusable TXT attaches automatically, and a forced context renewal resumes the same job. Local fixtures cannot prove these host behaviors. Do not export or publish an unaudited alternative if integration fails.
