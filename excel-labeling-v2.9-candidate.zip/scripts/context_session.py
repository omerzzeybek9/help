"""Bound serialized transport per host context. This cannot clear the host's history."""
import json
from pathlib import Path
import excel_labeling as rt
from presentation import write_json

def checkpoint(jd,session):
    _,meta=rt.load_job(jd)
    payload={'action':'host_context_handoff','job_dir':str(jd.resolve()),'input':meta['input'],'state':meta['state'],'session_id':session['id'],'emitted_characters':session['characters'],'instruction':'Host must compact/reset model context while preserving this job and source. In the new context read SKILL.md, call status, then work --refresh --session-id <actual-new-host-session-id>. Do not replay prior work or change session id without real context renewal. If unavailable, report one saved pause, not success.'}
    write_json(jd/'resume.json',payload);return payload

def load_session(jd,session_id=None):
    p=jd/'context_session.json';s=rt.load_json(p) if p.exists() else {'id':session_id or 'default','characters':0}
    if session_id is not None and session_id!=s['id']:s={'id':session_id,'characters':0}
    return s

DEFAULT_TRANSPORT_BUDGET = 240000  # Tunable transport allowance, not measured model capacity.

def get_work(jd,fn,session_id=None,budget=DEFAULT_TRANSPORT_BUDGET,**kwargs):
    if budget<4000:rt.die('CONTEXT_BUDGET_INVALID')
    s=load_session(jd,session_id)
    if s['characters']>=budget:return checkpoint(jd,s)
    # New host context must reload rules and invalidate an old outstanding request.
    prev=rt.load_json(jd/'context_session.json') if (jd/'context_session.json').exists() else None
    if prev and prev['id']!=s['id']:kwargs['refresh']=True
    value=fn(jd,**kwargs);cost=len(json.dumps(value,ensure_ascii=False,separators=(',',':')))
    if cost>budget:
        return {'action':'host_capacity_required','job_dir':str(jd.resolve()),'required_characters':cost,'budget_characters':budget,'instruction':'Request retained on disk; original text not emitted. Reduce work size with --refresh, or use host-verified capacity for an indivisible record. Never truncate source or raise budget without actual capacity.'}
    if s['characters'] and s['characters']+cost>budget:
        write_json(jd/'context_session.json',s);return checkpoint(jd,s)
    s['characters']+=cost;write_json(jd/'context_session.json',s)
    return value

def charge_answer(jd,payload):
    s=load_session(jd);s['characters']+=len(json.dumps(payload,ensure_ascii=False,separators=(',',':')));write_json(jd/'context_session.json',s)
