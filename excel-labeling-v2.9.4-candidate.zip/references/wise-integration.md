# Task plan and uninterrupted authorized work

At the start show these steps once:
1. Dosyayı ve etiket tercihlerini netleştir
2. Örnekleri göster ve onay al
3. Tüm satırları etiketle
4. Sonuçları kontrol et
5. Excel ve tekrar kullanım metnini sun

If a real native plan/task tool is exposed, use its actual schema and update the same plan. Otherwise use a normal short checklist. No bar, HTML asset or renderer installation is required. Do not invent a tool. Questions and approvals still use the actual ask_user_question MCP.

JOB/plan.json records current steps; work responses include plan_update only on stage changes. Complete stage 1 after real setup approval, stage 2 after real preview approval, stage 3 after labeling and required consolidation, and stage 4 after the quality gate passes. Stage 5 stays in_progress until both files are actually attached; an export receipt alone does not prove attachment. Native plan updates should replace the same plan, not add one message per row.

Without a plan tool, show each newly completed stage once, for example “✓ Örnekler onaylandı.” Continue the next tool immediately in the same turn. Do not repeat the full checklist on every update. If correction/repair reopens a stage, reflect the current state without claiming finished work is still valid. A plan update is not a final response.

There is no runtime-imposed cumulative character stop. The adapter calls the next action directly, retains accepted decisions, shares exact source where possible and uses bounded work retrieval. Existing job files remain valid; obsolete context_session.json/resume.json files do not control this version. Do not re-init an existing job or discard labels to upgrade. Use the current CLI from this version; old session/budget flags are no longer arguments.

Never simulate a background worker or promise progress after ending a turn. Continue authorized work through export and actual attachment. Only genuine user decisions, a user stop request or a concrete unrecoverable tool/input problem justify stopping. Required approvals and audit/export guards remain in force.

The skill cannot alter actual host model limits or guarantee a host will keep executing indefinitely. Verify native plan rendering, real MCP answers and file attachments in Wise; local fixture tests do not exercise that interface.
