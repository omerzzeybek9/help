# Large Data and Long Text

## Context discipline
Never load the full dataset into conversational context. Retrieve bounded work from the runtime.
Do not ask users for internal batch/chunk sizes.

Context is a finite execution resource. After preview approval:
- do not enumerate work rows or label decisions in prose;
- do not summarize every processed batch;
- do not repeat stable target rules on every retrieval; load them once with `rules`;
- submit bounded decisions immediately and use SQLite/runtime status as durable memory;
- never use conversation history to reconstruct which rows are complete.

If a platform warns about context pressure, stop adding summaries. Consult `status`/`manifest` and continue from runtime state rather than replaying old row text.

## Row bundles
For ordinary rows the runtime groups pending targets for the same physical source row into one `row_bundle` when possible. This reduces orchestration calls and helps Topic/Sentiment/etc. stay synchronized.

Read and decide every returned task in the bundle. Do not infer missing tasks from earlier rows.

## Work leases and source hashes
Every delivered semantic task includes a short-lived `lease_id` and `source_hash`. Submit must copy both exactly.
This prevents results for unseen/unknown work and protects against stale or shifted work queues.

Do not expose leases/hashes to users.

## Exact duplicates
Exact-identical source + approved context under the same target may reuse an already approved semantic result. This is deterministic and safe.
Do not automatically reuse approximate/fuzzy matches.

## Long text
Never silently truncate source used for final classification.
Long work is segmented internally. Segment outputs are semantic signals, not final labels. Finalize only after every required segment has been processed and the aggregate task is returned.

Preview excerpts/summaries are display-only.

## Stable row identity
Map results through runtime row IDs and source hashes, never by searching copied text back into the sheet.

## Performance principle
Optimize transport, bundling, exact duplicates and deterministic file operations. Never buy speed by replacing semantic reasoning with keyword rules.


## Completion truth
An internal plan checkbox or a statement such as “300 rows completed” is not evidence. Only `status.labeling_complete=true` authorizes moving to audit or telling the user full labeling is complete.


## Host context risk and resumability
`status.execution_hint.context_risk` is an internal signal derived from mostly-unique semantic text volume. It is not a quality score and must not be shown to ordinary users.

For large mostly-unique workloads, use bounded retrieval, share exact original text and commit decisions promptly. Estimated source volume is an internal planning signal, not a reason to stop or ask the user to restart. Continue the authorized work; never substitute keyword heuristics for semantic decisions.

After an interrupted tool call, recover from runtime status and rules in the same job rather than replaying prior rows or reconstructing progress from chat history.

## Normal transport
Use agent_io work/answer for all semantic phases. Rules are returned when the phase or approved guidance changes. After an uncertain tool result, work --refresh returns them again. Default work sizes count decisions, not rows; increasing targets does not require dividing the cap a second time. The adapter is single-writer and never starts background workers.

## v2.9.4 transport
Use answer --next to combine submission and retrieval. Identical segment text is shared through same-response text_ref; read it once and decide every target. Update only completed stages in the task plan, without narrating individual calls. See wise-integration.md. Do not select overlapping CONV/agent/customer representations without a semantic need.
