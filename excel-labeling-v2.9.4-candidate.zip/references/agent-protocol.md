# Agent protocol 2.9.4

Use scripts/agent_io.py. It transports explicit model decisions and never classifies source. Read this short submission section before the first answer. Keep internal config/SQLite/answer files outside the host delivery directory; use stdin rather than attachment-producing file tools.

`work --job-dir JOB` returns `action`, `request_id`, `phase`, `items`, and rules when changed. Normal items have shared row_fields and target tasks. Long tasks have `text` or `text_ref`. A text_ref refers to another task ref **in this same response**, with identical original text. Resolve it before deciding; do not invent missing references. This preserves full original evidence while avoiding repeated copies for multiple targets. Audit/repair items are flat tasks; each still needs its own decision.

Copy the entire returned answer_format, including request_id and EVERY answer entry, and fill its placeholders. Submit every short reference exactly once:
```
python scripts/agent_io.py answer --job-dir JOB --stdin --next <<'JSON'
{"request_id":"<returned-id>","answers":[{"ref":"1","labels":["<approved-label>"]}]}
JSON
```
`--next` commits the answer then returns the next action/work. Do not call another work before answering an outstanding request. If the next retrieval fails after commit, the accepted answer remains persisted; work --refresh reconstructs pending work. Immediate identical retries are safe. Unknown/stale references and partial requests fail. The adapter carries exact backend identifiers internally.

For segment tasks provide a concise note preserving meaning, negation and outcome across every segment. After all segments a separate aggregate task returns the signals. Summary text for user display is never a classifier input. Use review/review_reason only for genuinely unresolved source; use taxonomy_gap/gap_reason for clearly uncovered meaning. Never combine both. Consolidation answers use canonical_label instead of labels.

Actions:
- answer: read full evidence and submit all tasks.
- start_preview: run backend preview-start.
- approve_preview: run adapter preview, provide faithful short summaries when requested, show the returned table once, then obtain real MCP approval and call adapter approve.
- resolve_input / resolve_taxonomy / investigate_reviews: resolve the specific source/rule issue; do not export.
- diagnose_audit: inspect a few disagreements, then clarify rules or backend repair-start --mode progressive; return to the same loop.
- finish: call adapter finish, attach verified Excel and automatically generated reusable prompt.

Use work --refresh after an uncertain tool result; accepted work persists and rules reload. Only one writer per job. --max-tasks is a decision cap; a complete ordinary multi-target row can exceed it. --text-budget bounds original evidence, not total tokens; one atomic piece can exceed the soft cap. Never truncate actual labeling source.

Backend commands are retained for setup/corrections and engineering diagnostics. Ordinary workflow must use the adapter through completion, including audit finalization; do not guess that labeling completion or submitted audit answers mean the file is ready.

## Continuous execution and stage plan
Continue work → answer --next through the returned next action until finish. A successful answer is an intermediate step, not permission to end the turn. No cumulative character counter or manual-session handoff is part of this protocol. Accepted work is still stored durably in the job.

plan_update appears only when a stage changes. Map its steps to the actual plan tool if available; otherwise announce only newly completed stages once. A cached work retry may not repeat an already-reported plan update; the latest plan is also in JOB/plan.json. Never fabricate a native tool. Delivery remains in_progress even after export: the agent must attach the Excel and prompt through the actual host file tool, then complete that step. Do not publish plan.json itself.

## Label answers and display summaries are different payloads
- Label decisions: copy answer_format from work; send to `agent_io.py answer --stdin --next`. It contains request_id and answers with ref/labels (or note/canonical_label as returned).
- Display summaries: copy summary_format from preview; send to `agent_io.py preview --stdin`. It contains summaries with source_row/summary, without request_id.
- A missing field is a payload correction, not a reason to lease new work. Read the error and correct the same submission. Never send summaries to answer.
- work action=approve_preview means decisions are saved; it does NOT mean user approval. Run preview, complete its summaries, show its exact markdown, obtain real MCP approval, then run approve with the exact preview_id.
- Never manually fabricate a preview table after a failed submission. The normal path does not require low-level preview-next/next/submit calls.
