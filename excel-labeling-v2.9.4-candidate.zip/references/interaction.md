# Kullanıcıyla konuşma akışı

## İlk soru ekranı
Gerçek ask_user_question MCP ile üç tercihi aynı ekranda al: boyutlar; etiket kaynağı; seçilen bütün boyutlarda tek/çoklu etiket. Bu üçüncü sorunun kapsamını açık söyle. Tek/çoklu cevabı bütün seçilen boyutlara uygulanır; yalnız “boyuta göre belirleyeyim” yanıtı verilirse farklı tercihleri birlikte tamamlat. Kullanıcı açıkça farklı boyutlar için farklı kaynak/seçim belirtmişse bunu koru. Yanıtlanmış tercihi tekrar sorma; genel etiket onayını hiç sorulmamış tercihin cevabı sayma.

MCP çağrı sınırı varsa kalan ilk soruları hemen sonraki çağrıda tamamla; bu sırada etiket önerisi veya dosya hazırlığına geçme. Soru metinlerini normal mesajla sunup gerçek MCP kullanmadan onay almış gibi davranma. Teknik araç/endpoint/API anahtarı/ayar dosyası isteme.

## Onayların anlamı
Kullanıcının göreceği iki ayrı onay vardır:
1. Etiketlerin kısa tanımları, uygulanacak kaynak/sonuç sütunları ve tek/çoklu tercihi bir arada gösterilir. “Bu etiketlerle örnekleri hazırlayayım mı?” yanıtı bu yapıyı onaylar. Ayrı teknik kurulum onayı yoktur.
2. Tamamlanmış örnek tablo gerçekten gösterilir. Bu örneklerin onayı tüm dosyanın işlenmesine izin verir.

Etiket/sütun yapısı daha önce açıkça onaylandıysa tekrar sorma. Bir iç dosyanın biçimi hatalıysa bunu mevcut cevaplardan düzelt; kullanıcıdan aynı kararları yeniden isteme. Yapı değişirse yalnız ilgili değişikliği netleştir. Hazır etiket listesi henüz paylaşılmadıysa gerçek listeyi istemek eksik bilgi sorusudur; teknik kurulum değildir.

## Örnekler ve teslim
Tek bir tablo: gerçek Excel satırı, 1–2 cümlelik kısa özet, seçilen boyutların etiketleri. Özet olumsuzluğu/karışık sonucu korur; etiket kararı bütün orijinal metne dayanır. Tabloyu gerçekten mesajda göster, sonra aynı turda gerçek MCP onayını iste. Tablodan önce satırları açıklama ve sadece “onay bekleniyor” deyip durma.

Örnek onayından sonra mevcut işi sürdür. Planı yalnız aşamalar değişince güncelle; bar veya ek arayüz bekleme. Sonunda gerçek dosya aracıyla Excel ve otomatik yeniden kullanım metnini sun; iç JSON veya iş klasörünü sunma.

## Araştırma ve hazır boyutlar
Önce kullanıcıya sor veya veriden öner. Gerçekten belirsiz kalan soyut iş kavramı için araştırmadan önce kısa bilgi ver; müşteri metnini dış araştırmaya taşıma.

Diğer boyutların örnek hazırlığını sürdür. Tam işlem bekleyecekse hazır boyutların etiket/sütun yapısı ve örneklerini onaylatıp bir işte doğrulanmış ara çıktı üret. Sonra kalan boyutları bu dosyadan yeni işte işle; önceki sütunları/satırları koru, kalan işin kendi örnek onayını al. Ara dosyayı kullanıcıya nihai sonuç diye sunma; tüm istenen boyutlar tamamlanınca teslim et. Aktif işin kaynak dosyasını değiştirme.
