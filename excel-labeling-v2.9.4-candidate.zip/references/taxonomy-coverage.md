# Taxonomy Coverage and Shape

## Goal
A taxonomy should cover recurring meanings without hiding them in a catch-all or flattening everything into one broad group.

## Signals
Use `quality-report` and semantic review to inspect:

### Catch-all share
If a configured catch-all (`Diğer`, `Other`, etc.) becomes too large, inspect the recurring fine labels inside it.
A large catch-all often means real categories are missing.

Do not automatically promote every rare label. Promote recurring, meaningful business concepts.

### Dominant group
A group taking a very large share may be valid, but it can also indicate over-broad grouping.
Inspect its fine labels before splitting. Treat this as a quality signal, not an automatic semantic rule.

### Thin groups
Very small groups can indicate needless fragmentation. Merge only when meanings are genuinely compatible.

### TAXONOMY_GAP
For fixed taxonomies, clear uncovered meanings are `TAXONOMY_GAP`, not REVIEW and not forced nearest-label matches.
Recurring gaps require taxonomy revision and a fresh preview.

## Refinement loop
1. Identify material recurring uncovered/fine meanings.
2. Propose additions, splits, merges, or renames.
3. Ask the user only when business meaning changes.
4. Re-run coverage/quality checks.
5. Stop when material recurring gaps disappear and further splits would create trivial categories.

Keep the loop internal until a business decision is needed.

## Evidence
Evidence is useful selectively for:
- preview;
- semantic audit;
- REVIEW/TAXONOMY_GAP diagnosis;
- taxonomy refinement.

Do not require an evidence quote for every normal full-label row merely for display; that adds context/token cost without enough benefit.
