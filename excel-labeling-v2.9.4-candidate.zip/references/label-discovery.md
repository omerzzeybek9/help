# Label Discovery and Design

## User-provided labels
Use the user's vocabulary as authoritative unless they ask for redesign.
Do not rename or research labels by default.
Flag only overlaps/ambiguities that materially harm consistent classification.

## Proposed labels from data
Use two varied samples:
1. discovery sample;
2. fresh coverage sample.

Typical sample sizes may scale roughly as:
- <=100 non-empty rows: ~20 discovery + ~12 coverage;
- 101–1,000: ~32 + ~20;
- >1,000: ~48 + ~32;
subject to unique-record availability and runtime caps.

A useful taxonomy has:
- coverage;
- distinct boundaries;
- repeatable semantics;
- business usefulness;
- parsimony.

Refine internally until fresh samples stop revealing material recurring gaps.

## Fixed label specification
For each label keep only what is needed for stable semantics:
- name;
- short definition;
- include situations;
- exclude nearby meanings;
- examples when useful.

These are semantic boundaries, not keyword rules.

## Free-form + consolidation
Create concise semantic noun phrases from the actual row meaning.
Then merge synonyms/trivial variants without merging materially different concepts.

For root-cause `open_code_then_group`, raw labels are detail codes and canonical labels are reporting groups.

## Cross-target orthogonality
Targets should answer different questions:
- Topic: what is this about?
- Sentiment: how positive/negative/mixed/neutral is the evaluation/outcome?
- Intent: what is the person trying to do?
- Root Cause: what caused the stated outcome/problem?

Avoid redundant labels across targets. For Topic + Sentiment, a Topic label like `Genel Memnuniyet` is usually redundant with Sentiment; use a neutral general-experience fallback only when truly needed.
