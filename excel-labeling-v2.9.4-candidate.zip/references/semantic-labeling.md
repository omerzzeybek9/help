# Semantic Labeling Contract

## Model decides meaning; code does not
Semantic labels must be decided by the model from the actual source/context returned in the current runtime payload.

**Forbidden for semantic decisions:**
- generated Python classifiers;
- `if "word" in text` rules;
- regex/substring/phrase matchers;
- keyword dictionaries used as label-selection logic;
- lookup tables created from observed rows;
- programmatic heuristics that inspect source text and choose a semantic label;
- scripts that read work payloads and automatically emit labels.

Do not create custom helper scripts during semantic work, even merely to bulk-assemble decisions from work rows. The provided runtime CLI already handles deterministic transport and validation. Read the bounded payload directly, decide labels as the model, and submit those decisions through the runtime contract.

The same rule applies to audit: do not reuse a production classifier script/helper, cached semantic decision, or generated rule engine. Audit requires fresh model reasoning from the hidden-label audit payload.

## Meaning over words
Classify from the meaning of the complete source plus approved context.

A keyword can be evidence, but:
- its absence does not exclude a label;
- its presence does not force a label.

Examples:
- “The order arrived the next day” can mean Delivery without saying “shipping”.
- “The courier was not the problem; the product itself was broken” should not automatically become Delivery.

## Sentiment / evaluative targets
When a target represents sentiment, feeling, tone, satisfaction, or evaluation:
- judge the overall evaluative meaning and outcome, not surface politeness;
- use **Neutral** only when there is no material positive or negative evaluation/outcome;
- use **Mixed** when materially positive and negative signals both remain relevant;
- a negative outcome may dominate a polite wrapper;
- detect irony/sarcasm when positive-looking wording conflicts with an obviously negative situation;
- complaints about fit, failure, delay, unresolved issues, adverse price comparison, or broken expectations are not neutral simply because the wording is factual.

General examples:
- “The representative was helpful but the issue was not solved” → Mixed.
- “The size is too small and the fit is tight” → Negative.
- “Great, I only had to wait ten days” → Negative (irony).
- “The package was damaged but the product was intact” → Mixed.
- “I found the same product elsewhere for half the price” → Negative.

Approved user corrections override generic examples and become binding semantic exemplars.

## Work provenance
Never label a row from its row number, prior distribution, a remembered pattern, or an assumed repetitive structure.
Only label source content actually present in the current runtime work payload.

Runtime lease/hash proves delivery; it does not replace semantic reading. Read each returned row/segment before deciding.

## Approved preview exemplars
After user approval, corrected/approved preview examples are binding semantic guidance unless the user later changes the business rules.
Apply their meaning consistently to paraphrases and formatting variants; do not require exact wording.

## REVIEW vs TAXONOMY_GAP
Use `REVIEW` only when the row itself is genuinely unresolved because of ambiguity, missing essential context, unintelligible source, or materially indistinguishable choices.

Use `TAXONOMY_GAP` when the meaning is clear but no approved label covers it.
A taxonomy gap is a setup problem and blocks export until repaired.

## Empty rows
If all primary source columns are empty, leave output blank. Do not mark REVIEW.

## Single label
Choose the one label best supported by the target purpose and definitions.

## Multi label
Return every materially supported label, but avoid weak/incidental labels.

## Context
Context may disambiguate source meaning but must not override an explicit source statement without a clear reason.
Do not supply a missing subject or process merely from the dataset's general domain. A wait or delay with no indication of what was awaited does not by itself establish delivery, support or returns. Use a permitted general-experience category when it fits; ask for essential missing context when it does not.

## Multi-target consistency
Reason about the physical row once, then answer each target independently under its own purpose.
Do not let Topic substitute for Sentiment or vice versa.
Return every pending target in the atomic bundle together.

## Specific labels beat generic fallbacks
If a row clearly matches a specific approved business concept/process, prefer that label over a generic catch-all. A label such as `General Experience` must not absorb a row that clearly describes a return, delivery, payment, card, support, product-fit, or other specifically represented concept. Generic labels are for genuinely general rows, not classifier uncertainty.

## Sentiment from outcomes, not emotion words
Do not require words such as “happy”, “bad”, “great”, or “angry”. Operational outcomes carry sentiment too. A delayed unresolved request, a product that is too small, or discovering the same item elsewhere for half the price can be negative even when phrased factually. Long-term reliability, successful resolution, or “no problems” can be positive without expressive adjectives. Use Neutral only when the content truly lacks a material positive/negative evaluation or outcome.


## Root-cause targets
When `target_type=root_cause`, answer the approved causal question rather than summarizing the whole record. If both a material cause and a downstream outcome are stated, choose the cause. Use the outcome only when no cause is provided. Never infer an unstated cause.

For `open_code_then_group`, the first semantic label should be a concise actionable detail cause; later consolidation produces the reporting group. Grouping must not erase materially different causes merely because they lead to the same outcome.

## Selective evidence
Short evidence excerpts are useful for preview, audit, REVIEW/TAXONOMY_GAP diagnosis, and taxonomy refinement. They are not required as an extra user-visible artifact for every normal row.
