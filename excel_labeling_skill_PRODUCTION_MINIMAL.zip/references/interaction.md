# Interaction Contract

## MCP-only gates
All required user decisions must call the real `ask_user_question` MCP tool. Do not ask these as ordinary chat questions.

Mandatory interaction gates:
1. ambiguous sheet selection;
2. source/context column approval;
3. label-source path when ambiguous;
4. single vs multi-label when not explicitly supplied;
5. per-target setup approval;
6. preview approval — always mandatory;
7. decision after rejected preview;
8. reusable prompt offer.

## No silent fallback
If the MCP tool is unavailable or returns an invalid/empty result at a mandatory gate, stop before crossing the gate. Explain the issue. Never silently turn the same prompt into a normal chat question.

## Explicit answers
A decision may be skipped only where SKILL.md allows it and the user already explicitly supplied that exact setting in the current task. Preview approval can never be skipped.

## Keep it simple
User-facing questions should avoid implementation vocabulary. Prefer one clear semantic decision per interaction unless the tool supports a clearly understandable multi-select.
