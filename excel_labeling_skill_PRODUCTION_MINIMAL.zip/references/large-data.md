# Large Data and Long Text Safety

- Never place the complete large dataset into the conversation context at once.
- Runtime work retrieval must remain bounded internally.
- Do not expose or ask the user about work-unit sizes.
- Preserve stable physical-row identity throughout processing.
- Model outputs should contain only unit IDs and label decisions, not repeated source text.
- Never silently truncate text used for a final classification.
- Long rows are split internally. Segment decisions are semantic signals, not final labels.
- Finalize a long row only after every required segment has been processed and aggregate work is available.
- Preview excerpts/summaries are display-only.
- Validate completeness, source integrity, and label legality before export.
