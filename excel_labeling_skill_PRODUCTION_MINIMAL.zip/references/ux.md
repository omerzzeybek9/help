# UX Guidance for Branch and Office Users

The user should feel that the workflow is:
1. choose what to label;
2. confirm how labels work;
3. check a few examples;
4. receive the completed file.

Avoid technical words such as taxonomy, cardinality, batch, chunk, token, schema, row key, state, segment, or JSON.

Prefer short `ask_user_question` interactions with familiar language. Do not narrate internal processing unless the user asks.

When preview input is long, display a short excerpt or 1–2 sentence summary while keeping classification grounded in the full source content.
