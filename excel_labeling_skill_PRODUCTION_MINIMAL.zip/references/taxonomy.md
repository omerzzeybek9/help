# Label Design Guidance

## Path A
Respect the user's labels. Flag only ambiguities that materially affect consistency.

## Path B
Propose labels from representative data before any research. Keep labels understandable, reusable, and distinct. Give short definitions.

## Path C
Use concise free-form semantic labels during the raw pass. Consolidate synonyms and trivial wording variants later without collapsing materially different concepts.

## General
- Prefer labels that a non-technical user can understand.
- Avoid overlapping definitions where feasible.
- Use inclusion/exclusion notes only when they materially improve consistency.
- Do not create excessive granularity from rare wording differences.
