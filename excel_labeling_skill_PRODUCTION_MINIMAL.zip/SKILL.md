---
name: excel-labeling
version: 1.1.0
description: Approval-driven Excel/CSV labeling for non-technical users. Supports user-provided labels, data-driven label proposals, and free-form labeling with consolidation; uses ask_user_question MCP for all required user decisions and safely handles large files and long text.
---

# Excel Labeling

## Mission
Label Excel/CSV data quickly and accurately while making the experience simple enough for branch and office users who do not know labeling, AI, batching, token limits, schemas, or data-processing internals.

The agent owns semantic decisions and user interaction.
The runtime owns file inspection, stable row identity, bounded data access, long-text handling, state, validation, and export.

The user should experience a short guided workflow, not a technical configuration process.

---

# 1. Non-negotiable interaction contract

`ask_user_question` is an MCP tool in this environment.

For every required decision or approval gate in this skill, invoke the real `ask_user_question` MCP tool using its available schema.

**Do not replace a required MCP question with a normal chat question.**
**Do not merely print suggested options in prose and continue.**
**Do not infer an approval from silence, a previous unrelated answer, or your own judgment.**

A required gate is satisfied only when either:
1. the user already explicitly supplied that exact decision in the current task, and the workflow says the gate may be skipped; or
2. a valid response is returned by `ask_user_question`.

Preview approval is never skippable. It must come from `ask_user_question`, even if the user asked to label the whole file immediately.

## Required MCP gates
Use `ask_user_question` for these decisions when they are not already explicitly supplied:

1. Which sheet to process, only if multiple relevant sheets are ambiguous.
2. Which source column(s) should drive each labeling target.
3. Which label-source path to use when ambiguous:
   - user has a ready label list;
   - propose labels from the data;
   - free-form labels, then consolidate.
4. Whether each target is single-label or multi-label.
5. Per-target setup approval: source columns + output column + label set/rules.
6. Preview approval before full-file labeling. **Always required.**
7. Any user choice after a rejected preview.
8. Whether to create a reusable prompt at the end.

If `ask_user_question` is unavailable or fails at a required gate, stop before crossing that gate and explain that the interactive question tool is unavailable. Do not silently fall back to ordinary chat for the required decision.

## Question UX
Keep questions short and plain-language.
Do not expose terms such as taxonomy, cardinality, batch, chunk, token, state machine, row key, schema, or segment.

Prefer user-facing wording such as:
- “Hangi sütun etiketlensin?”
- “Etiketleri nasıl belirleyelim?”
- “Her satırda tek etiket mi olsun, birden fazla etiket olabilir mi?”
- “Bu etiketler ve kurallar uygun mu?”
- “Örnekler uygun. Tüm dosyaya uygulayayım mı?”

When the MCP tool supports structured choices, use them. Use multi-select only where multiple selections are genuinely valid, such as choosing source/context columns.

Do not ask several technical questions that can be inferred from the file. Group closely related choices only when the MCP tool and UX make the result unambiguous.

---

# 2. Core principles

1. Make the workflow easy for non-technical users.
2. Ask only for semantic choices; infer technical details from the file.
3. Required choices and approvals use `ask_user_question` MCP, never plain-chat substitutes.
4. Never label the full file before MCP preview approval.
5. Never perform external research by default.
6. Never silently truncate source text used for final classification.
7. Preserve original rows, columns, order, and values in the exported file.
8. Keep source-to-label alignment deterministic via runtime row identity, not copied text.
9. Handle large files in bounded internal work units without exposing this to the user.
10. For unusually long rows, analyze all required source segments before finalizing the row.
11. Validate completeness and label legality before export.
12. Do not add confidence/evidence/debug/status columns unless the user explicitly asks.
13. Respond in the user's language unless they request another language.
14. Never ask the user to configure processing size, token limits, row IDs, JSON, or runtime parameters.
15. Do not ask the user to repeat information already explicitly supplied.

---

# 3. Supported label-source paths

Every labeling target uses exactly one path.

## Path A — User-provided labels
Use the user's label list as the starting label set.
Do not research each label.
Do not replace the user's labels merely because you would choose different names.

You may identify obvious duplicates or overlaps and ask for a correction if the ambiguity materially changes labeling quality.

## Path B — Propose labels from the data
Inspect representative source rows and propose a concise, reusable label set with one-line definitions.

The proposal must be approved for that target before preview labeling.
Do not perform research merely to validate labels you proposed from the data.

## Path C — Free-form labels
Create concise semantic labels without a fixed initial label list.
After raw labeling completes, consolidate synonymous and near-duplicate labels into a stable final vocabulary.

Do not force an artificial global label set during the first pass.

---

# 4. End-to-end state machine

Follow this order unless a skippable decision was already explicitly supplied.

```text
input
  -> inspect file
  -> resolve sheet if ambiguous [MCP if needed]
  -> propose/confirm source columns [MCP]
  -> resolve label source A/B/C [MCP if ambiguous]
  -> resolve single/multi [MCP unless explicit]
  -> build per-target setup
  -> per-target setup approval [MCP]
  -> initialize DRAFT job
  -> label representative preview
  -> show preview
  -> preview approval [MCP, mandatory]
       -> rejected: revise and preview again
       -> approved: runtime unlock
  -> full labeling
  -> Path C consolidation
  -> validation
  -> export
  -> offer reusable prompt [MCP]
```

Never jump from file inspection directly to full labeling.
Never treat “please label this file” as permission to skip the preview approval gate.

---

# 5. Input handling

## Excel / CSV
Inspect first:

```bash
python scripts/excel_labeling.py inspect INPUT [--sheet SHEET]
```

Use the profile to learn:
- sheet names;
- row count;
- column names;
- non-empty rates;
- text-length distribution;
- likely text/category/ID columns;
- long-text risk.

Do not ask for facts the file already reveals.

If multiple sheets are plausibly relevant and intent is unclear, use `ask_user_question` MCP to select the sheet.

## Pasted data
Small pasted datasets may be labeled in chat.

If the user is about to paste hundreds of rows, or the content is already large enough to create context risk, warn them before they continue. Prefer wording like:

> Çok sayıda satırı sohbete yapıştırmak bazı satırların gözden kaçmasına veya bağlamın bozulmasına yol açabilir. Mümkünse Excel/CSV dosyasını yüklemek daha güvenilir olur.

Do not refuse solely because data was pasted.

---

# 6. Choose source and output columns

Inspect the data and recommend likely source column(s). Do not silently use every column.

Distinguish:
- **primary source columns**: content that determines the label;
- **optional context columns**: useful supporting information;
- **output column**: new column where the final label is written.

Use `ask_user_question` MCP to obtain column approval.

If the task contains multiple independent labeling targets, handle approval per target so the user understands what each output column means.

Do not use unrelated columns merely because they exist.

---

# 7. Resolve single-label vs multi-label

This is mandatory for every target unless the user explicitly stated it.

Use `ask_user_question` MCP with plain-language choices equivalent to:
- “Her satırda tek etiket”
- “Bir satırda birden fazla etiket olabilir”

Do not infer this setting purely from the data.

---

# 8. Label proposal and per-target approval

## Path A
Show the user's label list with concise definitions if definitions are known or necessary.
Do not invent elaborate rules unless needed.

## Path B
Sample representative rows:

```bash
python scripts/excel_labeling.py sample INPUT --columns COL1 [COL2 ...] --count 5 [--sheet SHEET]
```

Use a small representative sample to propose a concise label set.
Prefer labels that are:
- mutually understandable;
- reusable across the dataset;
- distinct enough to apply consistently;
- not unnecessarily granular.

## Path C
Explain briefly that labels will be created from the data and similar labels will be merged afterward. Do not expose implementation mechanics.

## Approval card
For each target, show only what the user needs:
- source column(s);
- output column;
- label list + short definitions for Path A/B;
- single/multi rule.

Then invoke `ask_user_question` MCP.

Useful choices are equivalent to:
- “Uygun, devam et”
- “Etiketleri/kuralları değiştireceğim”
- “Bu sütun için araştır”

Do not initialize the labeling job until required per-target approval is obtained.

---

# 9. Research policy — strict

Research is an exception, not a default step.

For each target/column:
- If the user approves it -> continue directly. **Do not research.**
- If the user provides a correction -> apply it. **Do not research unless explicitly requested.**
- If the user explicitly requests research -> tell the user that research will be performed for that target, then research only that unresolved target.
- Do not research approved targets.
- Do not research other columns because one target required research.
- If research was not explicitly requested for a target, continue without research.

This policy implements the required behavior: first ask the user about suggested labels/column suitability; proceed directly when all are approved; research only unresolved targets explicitly marked for research, and tell the user before doing it.

If research tools are unavailable, mention the limitation only when the user explicitly requested research.

---

# 10. Initialize the runtime job

After all required setup approvals have been obtained through `ask_user_question`, write a config file internally and initialize:

```bash
python scripts/excel_labeling.py init INPUT \
  --job-dir JOB \
  --config CONFIG.json \
  --setup-approval-source ask_user_question \
  [--sheet SHEET]
```

The user must never be asked to create or edit this config.

Runtime initialization should fail if the setup approval source is missing or is not `ask_user_question`.

---

# 11. Representative labeling preview

Start a small preview, normally 3–5 representative rows:

```bash
python scripts/excel_labeling.py preview-start --job-dir JOB --count 5
```

Retrieve preview work:

```bash
python scripts/excel_labeling.py preview-next --job-dir JOB
```

Submit semantic decisions:

```bash
python scripts/excel_labeling.py submit --job-dir JOB --stdin
```

Continue until preview work is complete, then retrieve results:

```bash
python scripts/excel_labeling.py preview-results --job-dir JOB
```

## Long input in preview
If the displayed input is long, show a 1–2 sentence summary or short excerpt to the user.

Critical rule:
**The displayed summary/excerpt is only for preview readability. The actual label must have been derived from complete-source processing. Never re-classify from the summary.**

Show a small table such as:

| Örnek | Önerilen etiket |
|---|---|
| kısa giriş veya 1–2 cümle özet | Kart Sorunu |

Then invoke `ask_user_question` MCP with choices equivalent to:
- “Örnekler uygun, tüm dosyaya uygula”
- “Etiketleri/kuralları değiştir”
- “Başka örnekler göster”

### Mandatory preview gate
Preview approval can never be inferred or skipped.

Only after the MCP tool returns explicit approval, unlock the job:

```bash
python scripts/excel_labeling.py approve-preview \
  --job-dir JOB \
  --approval-source ask_user_question
```

The runtime must reject full-file work when this approval has not occurred.

If the user rejects the preview:
- do not approve the job;
- apply requested changes;
- recreate/revise the draft configuration as needed;
- show a new preview;
- ask again through `ask_user_question`.

For Path A/B, fixed label names stay frozen after preview approval unless the user explicitly changes them and approves a new preview.

---

# 12. Full labeling execution

After runtime approval:

```bash
python scripts/excel_labeling.py next --job-dir JOB
```

The runtime returns bounded internal work items.
Do not mention batch/chunk/token/packet mechanics to the user unless they explicitly ask how the system works.

## Normal rows
For `mode: row`, classify from the complete source content provided for that work item.
Return only the decision object needed by the runtime: unit ID + final label(s), not a copy of the input text.

## Long rows
For `mode: segment`, analyze that source segment and return short semantic signals, not a final row label.

After every required segment is processed, the runtime emits `mode: aggregate` with the combined segment signals. Only then choose the final row label(s).

Never assign a final label from only the visible prefix of an unusually long source cell.

If complete source content cannot be handled reliably, mark the row for review instead of guessing.

---

# 13. Labeling decision rules

## Fixed label set — Path A/B
Return only approved labels.

### Single-label
Choose one best supported approved label.
If a meaningful fallback such as `Other` exists, use it according to its definition.
If no label can be chosen without guessing and no fallback applies, mark the row for review.

### Multi-label
Return every approved label materially supported by the full row.
Do not add weakly related labels merely because a keyword appears.

## Free-form — Path C
Create short, reusable semantic labels.
Prefer stable noun phrases over full sentences.
Avoid trivial wording drift where possible, but do not force a global label vocabulary during the raw pass.

---

# 14. Free-form consolidation — Path C only

After raw labeling completes:

```bash
python scripts/excel_labeling.py consolidation-next --job-dir JOB
```

Map synonymous/near-equivalent raw labels to canonical labels and submit:

```bash
python scripts/excel_labeling.py consolidation-submit --job-dir JOB --stdin
```

Consolidation must:
- merge synonyms and trivial wording variants;
- keep materially different concepts separate;
- preserve user-requested distinctions;
- avoid overly broad catch-all labels.

If consolidation materially changes the vocabulary and a user decision is needed, show a concise representative mapping and use `ask_user_question` MCP. Do not dump hundreds of mappings to the user.

---

# 15. Validation

Always validate before export:

```bash
python scripts/excel_labeling.py validate --job-dir JOB
```

Required checks include:
- setup approval source is recorded as `ask_user_question`;
- preview approval source is recorded as `ask_user_question`;
- every non-empty target row has a final result or explicit review state;
- no unknown IDs or duplicate final decisions;
- fixed-label results use only approved labels;
- single-label targets do not contain multiple labels;
- original source file has not changed;
- long rows are finalized only after all required segments are analyzed;
- Path C labels are fully consolidated before export.

If validation fails, repair only the affected work. Do not silently change the approved labels/rules just to pass validation.

---

# 16. Export

Export only after validation passes:

```bash
python scripts/excel_labeling.py export --job-dir JOB --out OUTPUT.xlsx
```

Default behavior:
- preserve original columns;
- preserve original row order and values;
- preserve other workbook sheets;
- append one label column per target;
- join multi-label output with `; `;
- use `REVIEW` only for genuinely unresolved rows;
- do not expose internal row IDs, segment IDs, debug state, or runtime metadata.

---

# 17. Final response and reusable prompt

Keep the completion message concise and non-technical. Include:
- what was labeled;
- completed row count;
- review count if any;
- output file/link.

Then invoke `ask_user_question` MCP to offer a reusable prompt, equivalent to:

> “Aynı kuralları daha sonra tekrar kullanmak için hazır bir prompt oluşturmamı ister misiniz?”

Only create the reusable prompt if the user accepts.

The reusable prompt should contain:
- source column(s);
- approved labels and definitions for Path A/B;
- single/multi rule;
- important inclusion/exclusion rules;
- expected output column;
- instruction to show a small preview and obtain approval before full labeling.

Do not include runtime mechanics, job directories, segmentation, or implementation details in the reusable prompt.

---

# 18. Failure behavior

If a deterministic file/runtime error occurs:
- do not guess;
- do not rewrite the source file;
- explain the specific problem in user-friendly language;
- preserve completed valid work where possible.

If the file format is unsupported, ask for XLSX or CSV.

If the user changes labeling rules after full labeling has started, treat that as a configuration change. Show and approve a new small preview through `ask_user_question` before applying the changed rules to the file.

If a required MCP interaction fails, stop at that gate rather than continuing with an assumed answer.

---

# 19. Internal references

Read only when relevant:
- `references/interaction.md` — mandatory MCP gates and user interaction rules
- `references/large-data.md` — bounded processing and long-text safety
- `references/taxonomy.md` — label design and consolidation guidance
- `references/ux.md` — non-technical user experience patterns
