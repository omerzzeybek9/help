# Data-Driven Discovery Strategies

## Principle

Skill hiçbir sektör veya target için hazır kategori adı sağlamaz. Kategori/etiket adları yalnız iki kaynaktan gelebilir:
1. kullanıcının açık hazır listesi (`label_source: user`);
2. mevcut dosyanın verisinden yapılan keşif (`label_source: proposed` veya `freeform`).

Target type yalnız semantic soruyu açıklar; kendi başına vocabulary belirlemez.

## Derived strategy

| Label source | Default strategy |
| --- | --- |
| `user` | `fixed` |
| `proposed` | `taxonomy_discovery` |
| `freeform` + causal/root-cause purpose | `open_code_then_group` |
| other `freeform` | `freeform` |

## `fixed`
Kullanıcı gerçekten hazır bir vocabulary verdiyse kullan. Etiket ekleme, yeniden adlandırma veya veriden başka liste uydurma.

## `taxonomy_discovery`
1. Mevcut veriden çeşitli discovery sample al.
2. Tekrarlayan semantic anlamları çıkar.
3. Birbirinden ayrışan, iş amacına uygun aday etiketleri oluştur.
4. Farklı satırlardan coverage sample al.
5. Material recurring gap/overlap varsa listeyi düzelt.
6. Kullanıcıya veriyle oluşturulan final öneriyi bir kez göster.

Hazır sektör kategorileri, geçmiş dosya taxonomy'si veya skilldeki örnekler keşif yerine geçmez.

## `open_code_then_group`
Serbest semantic detail kodlarını mevcut satırlardan üret. Ardından yalnız gerçekten aynı/çok yakın anlamları grupla. Farklı nedenleri aynı sonucu verdikleri için birleştirme.

## `freeform`
Kullanıcı açık semantic codes istiyorsa satır anlamından concise etiket üret; trivial wording varyantlarını sonradan birleştir.

## Rules
- User-provided vocabulary wins unless the user asks to redesign it.
- Proposed labels are always current-data-derived.
- Fuzzy string similarity semantic eşdeğerlik değildir.
- Approved taxonomy bir anlamı kapsamıyorsa en yakın kategoriye zorlamak yerine `TAXONOMY_GAP` kullan.
