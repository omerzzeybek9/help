# Hierarchical Labeling: Detail + Group

## When to use
Use hierarchical output only when the approved business question benefits from both a fine-grained semantic detail and a stable reporting group. Do not introduce this structure merely because the runtime supports it.

## Principle
The detail code is produced from the current row meaning. Group labels are formed from the current dataset's detail codes or from a user-provided vocabulary. No group name is built into the skill.

For causal work, prefer an explicitly stated cause over its downstream outcome. If the text states no cause, do not invent one.

## Runtime representation
Detail + group currently supports one detail code per row. Use a freeform target with `raw_output_column` and `output_column`; names shown below are placeholders, not recommended headings:

```json
{
  "name": "<onayli_boyut>",
  "target_type": "root_cause",
  "label_source": "freeform",
  "cardinality": "single",
  "purpose": "<onayli_is_sorusu>",
  "source_columns": ["<gercek_sutun>"],
  "raw_output_column": "<detay_sutunu>",
  "output_column": "<grup_sutunu>"
}
```

Full labeling emits the fine/detail code. Consolidation maps raw detail codes to canonical groups derived from the current data. Export writes both columns when configured.

## Grouping rules
- Group by shared semantic meaning, not string similarity.
- Preserve materially different meanings even if they share an outcome.
- Merge synonyms/trivial wording variants.
- Do not bury recurring meaningful concepts in a catch-all.

The user should not see open-coding batches or internal mappings; only the approved output structure and preview.
