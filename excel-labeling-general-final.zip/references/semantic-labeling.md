# Semantic Labeling Contract

## Contents

1. Model decides meaning; code does not
2. Meaning over words
3. Sentiment / evaluative targets
4. Work provenance
5. Approved preview exemplars
6. REVIEW vs TAXONOMY_GAP
7. Empty rows
8. Single label
9. Multi label
10. Context
11. Multi-target consistency
12. Specific labels beat generic fallbacks
13. Sentiment from outcomes, not emotion words
14. Root-cause targets
15. Selective evidence

## Model decides meaning; code does not
Semantic labels must be decided by the model from the actual source/context returned in the current runtime payload.

**Forbidden for semantic decisions:**
- generated Python classifiers;
- `if "word" in text` rules;
- regex/substring/phrase matchers;
- keyword dictionaries used as label-selection logic;
- lookup tables created from observed rows;
- programmatic heuristics that inspect source text and choose a semantic label;
- scripts that read work payloads and automatically emit labels.

Do not create custom helper scripts during semantic work, even merely to bulk-assemble decisions from work rows. The provided runtime CLI already handles deterministic transport and validation. Read the bounded payload directly, decide labels as the model, and submit those decisions through the runtime contract.

The same rule applies to audit: do not reuse a production classifier script/helper, cached semantic decision, or generated rule engine. Audit requires fresh model reasoning from the hidden-label audit payload.

## Meaning over words
Classify from the meaning of the complete source plus approved context.

A keyword can be evidence, but:
- its absence does not exclude a label;
- its presence does not force a label.

Examples:
- “The order arrived the next day” can mean Delivery without saying “shipping”.
- “The courier was not the problem; the product itself was broken” should not automatically become Delivery.

## Evaluative targets
When the approved target asks for an evaluation, attitude, satisfaction, tone or similar meaning:
- use only the approved labels and their current definitions; the skill supplies no default vocabulary;
- judge the overall stated evaluation/outcome, not isolated courtesy words;
- numeric ratings have no automatic mapping unless the user approved one;
- preserve negation, irony and materially conflicting signals;
- factual wording can still express a clear evaluation through the stated outcome;
- do not invent an evaluative class that is absent from the approved data-derived/user vocabulary.

User corrections override generic interpretation guidance and become binding exemplars.

## Work provenance
Never label a row from its row number, prior distribution, a remembered pattern, or an assumed repetitive structure.
Only label source content actually present in the current runtime work payload.

Runtime lease/hash proves delivery; it does not replace semantic reading. Read each returned row/segment before deciding.

## Approved preview exemplars
After user approval, corrected/approved preview examples are binding semantic guidance unless the user later changes the business rules.
Apply their meaning consistently to paraphrases and formatting variants; do not require exact wording.

## REVIEW vs TAXONOMY_GAP
Use `REVIEW` only when the row itself is genuinely unresolved because of ambiguity, missing essential context, unintelligible source, or materially indistinguishable choices.

Use `TAXONOMY_GAP` when the meaning is clear but no approved label covers it.
A taxonomy gap is a setup problem and blocks export until repaired.

## Empty rows
If all primary source columns are empty, leave output blank. Do not mark REVIEW.

## Single label
Choose the one label best supported by the target purpose and definitions.

## Multi label
Return every materially supported label, but avoid weak/incidental labels. A repeated legal boilerplate clause is a topic only if it falls within the approved scope as a substantive obligation; frequency alone neither includes nor excludes it.

## Context
Context may disambiguate source meaning but must not override an explicit source statement without a clear reason.
Do not supply a missing subject or process merely from the dataset's general domain. A wait or delay with no indication of what was awaited does not by itself establish delivery, support or returns. Use a permitted general-experience category when it fits; ask for essential missing context when it does not.

## Multi-target consistency
Reason about the physical row once, then answer each target independently under its own purpose.
Do not let one approved target substitute for another; answer each target under its own purpose and label definitions.
Return every pending target in the atomic bundle together.

## Specific labels beat generic fallbacks
If a row clearly matches a specific approved business concept/process, prefer that label over a generic catch-all. A label such as `General Experience` must not absorb a row that clearly describes a return, delivery, payment, card, support, product-fit, or other specifically represented concept. Generic labels are for genuinely general rows, not classifier uncertainty.

## Evaluation from meaning, not keywords
Do not require emotion words or use them as deterministic triggers. Operational outcomes, explicit judgments, negation and irony can carry evaluative meaning. Map that meaning only to the approved data-derived/user labels for the current target.


## Root-cause targets
When `target_type=root_cause`, answer the approved causal question rather than summarizing the whole record. If both a material cause and a downstream outcome are stated, choose the cause. Use the outcome only when no cause is provided. Never infer an unstated cause.

For `open_code_then_group`, the first semantic label should be a concise actionable detail cause; later consolidation produces the reporting group. Grouping must not erase materially different causes merely because they lead to the same outcome.

## Selective evidence
Short evidence excerpts are useful for preview, audit, REVIEW/TAXONOMY_GAP diagnosis, and taxonomy refinement. They are not required as an extra user-visible artifact for every normal row.
