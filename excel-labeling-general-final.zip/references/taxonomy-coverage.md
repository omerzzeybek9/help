# Taxonomy Coverage and Shape

## Goal
A data-derived taxonomy should cover recurring meanings without hiding material patterns in a catch-all or flattening everything into one broad group.

## Signals

### Configured catch-all share
If the user-approved or data-derived taxonomy contains a catch-all and its share becomes large, inspect recurring meanings inside it. Do not assume a catch-all name; use only the configured label.

### Dominant group
A very large group may be valid or may hide several meanings. Inspect semantic detail before proposing a split.

### Thin groups
Very small groups may indicate needless fragmentation. Merge only when meanings are genuinely compatible.

### TAXONOMY_GAP
For approved/fixed taxonomies, a clear uncovered meaning is `TAXONOMY_GAP`, not REVIEW and not a forced nearest-label match.

## Refinement loop
1. Identify material recurring uncovered meanings.
2. Propose additions/splits/merges only from the current data.
3. Ask the user only when business meaning changes.
4. Re-run coverage checks.
5. Stop when material recurring gaps disappear and further splits would be trivial.

Evidence is useful selectively for preview, audit, review/gap diagnosis and taxonomy refinement; it is not required as user-visible output for every row.
