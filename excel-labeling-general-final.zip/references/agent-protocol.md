# Commands and response formats

Normal execution uses `agent_io.py`. Adapter semantic label seçmez; model kararını kaydeder ve sonraki action'ı döndürür. Low-level next/submit/audit komutlarına normal akışta inme.

## Start

`excel_labeling.py inspect INPUT` içindeki `suggested_config` yalnız şemadır. Target adı, amaç, source/output sütunları ve etiketleri kullanıcı tercihleri ile **mevcut veriden** doldur. Örnek veya skill içinden kategori adı kopyalama.

`label_source`:
- `user`: kullanıcı gerçek hazır etiket listesi verdi;
- `proposed`: etiketler mevcut veriden keşfedildi ve kullanıcı onayladı;
- `freeform`: satır bazında serbest semantic etiket üretilecek, gerekirse sonradan birleştirilecek.

`discovery_strategy` normalde yazılmaz. Runtime şu şekilde türetir: kullanıcı listesi → `fixed`; veriden öner → `taxonomy_discovery`; freeform root-cause → `open_code_then_group`; diğer freeform → `freeform`.

Format örneği yalnız şemadır; angle-bracket değerleri gerçek veri/onayla doldur:

```bash
python scripts/agent_io.py start INPUT --stdin --approval-source ask_user_question <<'JSON'
{"targets":[
 {"name":"<onayli_boyut>","target_type":"custom","purpose":"<is_sorusu>","source_columns":["<gercek_sutun>"],"output_column":"<sonuc_sutunu>","label_source":"proposed","cardinality":"single","labels":[{"name":"<veriden_cikan_etiket>","definition":"<kisa_tanim>"}]}
]}
JSON
```

### 100 kayıt kapsamı

`start` exact kapsamı source columns + filters + visibility ile sayar.

- `labelable_rows <= 100`: job doğrudan açılır; bütün dolu kayıtlar işlenir.
- `labelable_rows > 100`: job **açılmaz** ve `action=confirm_scope`, `required_tool=ask_user_question`, `question`, `options` döner. Soruyu normal mesajla tekrarlama; gerçek MCP ile aç.
- Kullanıcı 100 kayıtlık kapsamı onaylarsa **aynı start stdin** ile komutu yeniden çalıştır ve `--scope-approval-source ask_user_question` ekle. Runtime tam 100 dolu kaydı seçer; kalan kayıtlar dosyada değiştirilmeden kalır.
- Kullanıcı onaylamazsa job başlatma.

Karakter sayısı kapsamı küçültmez. Uzun kayıtlar segment mekanizmasıyla işlenir.

Setup reddedilirse mevcut kullanıcı kararlarından yalnız hatalı payload'ı düzelt ve aynı start'ı yeniden çağır. Farklı sheet/header/visibility seçildiyse `--sheet`, `--header-row`, `--row-scope` kullan.

## Label answers

Work yanıtındaki **tam `answer_format` şablonunu** doldur; `request_id`, `ref` ve target kimliklerini değiştirme:

```bash
python scripts/agent_io.py answer --job-dir JOB --stdin --next <<'JSON'
{"request_id":"RETURNED_ID","answers":[{"ref":"1","labels":["<onayli_etiket>"]}]}
JSON
```

Her cevap slotunda verilen target adı, cardinality ve allowed labels bu slotun tek kaynağıdır. Bir target'ın etiketini başka target'a taşıma. Uzun segmentte `text`i tamamen değerlendir; aggregate final task gelmeden final label verme. Genuine ambiguity: `labels: []`, `review: true`, `review_reason`. Anlam açık ama approved taxonomy kapsamıyorsa `taxonomy_gap=true`, `gap_reason`; ikisini birlikte kullanma.

## Preview

`action=approve_preview` → `python scripts/agent_io.py preview --job-dir JOB`.

Özet istenirse dönen `summary_format`ın tamamını `preview --stdin` ile doldur. Özet yalnız gösterim içindir; label kararını tam kaynak metinden ver. Dönen Markdown'ı göster ve aynı turda gerçek MCP preview onayını aç. Onay sonrası aynı tablonun `preview_id` değerini `approve` komutuna ver.

## Actions

| action | Do |
| --- | --- |
| `confirm_scope` | Dönen soruyu gerçek MCP ile sor; onayda aynı start + `--scope-approval-source ask_user_question` |
| `answer` | Tam kaynaktan semantic karar ver; tam template'i gönder |
| `start_preview` | `agent_io.py work --job-dir JOB` |
| `approve_preview` | Preview tablosu + gerçek MCP onayı |
| `diagnose_audit` | Dönen somut semantic problemi incele; gerekirse business rule kararı al |
| `resolve_input` / `resolve_taxonomy` / `investigate_reviews` | Yalnız belirtilen gerçek boşluğu çöz |
| `finish` | `agent_io.py finish --job-dir JOB --out OUTPUT.xlsx`, sonra iki deliverable'ı paylaş |

Biçim hatasında yeni iş isteme veya refresh etme; aynı request'i doğru formatla düzelt. `work --refresh` yalnız lease expiry veya bilinçli reevaluation içindir. Tek writer kullan.

## Scope and counts

`inspect.rows_to_be_labeled` tahmindir. `start` kesin olarak `selected_rows`, `rows_to_be_labeled`, `blank_rows`, `rows_left_unlabeled`, `total_file_rows` ve `eligible_labelable_rows_total` döndürür. 100 veya daha az dolu kayıt varsa hepsi işlenir. Daha fazlasında yalnız MCP onayından sonra tam 100 dolu kayıt işlenir. Toplam karakter sınırı yoktur.

Finish `labeled_rows`, `review_rows`, `blank_rows`, `outside_scope_rows` döndürür. Bu sayıları tahmin etme.

## Corrections and delivery

Preview correction genel, kişisel veri içermeyen karar kuralıyla saklanır ve reusable prompta eklenir. `action=resolve_approved_examples` gelirse onaylı örnekleri sessizce değiştirme.

Her agent_io yanıtındaki todos envelope gerçek todo aracı varsa kullanılabilir. Satır/batch ilerlemesini sohbete yazma. Sonuçta yalnız `finish.deliverables` içindeki doğrulanmış veri dosyası ve reusable TXT paylaşılır.
