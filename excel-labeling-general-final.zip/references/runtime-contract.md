# Runtime Contract

## Purpose
The runtime is deterministic transport/state/file infrastructure. It does not choose semantic labels. The model reads the bounded source returned by the runtime and decides meaning.

## Target config
A target requires:
- `name`;
- one-sentence `purpose`;
- `source_columns`;
- optional `context_columns`;
- `output_column`;
- `label_source`: `user`, `proposed`, or `freeform`;
- `cardinality`: `single` or `multi`;
- `labels` unless freeform.

No category vocabulary is built into the runtime. If `label_source=proposed`, every label name/definition must have been discovered from the current data and approved by the user. If `label_source=user`, preserve the user's vocabulary. `freeform` starts without a fixed label list.

Valid shape example — placeholders only:

```json
{
  "targets": [{
    "name": "<onayli_boyut>",
    "target_type": "custom",
    "purpose": "<onayli_is_sorusu>",
    "source_columns": ["<gercek_sutun>"],
    "context_columns": [],
    "output_column": "<sonuc_sutunu>",
    "label_source": "proposed",
    "cardinality": "single",
    "labels": [{"name":"<veriden_cikan_etiket>","definition":"<kisa_tanim>","include":[],"exclude":[],"examples":[]}]
  }]
}
```

`target_type` is internal semantic metadata and may be `custom`. It never supplies labels. `discovery_strategy` may be omitted: user vocabulary → fixed; proposed → taxonomy discovery; freeform causal work → open-code/group; other freeform → freeform.

## Scope
Semantic scope is measured by non-empty labelable physical records after approved sheet/header/visibility/filter selection.

- `<=100`: process every labelable record; do not ask a scope question.
- `>100`: `agent_io start` must return `action=confirm_scope` before creating a job. Only a real `ask_user_question` approval authorizes a second identical start with `--scope-approval-source ask_user_question`; that run selects exactly 100 non-empty records.
- Character length is not a scope limiter. Long rows are segmented without silent truncation.

The output always preserves the original file rows. Out-of-scope rows stay unchanged.

## Preview and approval
`start` records the already-obtained setup approval and opens preview work. Preview decisions are model semantic decisions from complete source. Display summaries are separate and never become classification evidence. Corrected preview decisions are durable binding exemplars. A changed taxonomy/source/cardinality requires updated setup approval.

## State and provenance
SQLite stores work/results/leases/audit/repair state. Work carries stable row identity, source hash and lease. Retry is idempotent; one physical row's pending targets are submitted atomically where possible. Exact duplicate reuse requires identical source + approved context under the same target.

## Long text
Long source is segmented deterministically. Every segment is read by the model; notes preserve relevant semantic evidence. Final label is decided only after aggregate work is returned. Segment size/budget changes transport only, never scope.

## REVIEW / TAXONOMY_GAP
`REVIEW`: the source itself is genuinely ambiguous or lacks essential context.
`TAXONOMY_GAP`: meaning is clear but the approved vocabulary does not cover it.
Neither may be used as a speed shortcut.

## Audit and repair
Audit hides production labels and asks the model to re-decide from source and approved rules. It is a consistency check, not accuracy ground truth. Failed audit blocks export. Repair is bounded and followed by fresh audit; repeated unresolved semantic disagreement becomes a concrete diagnostic/business-rule blocker.

## Export
Structural validation, semantic consistency gates, row integrity, approved exemplars and workbook safety must pass before export. Only final verified data file and reusable TXT are deliverables. Internal job/config/audit files are private.
