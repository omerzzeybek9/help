# Conversation flow, plan and delivery

## First question screen

Up to three questions in the first round, together, through the real ask_user_question MCP — and only the ones whose answer is not already known:

1. **Which column to label** — the `labelable_columns` candidates, with your own suggestion marked. Ask this whenever the user has not named the column, even if only one candidate looks like prose.
2. **Which dimensions to label** — options drawn from this file.
3. **Where the labels come from** — a list they provide · proposed from the data · open coding then grouped.

Keep the question titles to two or three words: a long title is truncated mid-word in the interface and the user reads half a label. Put the explanation beside the option, not in the title.

**Ask the third only when no list is in front of you.** A taxonomy file the user attached, a
list pasted into the message, or "label it according to this prompt" already answers it: set
`label_source: user`, take the labels from that source, and do not ask. Putting the file's own
name in one of the options and asking anyway is holding the answer while posing the question.

When no list exists anywhere, ask it — and do not assume the answer. Naming a dimension is not
supplying a list. A user whose reports already run on an existing taxonomy, handed invented
labels, finds out only when the output does not fit — and by then the whole file is labeled.
"They did not mention a list" is an assumption until it is asked. If they answer that they have
one, ask for it in the same breath.

**Single/multi is different and does not belong in this round.** It is your recommendation, and
the right answer can differ by target, so propose it per target from the approved business question and observed data, then let the user change it in setup approval. A preference the user
states explicitly ("use my own list", "label freely", "more than one per row") is authoritative:
keep it and never re-ask it.

Never re-ask an answered preference, and never treat a general label approval as the answer to a question that was never asked.

If the MCP call limit truncates the set, complete the remaining first questions in the immediately following call; do not move on to label proposals or file preparation in between. Do not present question text in a normal message and act as though approval was obtained without the real MCP. Do not ask for technical tools, endpoints, API keys or config files.

## What the approvals mean

The user sees exactly two approvals:

1. Every label's name and one-line definition, the source/output columns to be used, the columns left unused, and the per-target single/multi recommendation, shown together in one table. A dimension name and a count are not enough — nobody can approve a label set they cannot see. Answering *"Bu etiketler ve yapıyla örnekleri hazırlayayım mı?"* approves that structure. There is no separate technical setup approval. If the user adds, drops or renames a label, apply it and re-approve the updated table: a changed set is not an approved set.
2. A genuinely rendered, completed sample table. Approving those samples authorizes processing the announced scope. If exact scope exceeds 100 labelable records, the separate runtime scope confirmation is still required before the job starts.

If the label/column structure was already explicitly approved, do not ask again. If an internal file's format is wrong, fix it from the existing answers; do not ask the user to re-decide. If the structure changes, clarify only what changed. Asking for a label list the user has not yet shared is a missing-information question, not technical setup.

## Samples and delivery

One table: real spreadsheet row, a 1–2 sentence summary, and the labels for each chosen dimension. The summary preserves negation and mixed outcomes; the label decision rests on the complete original text. Actually render the table in the message, then request the real MCP approval in the same turn. Do not narrate the rows before the table, and do not stop with only "awaiting approval".

After sample approval, continue the existing job. Use the returned todos_call; do not wait for a separate progress bar or extra interface. At the end, deliver the Excel and the automatically generated reuse prompt through the real file tool; never deliver internal JSON or the job folder.

## Task plan

Every agent_io CLI response carries todos_tool, todos_call and todos_instruction. Call the real write_todos tool with the runtime's stages and statuses; map argument names only when its advertised schema requires it. Do not construct a second plan from memory. inspect/sample have no job state and do not provide this envelope.

The normal EXPORTED list keeps delivery in progress. Only after both deliverables are actually attached, submit finish.after_delivery_todos_call. That conditional payload completes delivery; exporting alone does not prove attachment. If the todo tool is absent, do not write progress messages.

## Uninterrupted authorized work

Never simulate a background worker or promise progress after ending a turn. Continue authorized work through export and actual attachment. Only a genuine user decision, a user stop request, or a concrete unrecoverable tool/input problem justifies stopping. Required approvals and the audit/export guards remain in force throughout.

Existing job files stay valid across a resumed session: do not re-init an existing job or discard labels in order to "upgrade" it. New jobs use `agent_io start`, whose private config and state live in a system temporary directory. Do not choose a job folder inside the host's attachment/delivery directory, and publish only the two paths in `finish.deliverables`.

The skill cannot change the host model's real limits or guarantee that a host keeps executing indefinitely. Native plan rendering, real MCP answers and file attachment behaviour must be verified in the actual host interface; local fixture tests do not exercise it.

## Research and ready dimensions

Ask the user or propose from the data first. For a genuinely unresolved abstract business concept, give a short heads-up before researching; never carry customer text into external research.

Meanwhile continue preparing samples for the other dimensions. If one dimension must wait for a full decision, get the ready dimensions' label/column structure and samples approved and produce one verified intermediate output. Then process the remaining dimensions from that file in a new job, preserving the existing columns and rows and taking that job's own sample approval. Never present the intermediate file to the user as the final result; deliver once every requested dimension is complete. Do not modify the active job's source file.
