# Quality Gates

## 1. Taxonomy coverage before setup approval
For `label_source: proposed`, discover on a varied sample and test on a different holdout sample.
Check:
- recurring uncovered meanings;
- label overlap;
- vague/catch-all labels;
- boundaries that cannot be applied consistently;
- cross-target redundancy;
- business usefulness.

## 2. Challenging preview
Preview should include ordinary rows plus boundary/implicit/irony/negation/multi-topic/long examples when present.
Use the same physical rows across chosen targets when possible so the user can compare the approved dimensions consistently.

## 3. User corrections are durable
A correction to an existing preview decision must be persisted as a binding approved exemplar via runtime, independent of an expired work lease.
After correction, preview approval is required again.
Explicitly corrected examples are mandatory audit probes. Reserve part of the small audit for records outside the preview; merely rechecking all preview examples does not test production.

If taxonomy/source/cardinality itself changes, start a fresh job instead of mutating old state.

## 4. Structural validation is necessary but insufficient
Row counts, allowed labels, hashes, cardinality, and workbook integrity may all pass while semantics are wrong.
Structural validation must never be described as semantic accuracy.

## 5. Pre-audit triage
The adapter runs the quality report itself after full labeling and surfaces the result in the returned action; `quality-report` is an internal command, not one to call by hand.
- `TAXONOMY_GAP` blocks audit/export and requires setup repair.
- unexpectedly high REVIEW requires diagnosis.
- `label_source: freeform` must complete consolidation before audit.

## 6. Independent semantic consistency audit
Audit gets source/context + approved rules, but not the production label.
The model must classify again from meaning. Do not generate/reuse a Python classifier, keyword rules, cached production decisions, or a helper that auto-selects labels.

The default audit is about 10 target decisions across all targets; required explicit corrections may expand it. It reserves unseen records, then covers the following where the small budget permits:
- user-corrected and approved preview examples;
- dataset timeline;
- predicted label vocabulary, rare labels first;
- context strata where available;
- long text;
- unique content-hash clusters to avoid wasting budget on duplicates.

For `label_source: freeform`, audit the **canonical consolidated labels**, not raw free-form wording.

Audit mismatch is a consistency guardrail, not a claim of ground-truth accuracy. True accuracy comes from human-reviewed golden evaluation sets.

## 7. Repair
On the first audit, observed disagreements within the configured threshold also receive one focused repair through the existing queue, followed by a fresh audit. Later passing audits retain the threshold; any residual disagreement count remains in the final quality result and must not be described as zero. Do not invent an endless zero-mismatch retry loop.

If audit fails, do not export. Repair the affected scope and rerun a **fresh audit**.
If mismatches reveal a business-rule/taxonomy problem rather than execution drift, return to the user through MCP, revise setup, and re-preview.

## 8. REVIEW discipline
REVIEW means genuinely unresolved source, not low confidence or “no keyword match”.
High REVIEW cannot be acknowledged merely to bypass weak labeling rules.

## 9. Golden regression
For releases, distinguish runtime fixtures from human-reviewed semantic fixtures; where available maintain human-reviewed fixtures representing real domains and hard semantic phenomena. At minimum track:
- per-target accuracy;
- joint accuracy for multi-target rows;
- irony/negation/boundary subsets;
- user-correction persistence;
- known-corrupt fixture must fail audit;
- clean fixture must pass.

A skill/runtime change that fixes one failure but regresses an existing golden case is not release-ready.


## 10. Context-safe QA execution
Audit and repair are internal semantic work, not user-visible reports. Never echo audit rows or per-row mismatch decisions into chat. Load phase rules once, process bounded payloads, submit immediately, and rely on runtime state for progress.

The default audit budget is dataset-level and risk-based. Multiple targets must not automatically multiply the audit into a second full labeling pass. For a few hundred ordinary rows, the first audit should normally stay compact while still covering the required strata.

## 11. Progressive repair
The first repair after an audit failure should repair sampled mismatch clusters plus exact duplicates, not the whole target. Run a fresh audit afterward. Broaden only after repeated failure demonstrates a wider drift pattern.


## 12. Repair loop bound
Do not allow unbounded automated audit/repair cycles. The runtime permits at most two automated progressive repair cycles. A further failed fresh audit is an escalation signal, not permission to consume more context by repeatedly relabeling the dataset.


## 13. Taxonomy shape signals
Catch-all share, dominant-group share and thin groups are diagnostic signals, not relabeling rules. Their thresholds, what each one means and how to act on it live in [taxonomy-coverage.md](taxonomy-coverage.md).

