# Labeling Dimensions / Targets

## Principle

Bir satır aynı anda birden fazla bağımsız iş sorusuyla etiketlenebilir. Ancak skill sabit bir boyut listesi sunmaz. Boyut önerileri kullanıcının amacı ve mevcut dosyanın gerçek içeriğinden çıkarılır.

## Generic request

Kullanıcı yalnız “etiketle” gibi genel bir talep verirse:
1. muhtemel source sütunlarını inspect/sample ile oku;
2. satırların gerçekten cevaplayabildiği birkaç iş sorusunu çıkar;
3. yalnız bu veriyle desteklenen boyutları `ask_user_question` içinde öner;
4. kullanıcının seçmediği veya verinin cevaplamadığı boyutu ekleme.

Runtime içindeki `target_type` alanı semantic davranışı açıklayan metadata'dır; kullanıcıya gösterilecek hazır kategori/boyut listesi değildir. Uygun tip yoksa `custom` kullan.

## Multiple targets

Her seçilen boyut kendi purpose, source/context columns, output column, label source, cardinality ve approved labels/rules bilgisine sahiptir. Kullanıcı ortak tek/çoklu tercih belirtmediyse her target için veriye ve iş amacına göre ayrı öner ve setup tablosunda onaylat.

## Avoid over-suggesting

Kullanıcının işini çözmeyen ekstra boyutlar ekleme. Basit etiketleme isteğini analytics workshop'a çevirme.
