# Label Discovery and Design

## Beş etiketleme prensibi

Etiket seti önerirken ve serbest etiketleri birleştirirken **önce bunlara bak.** Bir set bu
beşini karşılamıyorsa kullanıcıya götürmeden düzelt.

**1 · Etiketler net olmalı.** Etiket tek başına okunduğunda hangi ihtiyacı temsil ettiği mümkün
olduğunca anlaşılmalı. Ölçüt basit: etiketi tanımı olmadan gören biri onu doğru satıra
uygulayabilir mi? Aşırı genel veya belirsiz adlar bu ölçütü geçmez.

**2 · Granülite dengeli olmalı.** Ne gereğinden detaylı ne de iş ihtiyacını karşılamayacak kadar
yüzeysel. İki sorunun ikisi de "evet" olmalı: bu etiket bir karar değiştirir mi, ve bu etikete
düşen satırlar birbirine gerçekten benzer mi? Tek satıra özel bir etiket birinciyi, her şeyi
yutan bir etiket ikinciyi kaybeder.

**3 · Kapsamlar çakışmamalı.** Kategorilerin karar sınırları mümkün olduğunca ayrışmalı. İki
etiket aynı satıra eşit derecede uyuyorsa sınır yok demektir — ya tanımı keskinleştir ya ikisini
birleştir. Çoklu etiketlemede aynı satırın iki farklı konuyu gerçekten içermesi çakışma hatası değildir. Aynı kavramı iki etiketle ifade eden çakışma çünkü sessizdir: her satır etiketlenir, dağılım makul
görünür, ama aynı satır iki farklı çalışmada iki farklı etiket alır.

**4 · Düşük frekanslı kategoriler gruplanmalı.** Yeterli hacmi olmayan konular gerektiğinde daha
anlamlı bir üst kategori altında toplanmalı. Az görülmesi tek başına birleştirme gerekçesi değildir; iş açısından önemli nadir olayları ve farklı nedenleri koru.

**5 · Catch-all kullanılıyorsa tek ve açık olmalı.** Aynı boyutta birden fazla belirsiz catch-all
etiketi oluşturma. Catch-all adı skill tarafından verilmez; gerekiyorsa veriden önerilir veya
kullanıcının vocabulary'sinden gelir.

Kullanıcının verdiği liste bu prensiplere uymuyorsa **kendiliğinden değiştirme** — onun
kelime dağarcığı geçerlidir. Yalnız tutarlılığı somut olarak bozan çakışmayı söyle, kararı ona
bırak.

---

*Aşağısı yönteme dair teknik ek — İngilizce, diğer referanslarla aynı dilde.*

## Proposed labels from data
Use two varied samples:
1. discovery sample;
2. fresh coverage sample.

Start with 5 varied short records, or 2–3 long records, then a disjoint coverage sample. Expand when new material meanings appear; do not treat the initial small sample as proof of coverage. Keep each retrieval bounded, choose only relevant columns, and use the existing sample command. Row-count-based quotas must not force dozens of full transcripts into context. Discovery excerpts are not final labeling evidence.

A useful taxonomy has:
- coverage;
- distinct boundaries;
- repeatable semantics;
- business usefulness;
- parsimony.

Refine internally until fresh samples stop revealing material recurring gaps.

## Fixed label specification
For each label keep only what is needed for stable semantics:
- name;
- short definition;
- include situations;
- exclude nearby meanings;
- examples when useful.

These are semantic boundaries, not keyword rules.

## Free-form + consolidation
Create concise semantic noun phrases from the actual row meaning.
Then merge synonyms/trivial variants without merging materially different concepts.

For root-cause `open_code_then_group`, raw labels are detail codes and canonical labels are reporting groups.

## Cross-target orthogonality
Targets should answer genuinely different approved business questions. Avoid labels that merely duplicate another target's meaning. The distinction comes from each target's approved purpose and current-data-derived definitions, not from a built-in list of target names.
