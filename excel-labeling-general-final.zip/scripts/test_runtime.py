#!/usr/bin/env python3
"""Regression tests for the properties that fail silently.

Run:  python scripts/test_runtime.py

Every test here exists because the failure it guards produces a plausible-looking
result rather than an error: labels bound to the wrong column, labels written to
the wrong row, a row count promised to the user that the run does not deliver.
Those are invisible in the output and only surface when someone checks the data
by hand, which is exactly what a test is for.

No third-party test runner: this has to stay runnable wherever the skill is.
"""
from __future__ import annotations
import csv, json, os, subprocess, sys, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import excel_labeling as rt  # noqa: E402

FAILURES: list[str] = []
PASSES = 0


def check(name: str, got, expected) -> None:
    global PASSES
    if got == expected:
        PASSES += 1
        print(f"  ok    {name}")
    else:
        FAILURES.append(f"{name}: beklenen {expected!r}, gelen {got!r}")
        print(f"  FAIL  {name}: beklenen {expected!r}, gelen {got!r}")


def run(*args, stdin: str | None = None) -> tuple[int, str]:
    p = subprocess.run([sys.executable, *args], input=stdin, capture_output=True,
                       text=True, cwd=str(HERE.parent))
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def write_csv(path: Path, rows: list[list]) -> Path:
    with open(path, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(rows)
    return path


# ---------------------------------------------------------------- 1. columns
def test_column_resolution() -> None:
    """A header NAME must beat a cell reference of the same spelling.

    Survey exports really are headed C1/C2/C3, which collides with the refs this
    code assigns to CSV columns. Losing that race binds the whole run to the
    wrong text and nothing downstream can notice.
    """
    print("\n1. sutun cozumleme")
    check("header 'B' beats ref B",
          rt.resolve_columns(["B", "Yorum"], ["A", "B"], ["B"]), [0])
    check("header 'C1' beats ref C1",
          rt.resolve_columns(["Soru2", "C1"], ["C1", "C2"], ["C1"]), [1])
    check("ref still resolves when no header matches",
          rt.resolve_columns(["id", "yorum"], ["C1", "C2"], ["C2"]), [1])
    check("plain header name",
          rt.resolve_columns(["id", "yorum"], ["C1", "C2"], ["yorum"]), [1])
    try:
        rt.resolve_columns(["yorum", "yorum"], ["C1", "C2"], ["yorum"])
        check("duplicate header rejected", "no error", "COLUMN_AMBIGUOUS")
    except SystemExit as e:
        check("duplicate header rejected", "COLUMN_AMBIGUOUS" in str(e), True)
    try:
        rt.resolve_columns(["a", "b"], ["C1", "C2"], ["yok"])
        check("unknown column rejected", "no error", "COLUMN_NOT_FOUND")
    except SystemExit as e:
        check("unknown column rejected", "COLUMN_NOT_FOUND" in str(e), True)


# ------------------------------------------------------------- 2. header row
def test_header_detection() -> None:
    """A header cannot sit below a populated row.

    One ragged line (a stray delimiter) used to outscore the real header, and the
    export then wrote a column NAME into that data row, destroying it.
    """
    print("\n2. baslik satiri")
    with tempfile.TemporaryDirectory() as d:
        p = write_csv(Path(d) / "ragged.csv", [
            ["id", "yorum", "durum"],
            [1, "kargo gecikti", "Sikayet", "fazladan alan"],
            [2, "urun bozuk"],
            [3, "tam satir", "Memnun"],
        ])
        check("ragged row does not become the header",
              rt.detect_header_row(p)["header_row"], 1)
        p2 = write_csv(Path(d) / "titled.csv", [
            ["2024 Musteri Raporu"], [], ["id", "yorum"], [1, "kargo gecikti"],
        ])
        check("real header found under a title row",
              rt.detect_header_row(p2)["header_row"], 3)


# --------------------------------------------------------------- 3. scope cap
def test_scope_rule() -> None:
    """100 or fewer labelable rows are all processed; >100 needs real scope approval.

    Character volume must never reduce the 100-record scope.
    """
    print("\n3. kapsam kurali")
    with tempfile.TemporaryDirectory() as d:
        # >200k source chars in exactly 100 records: all 100 must still be selected.
        long_text = "x" * 2600
        p = write_csv(Path(d) / "hundred.csv",
                      [["id", "yorum"]] + [[i, long_text + str(i)] for i in range(1, 101)])
        cfg = json.dumps({"targets": [{
            "name": "Boyut", "target_type": "custom", "purpose": "Verideki onayli anlami belirle",
            "source_columns": ["yorum"], "output_column": "Etiket",
            "label_source": "user", "cardinality": "single",
            "labels": [{"name": "A", "definition": "a"}]}]})
        code, out = run("scripts/agent_io.py", "start", str(p), "--stdin",
                        "--approval-source", "ask_user_question", stdin=cfg)
        check("100 long rows start succeeds", code, 0)
        if code == 0:
            doc=json.loads(out)
            check("all 100 labelable rows selected", doc.get("rows_to_be_labeled"), 100)
            check("no character cap reduces scope", doc.get("scope_capped_to_100"), False)

        # 101 non-empty records: first start must not create a job.
        p2 = write_csv(Path(d) / "hundred_one.csv",
                       [["id", "yorum"]] + [[i, f"kayit {i}"] for i in range(1, 102)])
        code, out = run("scripts/agent_io.py", "start", str(p2), "--stdin",
                        "--approval-source", "ask_user_question", stdin=cfg)
        check("101 rows returns scope confirmation", code, 0)
        if code == 0:
            doc=json.loads(out)
            check("scope confirmation action", doc.get("action"), "confirm_scope")
            check("no job before scope approval", "job_dir" in doc, False)
            check("exact labelable count exposed", doc.get("scope",{}).get("labelable_rows"), 101)

        code, out = run("scripts/agent_io.py", "start", str(p2), "--stdin",
                        "--approval-source", "ask_user_question",
                        "--scope-approval-source", "ask_user_question", stdin=cfg)
        check("approved 101-row scope starts", code, 0)
        if code == 0:
            doc=json.loads(out)
            check("approved run labels exactly 100", doc.get("rows_to_be_labeled"), 100)
            check("original eligible count retained", doc.get("eligible_labelable_rows_total"), 101)
            check("one physical row remains out of scope", doc.get("rows_left_unlabeled"), 1)

        # Blank rows do not consume the 100 semantic-record limit.
        rows=[["id","yorum"]]
        for i in range(1,111):
            rows.append([i, "" if i <= 10 else f"dolu {i}"])
        p3=write_csv(Path(d)/"blanks.csv",rows)
        code,out=run("scripts/agent_io.py","start",str(p3),"--stdin",
                     "--approval-source","ask_user_question",stdin=cfg)
        check("100 nonempty plus blanks needs no scope confirmation",code,0)
        if code==0:
            doc=json.loads(out)
            check("100 nonempty rows selected with blanks present",doc.get("rows_to_be_labeled"),100)


def test_data_driven_defaults() -> None:
    """Proposed labels never get a built-in vocabulary from target type."""
    print("\n3b. veri kaynakli varsayimlar")
    check("proposed sentiment uses discovery",
          rt.default_discovery_strategy("sentiment","proposed"), "taxonomy_discovery")
    check("proposed custom uses discovery",
          rt.default_discovery_strategy("custom","proposed"), "taxonomy_discovery")
    check("user vocabulary remains fixed",
          rt.default_discovery_strategy("sentiment","user"), "fixed")
    # A data-derived proposed evaluative target is allowed to have whatever
    # approved vocabulary the data produced; runtime must not impose four names.
    cfg={"targets":[{"name":"Degerlendirme","target_type":"sentiment",
         "purpose":"Onayli degerlendirme boyutunu belirle",
         "source_columns":["yorum"],"output_column":"Sonuc",
         "label_source":"proposed","cardinality":"single",
         "labels":[{"name":"A","definition":"a"},{"name":"B","definition":"b"}]}]}
    got=rt.validate_config(cfg,["yorum"],["C1"])
    check("runtime accepts data-derived proposed vocabulary",len(got["targets"][0]["labels"]),2)

# ------------------------------------------------------------ 4. task sizing
def test_task_flags_only_lower() -> None:
    """--max-tasks may lower the automatic payload size, never raise it.

    Raising it builds a payload too large to answer; the submission is rejected or
    comes back malformed and the work is redone, so the speed was never real.
    """
    print("\n4. gorev boyutu")
    with tempfile.TemporaryDirectory() as d:
        p = write_csv(Path(d) / "s.csv",
                      [["id", "yorum"]] + [[i, f"kisa yorum {i}"] for i in range(1, 61)])
        cfg = json.dumps({"targets": [{
            "name": "Konu", "target_type": "topic", "purpose": "Konu belirle",
            "source_columns": ["yorum"], "output_column": "Konu",
            "label_source": "user", "cardinality": "single",
            "labels": [{"name": "A", "definition": "a"}]}]})
        code, out = run("scripts/agent_io.py", "start", str(p), "--stdin",
                        "--approval-source", "ask_user_question", stdin=cfg)
        if code:
            check("start succeeds", code, 0)
            return
        doc = json.loads(out)
        job = doc["job_dir"]
        # The preview phase only ever offers 5 tasks, which is below every ceiling
        # and would hide a missing clamp. Get through it into production, where the
        # automatic size is large enough for a raise to be visible.
        while doc.get("action") == "answer":
            _, o = run("scripts/agent_io.py", "answer", "--job-dir", job, "--stdin", "--next",
                       stdin=json.dumps({"request_id": doc["request_id"], "answers": [
                           {"ref": a["ref"], "labels": ["A"]} for a in doc["answer_format"]["answers"]]}))
            doc = json.loads(o)
        if doc.get("action") == "approve_preview":
            _, o = run("scripts/agent_io.py", "preview", "--job-dir", job)
            pv = json.loads(o)
            _, o = run("scripts/agent_io.py", "preview", "--job-dir", job, "--stdin",
                       stdin=json.dumps({"summaries": [
                           {"source_row": r["source_row"], "summary": "ozet"} for r in pv["rows"]]}))
            pv = json.loads(o)
            run("scripts/agent_io.py", "approve", "--job-dir", job,
                "--approval-source", "ask_user_question", "--preview-id", pv["preview_id"])
        _, o = run("scripts/agent_io.py", "work", "--job-dir", job, "--refresh")
        auto = len(json.loads(o)["answer_format"]["answers"])
        check("production phase reached with room to raise", auto < 64, True)
        _, o = run("scripts/agent_io.py", "work", "--job-dir", job, "--refresh",
                   "--max-tasks", "64")
        check("--max-tasks cannot raise", len(json.loads(o)["answer_format"]["answers"]) <= auto, True)
        _, o = run("scripts/agent_io.py", "work", "--job-dir", job, "--refresh",
                   "--max-tasks", "2")
        check("--max-tasks can lower", len(json.loads(o)["answer_format"]["answers"]) <= 2, True)


# ------------------------------------------------------- 5. row identity
def test_row_identity_and_export() -> None:
    """A label must land on the row it was decided from.

    Hidden rows, filtered rows and the header offset all shift the arithmetic;
    misalignment produces a full, tidy-looking file that is wrong everywhere.
    """
    print("\n5. satir kimligi ve disari yazma")
    with tempfile.TemporaryDirectory() as d:
        rows = [["id", "yorum", "durum"]]
        for i in range(1, 13):
            rows.append([i, f"yorum {i}", "Sikayet" if i % 2 else "Memnun"])
        p = write_csv(Path(d) / "f.csv", rows)
        cfg = json.dumps({"targets": [{
            "name": "Konu", "target_type": "topic", "purpose": "Konu belirle",
            "source_columns": ["yorum"], "output_column": "Konu",
            "label_source": "user", "cardinality": "single",
            "labels": [{"name": "A", "definition": "a"}, {"name": "B", "definition": "b"}],
        }], "row_filters": [{"column": "durum", "operator": "equals", "value": "Sikayet"}]})
        code, out = run("scripts/agent_io.py", "start", str(p), "--stdin",
                        "--approval-source", "ask_user_question", stdin=cfg)
        if code:
            check("start succeeds", code, 0)
            return
        d0 = json.loads(out)
        job = d0["job_dir"]
        # Label every row with the parity of its own source row, so a shift of even
        # one row shows up as a mismatch in the export.
        want: dict[int, str] = {}

        def answer(doc):
            ans = []
            for slot in doc["answer_format"]["answers"]:
                ref = str(slot["ref"])
                row = None
                for it in doc["items"]:
                    for t in (it.get("tasks") or [it]):
                        if str(t.get("ref")) == ref:
                            row = t.get("source_row") or it.get("source_row")
                lab = "A" if (row or 0) % 4 == 1 else "B"
                want[row] = lab
                ans.append({"ref": ref, "labels": [lab]})
            c, o = run("scripts/agent_io.py", "answer", "--job-dir", job, "--stdin",
                       "--next", stdin=json.dumps({"request_id": doc["request_id"], "answers": ans}))
            return json.loads(o) if c == 0 else None

        doc = d0
        while doc and doc.get("action") == "answer":
            doc = answer(doc)
            if doc and doc.get("action") == "approve_preview":
                _, o = run("scripts/agent_io.py", "preview", "--job-dir", job)
                pv = json.loads(o)
                _, o = run("scripts/agent_io.py", "preview", "--job-dir", job, "--stdin",
                           stdin=json.dumps({"summaries": [
                               {"source_row": r["source_row"], "summary": "ozet"} for r in pv["rows"]]}))
                pv = json.loads(o)
                _, o = run("scripts/agent_io.py", "approve", "--job-dir", job,
                           "--approval-source", "ask_user_question",
                           "--preview-id", pv["preview_id"])
                doc = json.loads(o)
        out_path = Path(d) / "out.csv"
        code, o = run("scripts/agent_io.py", "finish", "--job-dir", job, "--out", str(out_path))
        check("finish succeeds", code, 0)
        if code:
            return
        with open(out_path, encoding="utf-8-sig") as f:
            got = list(csv.reader(f))
        header = got[0]
        check("output column appended once", header.count("Konu"), 1)
        ki = header.index("Konu")
        check("all original rows preserved", len(got), 13)
        mismatched, untouched = [], 0
        for physical, row in enumerate(got[1:], start=2):
            label = row[ki] if len(row) > ki else ""
            if row[2] != "Sikayet":
                if label:
                    mismatched.append(("filtered row labelled", physical, label))
                else:
                    untouched += 1
            elif want.get(physical) and label != want[physical]:
                mismatched.append(("wrong row", physical, label, want[physical]))
        check("labels land on their own rows", mismatched, [])
        check("filtered rows left untouched", untouched, 6)


# ------------------------------------------------------------ 6. injection
def test_untrusted_cells() -> None:
    """Cell text is data. Formulas must be neutralised on the way out."""
    print("\n6. guvenlik")
    check("formula prefix escaped", rt.safe_spreadsheet_text("=HYPERLINK(1)")[0], "'")
    check("plain text untouched", rt.safe_spreadsheet_text("kargo gecikti"), "kargo gecikti")
    check("minus escaped", rt.safe_spreadsheet_text("-1+1")[0], "'")


def main() -> int:
    print("excel-labeling regresyon testleri")
    for t in (test_column_resolution, test_header_detection, test_scope_rule,
              test_data_driven_defaults, test_task_flags_only_lower,
              test_row_identity_and_export, test_untrusted_cells):
        try:
            t()
        except Exception as e:  # a crashing test is a failing test
            FAILURES.append(f"{t.__name__} crashed: {e!r}")
            print(f"  CRASH {t.__name__}: {e!r}")
    print(f"\n{PASSES} gecti, {len(FAILURES)} basarisiz")
    for f in FAILURES:
        print(f"  - {f}")
    return 1 if FAILURES else 0


if __name__ == "__main__":
    raise SystemExit(main())
