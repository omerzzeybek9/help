"""Deterministic display and reuse artifacts; never chooses semantic labels or summaries."""
import hashlib,json,os,shlex
from pathlib import Path
import excel_labeling as rt

def write_json(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8');os.replace(tmp,path)

def ui_state(jd):
    cfg,meta=rt.load_job(jd);db=rt.db_connect(jd)
    try:
        rows=db.execute('SELECT w.unit_id,w.source_row,w.is_long,w.text,r.state FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id').fetchall()
        eligible={r['source_row'] for r in rows if r['state']!='EMPTY'}
        pending={r['source_row'] for r in rows if r['state'] is None}
        segments={r[0]:r[1] for r in db.execute('SELECT parent_unit_id,COUNT(*) FROM segment_results GROUP BY parent_unit_id')}
        total=done=0
        for r in rows:
            if r['state']=='EMPTY':continue
            weight=len(rt.split_long(r['text']))+1 if r['is_long'] else 1
            total+=weight;done+=weight if r['state'] is not None else min(weight-1,segments.get(r['unit_id'],0))
        audit_rows=db.execute('SELECT w.unit_id,w.is_long,w.text,a.audited_labels_json FROM audit a JOIN work w ON w.unit_id=a.unit_id').fetchall()
        audit_segments={r[0]:r[1] for r in db.execute('SELECT parent_unit_id,COUNT(*) FROM audit_segment_results GROUP BY parent_unit_id')}
        audit_total=audit_done=0
        for r in audit_rows:
            weight=len(rt.split_long(r['text']))+1 if r['is_long'] else 1
            audit_total+=weight
            audit_done+=weight if r['audited_labels_json'] is not None else min(weight-1,audit_segments.get(r['unit_id'],0))
    finally:db.close()
    state=meta['state'];stage='Etiketleniyor';percent=int(100*done/max(1,total))
    # Every row having a raw label is not the end of the work when a free-form
    # target still owes a consolidation pass, and the job only flips to
    # CONSOLIDATING once that pass actually starts. Reporting 100% in the gap
    # showed unfinished work as finished.
    if percent>=100 and state=='LABELING' and any(
            t['label_source']=='freeform' for t in rt.load_job(jd)[0]['targets']):
        percent=99
    if state in rt.PREVIEW_STATES:stage='Örnekler hazırlanıyor';percent=None
    elif state=='CONSOLIDATING':stage='Benzer etiketler birleştiriliyor';percent=None
    elif state=='AUDITING':stage='Kontrol ediliyor';percent=int(100*audit_done/max(1,audit_total))
    elif state in {'AUDIT_FAILED','REPAIRING'}:stage='Sonuçlar gözden geçiriliyor';percent=None
    elif state in {'AUDIT_PASSED','VALIDATED'}:stage='Dosya hazırlanıyor';percent=None
    elif state=='EXPORTED':stage='Dosya hazır';percent=100
    value={'key':hashlib.sha256(str(jd.resolve()).encode()).hexdigest()[:16],'stage':stage,'percent':percent,'completed_rows':len(eligible-pending),'total_rows':len(eligible),'blank_rows':meta['rows']-len(eligible),'output_ready':state=='EXPORTED'}
    path=jd/'progress.json';previous=rt.load_json(path) if path.exists() else {}
    value['revision']=previous.get('revision',0)+(int({k:v for k,v in previous.items() if k!='revision'}!=value))
    write_json(path,value);return value

def preview_signature(jd):
    db=rt.db_connect(jd)
    try:
        rows=[list(r) for r in db.execute('SELECT p.unit_id,w.content_hash,r.labels_json,r.state FROM preview p JOIN work w ON w.unit_id=p.unit_id LEFT JOIN results r ON r.unit_id=p.unit_id ORDER BY p.rank')]
    finally:db.close()
    cfg,_=rt.load_job(jd)
    return hashlib.sha256(json.dumps([cfg,rows],ensure_ascii=False,sort_keys=True).encode()).hexdigest()

def cell(s):return str(s).replace('\\','\\\\').replace('|','\\|').replace('\r',' ').replace('\n',' ')

PLAN_STEPS = [
    'Dosyayı ve etiket tercihlerini netleştir',
    'Örnekleri göster ve onay al',
    'Tüm satırları etiketle',
    'Sonuçları kontrol et',
    'Excel ve tekrar kullanım metnini sun',
]


def task_plan(jd):
    """Real phase milestones; export readiness never proves host attachment."""
    _, meta = rt.load_job(jd)
    status = rt.status(jd)
    state = meta['state']
    preview_approved = meta.get('preview_approval_source') == 'ask_user_question'
    labeled = bool(preview_approved and status['labeling_complete']
                   and status['ready_for_audit'] and state != 'REPAIRING')
    checked = state in {'AUDIT_PASSED', 'VALIDATED', 'EXPORTED'}
    # The export is the last thing this runtime can know about; whether the host
    # then attached the file is outside its sight. A hardcoded False, though, left
    # the final step reading "in_progress" forever on a finished job and disagreed
    # with agent_io's own todo list, which marks EXPORTED complete.
    done = [meta.get('setup_approval_source') == 'ask_user_question',
            preview_approved, labeled, checked, False]
    active = next((i for i, complete in enumerate(done) if not complete), 4)
    return {'steps': [{'step': label, 'status': 'completed' if done[i] else
                      ('in_progress' if i == active else 'pending')}
                     for i, label in enumerate(PLAN_STEPS)],
            'delivery_ready': state == 'EXPORTED'}


def plan_update(jd):
    """Emit only changed stages, not a status message for every work request."""
    value = task_plan(jd)
    p = jd/'plan.json'
    previous = rt.load_json(p) if p.exists() else {}
    if {k: v for k, v in previous.items() if k != 'revision'} == value:
        return None
    value['revision'] = previous.get('revision', 0) + 1
    write_json(p, value)
    return value

def preview_approval(markdown,signature,preview_id,jd=None):
    # Carry the command, not just the name of it. Every other step returns a
    # runnable line; this one returned "run approve" and left the caller to
    # assemble --preview-id and the job path from memory, which is where the
    # guessing started.
    cmd = ('python scripts/agent_io.py approve --job-dir '
           f'{shlex.quote(str(jd)) if jd is not None else "JOB"} '
           '--approval-source ask_user_question '
           f'--preview-id {preview_id}')
    # The approval step is a stage boundary, so the stage list belongs here too.
    # Returning it only from work meant the plan froze exactly while the user
    # was being asked something — the one moment they are looking at it.
    todos = None
    if jd is not None:
        try:
            import agent_io
            todos = agent_io.progress(jd)['todos']
        except Exception:
            todos = None
    extra = ({'todos': todos, 'todos_tool': 'write_todos',
              'todos_call': {'todos': todos}} if todos else {})
    return {'action':'approve_preview','markdown':markdown,'signature':signature,'preview_id':preview_id,
            **extra,
            'required_tool':'ask_user_question',
            'question':'Bu örneklerle belirtilen kapsamdaki kayıtları etiketleyeyim mi?',
            'next_command':cmd,
            'instruction':('YALNIZ markdown alanini oldugu gibi goster — '
                           'satirlari yeniden yazma, ozetleme, kendi tablonu '
                           'kurma veya yorum ekleme. Bu tablo kullaniciya '
                           'gosterilecek tek seydir. Sonra gerçek '
                           'ask_user_question MCP aracını question ile çağır. '
                           'Mesaja ayrıca düz metin soru ekleme. Bu nesne '
                           'yönlendirmedir; araç çağrısı veya onay değildir. '
                           'Kullanıcı gerçekten cevap verdikten SONRA '
                           'next_command\'ı aynen çalıştır.')}


def preview(jd,payload=None):
    raw=rt.preview_results(jd)
    if not raw['complete']:
        # The failure this guards against is not calling preview too early — it
        # is giving up on the tool and writing a table by hand with "?" in the
        # label columns, then asking the user to fill it in. That inverts the
        # whole gate: the user is meant to check decisions the model made, not
        # make them. Say so here, because this is the moment the model is
        # tempted to improvise a table.
        rt.die('PREVIEW_INCOMPLETE',
               'Önizleme görevlerinin bir kısmı hâlâ kararsız. work/answer '
               'döngüsünü action "answer" olmaktan çıkana kadar sürdür, sonra '
               'preview çağır. Kendi tablonu yazma ve etiket sütununu "?" '
               'bırakıp kullanıcıdan doldurmasını isteme: onay, senin verdiğin '
               'kararlar içindir — kullanıcı etiketleyici değil, onaylayıcıdır. '
               'Etiketi bir satır için gerçekten seçemiyorsan labels: [] + review: true + review_reason '
               'ver ve nedenini yaz; boş bırakma.')
    cfg,meta=rt.load_job(jd);by_row={}
    for item in raw['preview_results']:
        row=by_row.setdefault(item['source_row'],{'source_row':item['source_row'],'labels':{},'units':[]})
        row['labels'][item['target']]=item['labels'] or [item['state']];row['units'].append(item['unit_id'])
    sig=preview_signature(jd);p=jd/'preview_display.json'
    if payload is None and p.exists():
        old=rt.load_json(p)
        if old['signature']==sig:return preview_approval(old['markdown'],sig,old['preview_id'],jd)
    if payload is None:
        db=rt.db_connect(jd)
        try:
            for row in by_row.values():
                notes=[];excerpts=[]
                for uid in row['units']:
                    w=db.execute('SELECT fields_json,is_long FROM work WHERE unit_id=?',(uid,)).fetchone()
                    if w['is_long']:
                        notes.extend(r[0] for r in db.execute('SELECT note FROM segment_results WHERE parent_unit_id=? ORDER BY unit_id',(uid,)) if r[0])
                    else:excerpts.extend(f['text'] for f in json.loads(w['fields_json']) if f['role']=='source')
                row['display_evidence']=list(dict.fromkeys(notes+excerpts))
                del row['units']
        finally:db.close()
        _t = None
        try:
            import agent_io
            _t = agent_io.progress(jd)['todos']
        except Exception:
            _t = None
        return {'action':'write_preview_summaries','rows':list(by_row.values()),
                'summary_format':{'summaries':[{'source_row':n,'summary':'<1–2 sentence summary>'} for n in by_row]},
                'submit_command':f'python scripts/agent_io.py preview --job-dir {shlex.quote(str(jd))} --stdin',
                **({'todos':_t,'todos_tool':'write_todos','todos_call':{'todos':_t}} if _t else {}),
                'instruction':'Bu turda kullaniciya hicbir sey yazma: ozetleri sohbete dokme, kendi tablonu kurma. Ozetler preview --stdin ile gonderilir ve tablo halinde geri gelir; gosterecegin tek sey odur. Fill summary_format; send with preview --stdin, NOT answer. Write 1–2 faithful sentences, max420 characters. Preserve the material facts, negation, outcome and any explicit evaluation relevant to the approved targets. Do not invent a conclusion or mapping absent from the source and approved rules. Summary is display-only; never relabel from it. Show only the returned markdown table, then open the real MCP preview question.'}
    summaries=payload.get('summaries',[]) if isinstance(payload,dict) else []
    if not isinstance(summaries,list) or any(not isinstance(x,dict) for x in summaries):rt.die('PREVIEW_SUMMARIES_INVALID')
    supplied={x.get('source_row'):x.get('summary') for x in summaries}
    if len(supplied)!=len(summaries) or set(supplied)!=set(by_row):rt.die('PREVIEW_SUMMARIES_MUST_COVER_ROWS','Copy summary_format from preview and fill every summary. Send with preview --stdin; do not use answer or request new labeling work.')
    _bad={n:('empty' if not isinstance(s,str) or not s.strip() else f'{len(s)} chars')
           for n,s in supplied.items()
           if not isinstance(s,str) or not s.strip() or len(s)>420}
    if _bad:
        rt.die('PREVIEW_SUMMARY_LENGTH_INVALID',
               f'every summary must be non-empty and at most 420 characters. '
               f'Offending rows: {dict(list(_bad.items())[:6])}. Write a short '
               f'faithful summary of that row from its own source text — do not '
               f'send an empty string, and do not paste the whole row.')
    names=[t['name'] for t in cfg['targets']]
    lines=['| Satır | Kısa özet | '+' | '.join(cell(x) for x in names)+' |','| --- | --- | '+' | '.join('---' for _ in names)+' |']
    for n,row in by_row.items():lines.append('| '+str(n)+' | '+cell(supplied[n])+' | '+' | '.join(cell('; '.join(row['labels'].get(name,['—']))) for name in names)+' |')
    markdown='\n'.join(lines)
    preview_id=hashlib.sha256(json.dumps([sig,summaries,markdown],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
    write_json(p,{'signature':sig,'summaries':summaries,'markdown':markdown,'preview_id':preview_id})
    return preview_approval(markdown,sig,preview_id,jd)

def approve(jd,approval_source,preview_id):
    p=jd/'preview_display.json'
    if not p.exists() or rt.load_json(p)['signature']!=preview_signature(jd):
        # Approval must follow a table the user actually saw. Without naming the
        # step, the caller usually retries approve or re-answers the preview,
        # because nothing says the missing thing is the display call.
        rt.die('CURRENT_PREVIEW_DISPLAY_REQUIRED',
               'call `agent_io.py preview --job-dir JOB` first and show the '
               'returned markdown to the user, then approve with the preview_id '
               'from that same response. If the preview answers changed after the '
               'table was produced, run preview again to refresh it.')
    if rt.load_json(p).get('preview_id')!=preview_id:
        rt.die('PREVIEW_APPROVAL_STALE',
               'this preview_id belongs to an older table. Run `preview` again, '
               'show the new markdown, and approve with the preview_id it '
               'returns — do not reuse an id from a previous display.')
    if not rt.preview_results(jd)['complete']:
        rt.die('PREVIEW_INCOMPLETE',
               'some preview tasks have no decision yet. Continue the '
               '`answer --next` loop until the returned action stops being '
               '"answer", then display and approve.')
    if approval_source!='ask_user_question':rt.die('PREVIEW_APPROVAL_REQUIRED')
    _,meta=rt.load_job(jd)
    if meta.get('pending_exemplar_conflicts'):
        meta['acknowledged_exemplar_conflicts']=meta.pop('pending_exemplar_conflicts')
        rt.save_meta(jd,meta)
        return {'approved_examples_retained':True}
    if meta.get('preview_approval_source')=='ask_user_question':
        return {'approved':True,'already_recorded':True}
    return rt.approve_preview(jd,approval_source)

def reusable(jd,out):
    cfg,meta=rt.load_job(jd)
    lines=['Yeni yüklediğim Excel/CSV dosyasını aşağıdaki kurallarla etiketle.','Aşağıda belirtilen boyut, etiket kaynağı ve tek/çoklu tercihlerini tekrar sorma. Yeni dosyanın sütunlarını kontrol et; etiket ve sütun önerisini gerçek soru aracıyla bir kez onaylat. Örnekleri yalnızca kısa özetli bir tabloda göster; yine gerçek soru aracıyla onayımı alıp bu çalışmanın kapsamını tamamla; sınır nedeniyle kalan kayıtları ayrıca bildir.','Etiketleri tam orijinal metnin anlamından belirle. Boş kaynakları boş bırak. Kaynak veriyi koruyarak yeni dosya üret. İlerlemeyi kısa planda göster; satır kararlarını sohbete yazma.','Önceki dosyanın sayfası: '+str(meta['sheet'])+'. Başlık satırı: '+str(meta.get('header_row',1))+'. Kapsam: '+str(meta.get('row_scope','all'))+'. Yeni dosyadaki karşılığını kontrol et.']
    if cfg.get('row_filters'):
        filters=[]
        for f in cfg['row_filters']:
            item={'column':f.get('column_name',f['column']),'operator':f['operator'],'case_sensitive':f.get('case_sensitive',False)}
            if f['operator'] in {'equals','not_equals'}:item['value']=f['values'][0]
            elif f['operator'] in {'in','not_in'}:item['values']=f['values']
            filters.append(item)
        lines.append('Satır seçimi: '+json.dumps(filters,ensure_ascii=False))
    lines.append(f'Çalışma kapsamı: en çok {rt.FULL_RUN_ROW_LIMIT} dolu kayıt. Yeni dosyada 100 veya daha az dolu kayıt varsa hepsini işle; daha fazlaysa gerçek MCP kapsam onayı olmadan başlama. Toplam karakter sayısı kapsamı azaltmaz.')
    db=rt.db_connect(jd)
    try:
        for t in cfg['targets']:
            lines+=['',t['name']+':','Amaç: '+t.get('purpose',''),'Kaynak sütunlar: '+', '.join(t['source_column_names']),'Bağlam sütunları: '+(', '.join(t.get('context_column_names',[])) or 'Yok'),'Çıktı sütunu: '+t['output_column'],'Etiket sayısı: '+('Tek' if t['cardinality']=='single' else 'Birden fazla')]
            if t.get('raw_output_column'):lines.append('Detay sütunu: '+t['raw_output_column'])
            if t['label_source']=='user':
                lines.append('Yol: Kullanıcının aşağıdaki hazır etiketlerini aynen koru.')
                for lab in t['labels']:
                    lines.append('- '+lab['name']+': '+lab.get('definition',''))
                    for key,title in [('include','Dahil'),('exclude','Hariç')]:
                        if lab.get(key):lines.append('  '+title+': '+'; '.join(lab[key]))
            elif t['label_source']=='proposed':
                lines.append('Yol: Etiketleri yeni dosyanın kendi verisinden yeniden keşfet ve yapı onayında göster. Önceki dosyanın kategori adlarını otomatik kopyalama.')
            else:
                lines.append('Yol: Yeni dosyanın satırlarından serbest semantic etiketler üret; yalnız gerçekten aynı anlamları birleştir. Önceki dosyanın grup adlarını otomatik taşıma.')
        correction_rules=[r[0] for r in db.execute("SELECT DISTINCT rationale FROM approved_exemplars WHERE explicit_correction=1 AND rationale!='' ORDER BY rationale")]
    finally:db.close()
    if correction_rules:lines+=['','Kullanıcının düzelttiği genel karar kuralları:']+['- '+x for x in correction_rules]
    lines+=['','Etiket kararlarını yeni dosyanın tam kaynak anlamından ve o çalışma için onaylanan veri-kaynaklı/kullanıcı etiket tanımlarından ver; önceki dosyanın etiket dağılımını kural sayma.','Sonuç dosyası ile birlikte güncel yeniden kullanım promptunu da oluştur.']
    out=Path(out);out.write_text('\n'.join(lines),encoding='utf-8')
    return {'path':str(out.resolve()),'correction_guidance_needed':False,'instruction':'Attach automatically with output; no extra permission question. Correction rationales must contain general non-identifying rules, never copied customer text.'}
