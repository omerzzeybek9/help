# Execution, context, and recovery

## Healthy execution
After preview approval, execute tools in the same active turn. Do not end with “I will continue”, “please wait”, or a plan while runnable work remains. A final response ends execution unless the host has an actual scheduled continuation mechanism.

For preview/full/audit/repair: retrieve one bounded payload, read each permitted source/context, decide as the model, submit, inspect the result. Do not narrate individual decisions outside the user-approved preview. Do not duplicate source text in reasoning or output. Use the compact CLI JSON directly; do not pretty-print it or dump job files.

A larger batch does not fix accumulated conversation history. Keep source complete, reserve space for decisions and tool responses, and obey the runtime batching budget. Repair reports `oversized_atomic_item` when the first complete evidence item exceeds its soft limit; rules and transport metadata are additional context. Never truncate such an item. Reserve enough context or compact before processing it. If the host reports remaining context, compact before exhausting it. The script does not know the model context limit and cannot compact or restart the host.

## Resume
Run:
```bash
python scripts/excel_labeling.py resume --job-dir JOB
```
This reports persisted phase, fully completed physical rows, remaining target units, audit/repair pending counts, repair rounds, blockers, next action, and verified export receipt. After `quality-report`, resolve any quality issues, then use `after_quality_triage` to proceed to consolidation or audit-start. Read-only quality-report does not advance the state by itself; do not loop on resume/quality-report. Row count and target-unit count are different. Completion of labeling does not imply completion of audit or delivery.

On a submit error, do not assume success. Inspect the acknowledgement/error and resume state. If a lease expired, retrieve the pending payload in the same phase and classify it again. Preserve completed work and existing approvals. Use `contract` for schema mistakes. Never edit SQLite or meta.json manually.

After context compaction or a new host worker, read SKILL.md and this reference, then call resume. The next payload reintroduces approved rules. Preserve the job directory, config, source file, and requested output path in the host continuation state. The job contains customer data; use only the approved Wise storage/environment. Do not send it to external services.

If the host cannot continue automatically, state honestly that processing is paused, preserve the job, and provide the host-supported resumption path. Do not say it is still running. Cross-session recovery requires the host to retain/access the job directory and original source path; this skill alone cannot guarantee that capability. If source is missing or changed, stop and resolve the exact original input before continuing.

## Audit failures
Use `audit-results --mismatch-limit 5` for a small diagnostic sample. This limits display, not audit coverage. Judge both proposed labels against source and approved rules. Mismatch is disagreement, not proof that either side is wrong.

If rules are clear, repair using the existing conservative runtime scope and then a fresh audit seed. Do not blindly copy audit labels. If definitions conflict, obtain a business-rule clarification and follow the existing new-setup policy. After one repair and failed re-audit, stop broad automatic repair and diagnose; resume flags this case. Never lower coverage, increase the mismatch threshold, bypass validation, or export because processing is taking too long.

## Delivery
Export must pass all existing gates. `resume` verifies the saved output receipt against file bytes. An older v2.5 exported job has no receipt: re-export through the normal gates before delivery. After a verified export, attach the output through the real host file mechanism. Do not expose input/config/meta/SQLite as substitutes. Offer the reusable prompt only after delivery.

The receipt proves that exported bytes still match, not semantic accuracy, successful user download, or workbook fidelity beyond the existing export tests.
