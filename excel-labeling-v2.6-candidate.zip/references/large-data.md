# Large Data and Long Text

## Context discipline
Never load the full dataset into conversational context. Retrieve bounded work from the runtime.
Do not ask users for internal batch/chunk sizes.

## Row bundles
For ordinary rows the runtime groups pending targets for the same physical source row into one `row_bundle` when possible. This reduces orchestration calls and helps Topic/Sentiment/etc. stay synchronized.

Read and decide every returned task in the bundle. Do not infer missing tasks from earlier rows.

## Work leases and source hashes
Every delivered semantic task includes a short-lived `lease_id` and `source_hash`. Submit must copy both exactly.
This prevents results for unseen/unknown work and protects against stale or shifted work queues.

Do not expose leases/hashes to users.

## Exact duplicates
Exact-identical source + approved context under the same target may reuse an already approved semantic result. This is deterministic and safe.
Do not automatically reuse approximate/fuzzy matches.

## Long text
Never silently truncate source used for final classification.
Long work is segmented internally. Segment outputs are semantic signals, not final labels. Finalize only after every required segment has been processed and the aggregate task is returned.

Preview excerpts/summaries are display-only.

## Stable row identity
Map results through runtime row IDs and source hashes, never by searching copied text back into the sheet.

## Performance principle
Optimize transport, bundling, exact duplicates and deterministic file operations. Never buy speed by replacing semantic reasoning with keyword rules.
