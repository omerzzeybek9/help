# Label Discovery and Design

## Path A — user-provided labels
Use the user's list as the starting vocabulary.
Do not research or rename labels by default.
Flag only overlaps/ambiguities that would materially harm consistency.

## Path B — propose from the data
Do not infer a taxonomy from only 3–5 rows.

Use two different varied samples:
1. discovery sample to identify candidate concepts;
2. coverage sample to test whether important concepts remain uncovered.

Scale sample size with the dataset instead of using a tiny fixed sample. As a default, use roughly 20/12 rows for files up to 100 non-empty rows, 32/20 for 101–1,000, and 48/32 above 1,000, subject to the runtime sample cap and the number of unique records.

A proposed label set should satisfy:
- **coverage**: important recurring meanings are represented;
- **distinctness**: labels are not near-duplicates;
- **consistency**: boundaries can be applied repeatedly;
- **usefulness**: labels answer the user's actual business goal;
- **parsimony**: do not create a label for every wording variant.

If the coverage sample reveals a meaningful missing concept, refine and audit again before showing the user.

## Internal label specification
For fixed labels, keep enough semantics to classify consistently:
- name
- short definition
- include: representative semantic situations
- exclude: nearby meanings that belong elsewhere
- examples: only where useful

These are semantic guides, not keyword lists.

## Path C — free-form + consolidation
During raw labeling, create concise semantic noun phrases without forcing a fixed vocabulary.
Afterward merge synonyms/trivial wording variants.
Do not merge materially different concepts just to reduce label count.

If a new canonical concept materially changes what the user will receive, ask for approval; trivial synonym normalization does not need another user interruption.

## Cross-target orthogonality
When multiple targets are selected, design their label sets together.

Examples:
- Topic should answer “what is this about?”
- Sentiment should answer “how positive/negative/neutral/mixed is it?”
- Intent should answer “what is the user trying to do?”

Avoid labels in one target that merely restate another target. If Topic + Sentiment both exist, a label such as `Genel Memnuniyet` is usually redundant with Sentiment. If records truly contain no narrower business topic, a neutral `Genel Deneyim` label can be used with a clear boundary.

## Discovery saturation
For Path B, one discovery pass is not always enough. If the coverage sample reveals a recurring concept not represented by the proposed labels, refine the taxonomy and test another fresh sample. Stop when additional varied samples no longer reveal material recurring gaps, or when further expansion would create trivial/rare labels.

Keep this internal; do not make the user watch repeated discovery rounds.
