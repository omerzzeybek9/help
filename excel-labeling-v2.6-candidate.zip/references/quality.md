# Quality Gates

## 1. Taxonomy coverage before setup approval
For Path B, discover on a varied sample and test on a different holdout sample.
Check:
- recurring uncovered meanings;
- label overlap;
- vague/catch-all labels;
- boundaries that cannot be applied consistently;
- cross-target redundancy;
- business usefulness.

## 2. Challenging preview
Preview should include ordinary rows plus boundary/implicit/irony/negation/multi-topic/long examples when present.
Use the same physical rows across targets so the user can compare Topic + Sentiment side by side.

## 3. User corrections are durable
A correction to an existing preview decision must be persisted as a binding approved exemplar via runtime, independent of an expired work lease.
After correction, preview approval is required again.
Corrected examples are mandatory semantic-audit probes.

If taxonomy/source/cardinality itself changes, start a fresh job instead of mutating old state.

## 4. Structural validation is necessary but insufficient
Row counts, allowed labels, hashes, cardinality, and workbook integrity may all pass while semantics are wrong.
Structural validation must never be described as semantic accuracy.

## 5. Pre-audit triage
Run `quality-report` after full labeling.
- `TAXONOMY_GAP` blocks audit/export and requires setup repair.
- unexpectedly high REVIEW requires diagnosis.
- Path C must complete consolidation before audit.

## 6. Independent semantic consistency audit
Audit gets source/context + approved rules, but not the production label.
The model must classify again from meaning. Do not generate/reuse a Python classifier, keyword rules, cached production decisions, or a helper that auto-selects labels.

Audit sampling is stratified across:
- user-corrected and approved preview examples;
- dataset timeline;
- predicted label vocabulary, rare labels first;
- context strata where available;
- long text;
- unique content-hash clusters to avoid wasting budget on duplicates.

For Path C, audit the **canonical consolidated labels**, not raw free-form wording.

Audit mismatch is a consistency guardrail, not a claim of ground-truth accuracy. True accuracy comes from human-reviewed golden evaluation sets.

## 7. Repair
If audit fails, do not export. Repair the affected scope and rerun a **fresh audit**.
If mismatches reveal a business-rule/taxonomy problem rather than execution drift, return to the user through MCP, revise setup, and re-preview.

## 8. REVIEW discipline
REVIEW means genuinely unresolved source, not low confidence or “no keyword match”.
High REVIEW cannot be acknowledged merely to bypass weak labeling rules.

## 9. Golden regression
For releases, maintain human-reviewed fixtures representing real domains and hard semantic phenomena. At minimum track:
- per-target accuracy;
- joint accuracy for multi-target rows;
- irony/negation/boundary subsets;
- user-correction persistence;
- known-corrupt fixture must fail audit;
- clean fixture must pass.

A skill/runtime change that fixes one failure but regresses an existing golden case is not release-ready.
