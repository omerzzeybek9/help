# Interaction and UX

## Product experience
A non-technical branch/office user should feel they are making business decisions, not configuring an AI pipeline.

Normal path should feel like:
1. “Bu veriyi hangi açı(lar)dan etiketleyelim?”
2. “Önerdiğim etiketler ve tek/çoklu yapı uygun mu?”
3. “Bu örnek sonuçlar doğru mu?”
4. “Dosyanız hazır.”

## Mandatory MCP gates
Use the real `ask_user_question` MCP tool. Never replace a required gate with ordinary prose or invent approval.

Use it when needed for:
- ambiguous sheet/header/visible-row scope;
- generic target/dimension selection;
- setup approval;
- preview approval or user preview corrections;
- business-rule/taxonomy changes after QA;
- material free-form consolidation changes;
- unavoidable high REVIEW acceptance;
- output-column conflict choice;
- reusable prompt offer.

If MCP fails at a required gate, stop at that gate.

## Ask fewer, better questions
Combine one/multiple behavior with label setup when possible. Recommend sensible defaults instead of asking abstract configuration questions.

Example:
- `Konu/Tema: bir satırda birden fazla konu olabilir`
- `Duygu: her satır için tek duygu etiketi`
- show the proposed labels below each target;
- ask one MCP question: `Bu yapı uygun mu?`

## Preview corrections
If the user says an already-shown preview example has the wrong label **without changing taxonomy/source/cardinality**, persist that correction with `preview-correct`. Do not depend on an old work lease and do not silently discard the correction.

If the correction implies a business-rule/taxonomy/source/cardinality change, revise setup, get new setup approval, start a fresh job, and preview again.

## Conditional questions only
Do not ask about hidden rows, header row, output-column conflicts, etc. unless the runtime actually detects the condition.

## Do not narrate internals
After preview approval, do not expose:
- work item counts;
- batches/chunks;
- JSON generation;
- leases/hashes/bundle IDs;
- repeated submit loops;
- audit-next/audit-submit mechanics;
- repair queue details;
- classifier scripts (which must not be used anyway).

Internal recoverable errors should be repaired silently. Only return to the user for a real business decision.

## Language
Use the user's language for proposed labels and explanations unless they supplied an existing label vocabulary in another language. Keep one target's output vocabulary internally consistent.

## Advanced workbook risk
If `inspect` reports `workbook_features.roundtrip_risk = high`, do not surface a raw runtime error at export. Before export, use `ask_user_question` with simple business wording: the workbook contains advanced Excel features (for example macros, pivots, protection, or external links) that may not round-trip perfectly. Offer to create a labeled copy while leaving the original untouched, or stop/cancel. Only pass the runtime's advanced-workbook override after explicit user approval. Do not imply perfect preservation when the runtime reports high risk.
