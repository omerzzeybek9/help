# Required choices before setup approval

`setup-check --config CONFIG.json` reports only missing choices. Its output describes questions; it is not an MCP request schema. Use the actual ask_user_question MCP. Never ask users about this configuration file or evidence format.

1. Resolve the dimensions: “Verileri hangi boyutlarda etiketlemek istersiniz?” Offer a few useful choices based on the file. Do not ask preferences for dimensions the user has not selected.
2. Resolve each dimension's label source: ready list / data-proposed / free-form then consolidation. If the user chose a ready list, obtain the actual list before setup approval.
3. Resolve each dimension's cardinality: “Konu için her satırda tek etiket mi, birden fazla etiket mi olsun?” Ask separately for Duygu unless a prior explicit answer covered it too. Do not silently assume sentiment is single or topic is multi.
4. Only when all choices are recorded, show the setup table and obtain setup approval. Then complete and show the preview table and obtain its separate approval. General setup approval does not answer an unasked cardinality question.

Combine related questions if the real MCP supports it. If it allows fewer questions than needed, ask the remaining ones in the next MCP call. Tool limits never mean optional questions. Do not repeat explicit answers from this conversation or a user-supplied reusable prompt; record them as explicit_user_message. Newly missing choices must use MCP. Never invent an answer, response ID or tool result.

Each raw config target includes `user_choices`. Every entry contains `value` matching that target's current setting, `source` (ask_user_question or explicit_user_message), and `answer` (the actual short user answer). For dimension, value is the selected target name. Copy only the relevant preference; do not copy customer records or a large chat transcript. The answer must be substantive, not merely generic setup approval.

Schema example only, never proof that these answers occurred:
```json
"user_choices": {
  "dimension": {"value":"Konu","source":"ask_user_question","answer":"Konu ve duygu"},
  "label_source": {"value":"proposed","source":"ask_user_question","answer":"Etiketleri veriden öner"},
  "cardinality": {"value":"multi","source":"ask_user_question","answer":"Konu için birden fazla etiket"}
}
```

Run setup-check after recording actual answers and before setup approval. Missing or mismatched choices cause init to fail with USER_CHOICES_REQUIRED before it creates a job or reads labeling data. Fix the missing user decision through the real conversation, not by manufacturing evidence. Choice records are saved in the job metadata for continuation.

This checks completeness and consistency, not authenticity. Wise must verify these records against actual user messages/MCP responses. An unrestricted model can fabricate strings; a local script cannot prove a real question was asked. Existing v2.9 jobs can resume; do not invent historical choice records or re-init an active job merely to upgrade.
