# User interaction

Use the real ask_user_question MCP and the schema it actually exposes. No ordinary-message substitution for critical choices. Keep prompts in the user's language and combine related questions if supported.

Read setup-questions.md before collecting choices. Run setup-check before approving setup; each target needs explicit recorded dimension, label-source and cardinality choices.

## Minimal decisions
1. If purpose is absent: “Yorumlardan neyi öğrenmek istersiniz?” Offer only relevant dimensions.
2. For each target, resolve label source and one/multiple labels. “Hazır etiketlerinizi mi kullanalım, veriden mi önerelim, yoksa serbest etiket üretip benzerlerini mi birleştirelim?” “Bir yorum birden fazla konu alabilir mi?” Explicit earlier answers count; silence does not.
3. Approve a compact setup table with target, source/context/output columns, chosen path, cardinality and short label definitions. State sheet and subset once.
4. Show the shared preview, apply corrections, obtain approval before full execution.

Do not ask the user for an endpoint, API key, package installation, batch size or runtime options. If an essential tool is unavailable, explain the actual missing capability simply.

## Long preview
Show only the single runtime-rendered table with a 1–2 sentence summary, the original Excel row number and target labels. Preserve negation, material cause and mixed signals in the summary. Base classification on every original segment, not the display summary. Put any essential reason inside the summary cell, never in additional row-by-row prose.

## Research and independently ready targets
Keep explicitly approved choices settled. A genuinely unresolved business concept may be identified by the user or model. First ask the user or propose sensible labels from data. Announce the specific remaining concept before any research, and research abstract terminology only.

Continue discovery/preview preparation for other targets. If one unresolved target would delay full processing of independently approved targets, create one job for the ready target set, approve its setup and preview, and complete it through verified export as an internal intermediate. Later initialize the unresolved target's job from that verified intermediate, preserving all existing columns and rows. Obtain its own setup and preview approval and export to a new path. Each job has its own source hash; never change a source file under an active job. Track all requested targets and deliver only when all requested outputs are accounted for. No research-specific feature is needed in the runtime; the two-stage copy/export path must preserve prior columns.

## Completion
After attaching verified Excel, automatically attach the generated reusable prompt; do not ask whether to create it. Include approved definitions, columns, cardinalities and general correction guidance without copying original customer records. State only labeled/blank counts; distributions and audit metrics are optional on request. Never describe sample agreement as100%accuracy.
