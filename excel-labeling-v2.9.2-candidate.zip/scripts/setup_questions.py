"""Check recorded user choices. The host must authenticate actual user/MCP responses."""

FIELDS = ('dimension', 'label_source', 'cardinality')
SOURCES = {'ask_user_question', 'explicit_user_message'}
APPROVAL_ONLY = {'onaylıyorum', 'onayliyorum', 'onay', 'tamam', 'evet', 'ok', 'yes', 'approved', 'approve'}


def check(config):
    targets = config.get('targets') if isinstance(config, dict) else None
    if not isinstance(targets, list) or not targets:
        return {'action': 'collect_user_choices', 'ready': False, 'questions': [
            {'field': 'dimension', 'question': 'Verileri hangi boyutlarda etiketlemek istersiniz?'}]}
    questions = []
    for target in targets:
        if not isinstance(target, dict):
            raise ValueError('Each target must be an object')
        name = target.get('name', '')
        evidence = target.get('user_choices', {})
        if not isinstance(evidence, dict):
            evidence = {}
        expected = {'dimension': name, 'label_source': target.get('label_source'),
                    'cardinality': target.get('cardinality')}
        for field in FIELDS:
            record = evidence.get(field, {})
            valid_value = (isinstance(name, str) and bool(name.strip()) if field == 'dimension'
                           else isinstance(expected[field], str) and expected[field] in ({'user', 'proposed', 'freeform'}
                                                    if field == 'label_source' else {'single', 'multi'}))
            valid = (isinstance(record, dict) and valid_value
                     and record.get('value') == expected[field]
                     and isinstance(record.get('source'), str) and record['source'] in SOURCES
                     and isinstance(record.get('answer'), str)
                     and 0 < len(record['answer'].strip()) <= 1200
                     and record['answer'].strip().casefold().rstrip('.!') not in APPROVAL_ONLY)
            if valid:
                continue
            question = {'target': name, 'field': field}
            if field == 'dimension':
                question['question'] = 'Verileri hangi boyutlarda etiketlemek istersiniz?'
            elif field == 'label_source':
                question.update(question=f'{name} etiketlerini nasıl belirleyelim?', options=[
                    'Hazır etiket listemi kullan', 'Veriden etiket öner', 'Serbest üret, benzerlerini birleştir'])
            else:
                question.update(question=f'{name} için her satırda tek etiket mi, birden fazla etiket mi olsun?',
                                options=['Tek etiket', 'Birden fazla etiket'])
            questions.append(question)
    # Resolve dimensions first; do not ask preferences for targets the user has not selected.
    dimensions = [q for q in questions if q['field'] == 'dimension']
    if dimensions:
        questions = [{'field': 'dimension', 'question': 'Verileri hangi boyutlarda etiketlemek istersiniz?'}]
    return {'action': 'collect_user_choices' if questions else 'approve_setup',
            'ready': not questions, 'questions': questions,
            'instruction': ('Ask only missing choices using the real ask_user_question schema. '
                            'Record actual answers; never infer answers from config defaults or generic setup approval. '
                            'These question descriptors are not an MCP call or proof of authentic user consent.')}


def require(config):
    result = check(config)
    if not result['ready']:
        missing = ', '.join((q.get('target', '') + ':' + q['field']).strip(':') for q in result['questions'])
        raise SystemExit('USER_CHOICES_REQUIRED: ' + missing + '; run setup-check and ask only the missing choices')
