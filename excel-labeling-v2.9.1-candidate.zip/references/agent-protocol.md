# Agent protocol 2.9.1

Use scripts/agent_io.py. It transports explicit model decisions and never classifies source.

`work --job-dir JOB` returns `action`, `request_id`, `phase`, `items`, and rules when changed. Normal items have shared row_fields and target tasks. Long tasks have `text` or `text_ref`. A text_ref refers to another task ref **in this same response**, with identical original text. Resolve it before deciding; do not invent missing references. This preserves full original evidence while avoiding repeated copies for multiple targets. Audit/repair items are flat tasks; each still needs its own decision.

Submit every short reference exactly once:
```
python scripts/agent_io.py answer --job-dir JOB --stdin --next <<'JSON'
{"request_id":"<returned-id>","answers":[{"ref":"1","labels":["<approved-label>"]}]}
JSON
```
`--next` commits the answer then returns the next action/work. Do not call another work before answering an outstanding request. If the next retrieval fails after commit, the accepted answer remains persisted; work --refresh reconstructs pending work. Immediate identical retries are safe. Unknown/stale references and partial requests fail. The adapter carries exact backend identifiers internally.

For segment tasks provide a concise note preserving meaning, negation and outcome across every segment. After all segments a separate aggregate task returns the signals. Summary text for user display is never a classifier input. Use review/review_reason only for genuinely unresolved source; use taxonomy_gap/gap_reason for clearly uncovered meaning. Never combine both. Consolidation answers use canonical_label instead of labels.

Actions:
- answer: read full evidence and submit all tasks.
- start_preview: run backend preview-start.
- approve_preview: run adapter preview, provide faithful short summaries when requested, show the returned table once, then obtain real MCP approval and call adapter approve.
- resolve_input / resolve_taxonomy / investigate_reviews: resolve the specific source/rule issue; do not export.
- diagnose_audit: inspect a few disagreements, then clarify rules or backend repair-start --mode progressive; return to the same loop.
- host_capacity_required: request is retained but source was not emitted; reduce work size with --refresh or arrange verified host capacity, never truncate.
- host_context_handoff: actual host context renewal is required; read wise-integration.md. Do not fake it by renaming the session.
- finish: call adapter finish, attach verified Excel and automatically generated reusable prompt.

Use work --refresh after uncertainty/context reset; accepted work persists and rules reload. An ordinary retry must not reset the host context counter. Only one writer per job. --max-tasks is a decision cap; a complete ordinary multi-target row can exceed it. --text-budget bounds original evidence, not total tokens; one atomic piece can exceed the soft cap. Never truncate actual labeling source.

Backend commands are retained for setup/corrections and engineering diagnostics. Ordinary workflow must use the adapter through completion, including audit finalization; do not guess that labeling completion or submitted audit answers mean the file is ready.
