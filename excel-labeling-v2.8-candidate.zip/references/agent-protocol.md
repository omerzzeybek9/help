# Agent transport protocol 2.8

The public semantic interface is `scripts/agent_io.py`. It transports decisions; it never reads text to choose a label. Backend `excel_labeling.py` retains file and state validation.

## Work and answer
```
python scripts/agent_io.py work --job-dir JOB
```
An example response shape (illustrative IDs only):
```json
{"action":"answer","request_id":"c781af19b2d0","phase":"production","items":[{"mode":"row_bundle","source_row":2,"row_fields":[{"ref":"B","name":"yorum","text":"Ödeme iki kez alındı."}],"tasks":[{"ref":"1","target_id":"t001","source_refs":["B"],"context_refs":[],"mode":"row"}]}]}
```
Read complete source and the allowed source/context for each task. In audit/repair, `items` holds flat tasks with `fields`; for long work it holds complete segments or aggregate signals. Never interpret an unknown response shape as an empty queue.

Submit model-decided labels directly, e.g. with a quoted stdin heredoc through execute:
```
python scripts/agent_io.py answer --job-dir JOB --stdin <<'JSON'
{"request_id":"<exact returned value>","answers":[{"ref":"1","labels":["Ödeme"]}]}
JSON
```
Every returned reference must appear exactly once. The adapter copies leases, hashes and identifiers internally. Unknown references, extra fields and partial requests fail without committing labels. Immediate retries of the same acknowledged answer return its recorded acknowledgement.

For unresolved rows use `review:true, review_reason:"..."`; for clearly uncovered meanings use `taxonomy_gap:true, gap_reason:"..."`. Never combine both. For segment tasks include a concise `note` preserving relevant meaning and cross-segment ambiguity. Segment signals alone are not final labels; all original segments must first be read. Production and audit segment signals are kept separately.

Consolidation uses:
```json
{"request_id":"<returned>","answers":[{"ref":"1","canonical_label":"Kart teslimatı"}]}
```
It maps only the returned raw label. Material changes to business grouping require MCP approval before answering.

## Recovery
`work` replays an outstanding valid request. After an interruption/expiry or context reset, use `work --refresh` to reconstruct pending work and reload rules. Old request IDs then fail. Accepted rows remain committed. Do not rely on idempotency across arbitrary filesystem crashes: if the process died between database commit and acknowledgement persistence, refresh work; completed rows are not returned again.

Only one process may operate a job at a time. Do not run concurrent semantic workers against the same job. A short request may contain more than max-tasks when one atomic multi-target row is larger than that cap. The text budget bounds source/evidence, not total serialized tokens; one complete atomic record can exceed the soft limit. Never truncate it.

## Control commands
Use backend `inspect/sample/init/preview-start/preview-results/preview-correct/approve-preview` for setup and preview. Use `repair-start` only after diagnosed failed audit; the adapter resumes repair and fresh audit automatically. Use `quality-report` to diagnose warnings; `acknowledge-review` requires a real user decision.

`finish` passes through all backend export gates and records a byte receipt. It never approves MCP on the user's behalf and never publishes. If the host allows arbitrary file writes, it must independently gate publication; neither local hashes nor approval-source strings are a security boundary against that same host user.
