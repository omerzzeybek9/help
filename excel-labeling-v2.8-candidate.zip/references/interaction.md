# User interaction

Use the real ask_user_question MCP and the schema it actually exposes. No ordinary-message substitution for critical choices. Keep prompts in the user's language and combine related questions if supported.

## Minimal decisions
1. If purpose is absent: “Yorumlardan neyi öğrenmek istersiniz?” Offer only relevant dimensions.
2. For each target, resolve label source and one/multiple labels. “Hazır etiketlerinizi mi kullanalım, veriden mi önerelim, yoksa serbest etiket üretip benzerlerini mi birleştirelim?” “Bir yorum birden fazla konu alabilir mi?” Explicit earlier answers count; silence does not.
3. Approve a compact setup table with target, source/context/output columns, chosen path, cardinality and short label definitions. State sheet and subset once.
4. Show the shared preview, apply corrections, obtain approval before full execution.

Do not ask the user for an endpoint, API key, package installation, batch size or runtime options. If an essential tool is unavailable, explain the actual missing capability simply.

## Long preview
Show a 1–2 sentence summary, the original Excel row number and target labels. Preserve negation, material cause and mixed signals in the summary. Base classification on every original segment, not the display summary. Add a short reason only when it helps the user judge a boundary case.

## Research and independently ready targets
Keep explicitly approved choices settled. A genuinely unresolved business concept may be identified by the user or model. First ask the user or propose sensible labels from data. Announce the specific remaining concept before any research, and research abstract terminology only.

Continue discovery/preview preparation for other targets. If one unresolved target would delay full processing of independently approved targets, create one job for the ready target set, approve its setup and preview, and complete it through verified export as an internal intermediate. Later initialize the unresolved target's job from that verified intermediate, preserving all existing columns and rows. Obtain its own setup and preview approval and export to a new path. Each job has its own source hash; never change a source file under an active job. Track all requested targets and deliver only when all requested outputs are accounted for. No research-specific feature is needed in the runtime; the two-stage copy/export path must preserve prior columns.

## Completion
After attaching the verified file, state the row count and added columns. Mention blank/unresolved rows if relevant. Distribution is optional and must come from returned report counters. Offer the reusable prompt through MCP; if accepted, include approved definitions and boundaries, selected columns, one/multiple rules, and applicable corrections. Do not expose internal files.
