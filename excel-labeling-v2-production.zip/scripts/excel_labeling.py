#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
import re
import shutil
import sqlite3
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Iterator

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.utils import get_column_letter
except Exception:  # pragma: no cover
    Workbook = None
    load_workbook = None
    get_column_letter = None

SUPPORTED = {".xlsx", ".xlsm", ".csv", ".tsv"}
LONG_THRESHOLD = 10_000
SEGMENT_TARGET = 5_000
SEGMENT_OVERLAP = 250
NEXT_TEXT_BUDGET = 80_000
NEXT_MAX_ITEMS = 100
SAMPLE_RESERVOIR = 5_000
PROFILE_RESERVOIR = 10_000
UNIQUE_CAP = 5_000
LABEL_JOIN = "; "
WORD_RE = re.compile(r"\b[\wÇĞİÖŞÜçğıöşü]+\b", re.UNICODE)
SENT_BOUNDARY = re.compile(r"(?<=[.!?。！？])\s+|\n{2,}")


class RuntimeErrorCode(Exception):
    pass


def die(code: str, detail: str = "") -> None:
    msg = code if not detail else f"{code}: {detail}"
    raise SystemExit(msg)


def dump(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def read_stdin_json() -> Any:
    raw = sys.stdin.read()
    if not raw.strip():
        die("STDIN_EMPTY")
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        die("STDIN_JSON_INVALID", str(e))


def file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def clean_text(v: Any) -> str:
    if v is None:
        return ""
    return str(v)


def normalize_label(s: str) -> str:
    return " ".join(str(s or "").strip().split())


def dedupe_preserve(items: Iterable[str]) -> list[str]:
    seen = set()
    out = []
    for item in items:
        item = normalize_label(item)
        key = item.casefold()
        if item and key not in seen:
            seen.add(key)
            out.append(item)
    return out


def _ext(path: str | Path) -> str:
    e = Path(path).suffix.lower()
    if e not in SUPPORTED:
        die("UNSUPPORTED_INPUT", e or "no extension")
    return e


def list_sheets(path: str | Path) -> list[str]:
    ext = _ext(path)
    if ext in {".xlsx", ".xlsm"}:
        if load_workbook is None:
            die("MISSING_DEPENDENCY", "openpyxl")
        wb = load_workbook(path, read_only=True, data_only=False)
        names = list(wb.sheetnames)
        wb.close()
        return names
    return ["CSV"]


def iter_table(path: str | Path, sheet: str | None = None) -> Iterator[tuple[list[str], list[str], int, list[Any]]]:
    """Yield (headers, refs, physical_row_number, values) for data rows."""
    ext = _ext(path)
    if ext in {".xlsx", ".xlsm"}:
        if load_workbook is None:
            die("MISSING_DEPENDENCY", "openpyxl")
        wb = load_workbook(path, read_only=True, data_only=False)
        if sheet:
            if sheet not in wb.sheetnames:
                wb.close()
                die("SHEET_NOT_FOUND", sheet)
            ws = wb[sheet]
        else:
            ws = wb.active
        it = ws.iter_rows(values_only=True)
        try:
            first = next(it)
        except StopIteration:
            wb.close()
            die("EMPTY_INPUT")
        headers = [clean_text(v).strip() for v in first]
        refs = [get_column_letter(i + 1) for i in range(len(headers))]
        for excel_row, row in enumerate(it, start=2):
            vals = list(row)
            if len(vals) < len(headers):
                vals += [None] * (len(headers) - len(vals))
            elif len(vals) > len(headers):
                vals = vals[: len(headers)]
            yield headers, refs, excel_row, vals
        wb.close()
        return

    delim = "\t" if ext == ".tsv" else ","
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f, delimiter=delim)
        try:
            first = next(reader)
        except StopIteration:
            die("EMPTY_INPUT")
        headers = [clean_text(v).strip() for v in first]
        refs = [f"C{i + 1}" for i in range(len(headers))]
        for row_num, row in enumerate(reader, start=2):
            vals = list(row)
            if len(vals) < len(headers):
                vals += [""] * (len(headers) - len(vals))
            elif len(vals) > len(headers):
                vals = vals[: len(headers)]
            yield headers, refs, row_num, vals


def table_headers(path: str | Path, sheet: str | None = None) -> tuple[list[str], list[str]]:
    ext = _ext(path)
    if ext in {".xlsx", ".xlsm"}:
        if load_workbook is None:
            die("MISSING_DEPENDENCY", "openpyxl")
        wb = load_workbook(path, read_only=True, data_only=False)
        if sheet:
            if sheet not in wb.sheetnames:
                wb.close()
                die("SHEET_NOT_FOUND", sheet)
            ws = wb[sheet]
        else:
            ws = wb.active
        first = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), None)
        wb.close()
        if first is None:
            die("EMPTY_INPUT")
        headers = [clean_text(v).strip() for v in first]
        refs = [get_column_letter(i + 1) for i in range(len(headers))]
        return headers, refs
    delim = "\t" if ext == ".tsv" else ","
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f, delimiter=delim)
        first = next(reader, None)
    if first is None:
        die("EMPTY_INPUT")
    headers = [clean_text(v).strip() for v in first]
    refs = [f"C{i + 1}" for i in range(len(headers))]
    return headers, refs


def resolve_columns(headers: list[str], refs: list[str], requested: list[str]) -> list[int]:
    indices = []
    header_to_idxs: dict[str, list[int]] = defaultdict(list)
    for i, h in enumerate(headers):
        header_to_idxs[h].append(i)
    ref_map = {r.casefold(): i for i, r in enumerate(refs)}
    for raw in requested:
        q = str(raw).strip()
        if q.casefold() in ref_map:
            idx = ref_map[q.casefold()]
        else:
            matches = header_to_idxs.get(q, [])
            if not matches:
                # case-insensitive unique header match
                ci = [i for i, h in enumerate(headers) if h.casefold() == q.casefold()]
                matches = ci
            if len(matches) == 0:
                die("COLUMN_NOT_FOUND", q)
            if len(matches) > 1:
                choices = ", ".join(refs[i] for i in matches)
                die("COLUMN_AMBIGUOUS", f"{q} -> {choices}")
            idx = matches[0]
        if idx not in indices:
            indices.append(idx)
    return indices


def percentile(vals: list[int], p: float) -> float:
    if not vals:
        return 0.0
    vals = sorted(vals)
    x = (len(vals) - 1) * p
    a, b = math.floor(x), math.ceil(x)
    if a == b:
        return float(vals[a])
    return vals[a] + (vals[b] - vals[a]) * (x - a)


def likely_role(name: str, nonempty: int, unique_count: int, unique_capped: bool, avg_len: float, max_len: int) -> str:
    n = name.casefold()
    if any(k in n for k in ("id", "uuid", "no", "numara", "number")) and avg_len < 80:
        return "id"
    if max_len >= 500 or avg_len >= 60:
        return "text"
    if nonempty and not unique_capped and unique_count <= 50:
        return "category"
    return "mixed"


def inspect_file(path: str, sheet: str | None) -> dict[str, Any]:
    sheets = list_sheets(path)
    chosen = sheet
    if _ext(path) in {".xlsx", ".xlsm"} and chosen is None:
        chosen = sheets[0]
    headers, refs = table_headers(path, chosen)
    col_count = len(headers)
    nonempty = [0] * col_count
    sum_len = [0] * col_count
    max_len = [0] * col_count
    reservoirs: list[list[int]] = [[] for _ in range(col_count)]
    uniques: list[set[str]] = [set() for _ in range(col_count)]
    unique_capped = [False] * col_count
    rows = 0
    rng = random.Random(17)

    for hs, rs, row_num, vals in iter_table(path, chosen):
        rows += 1
        for i in range(col_count):
            text = clean_text(vals[i])
            ln = len(text)
            if text.strip():
                nonempty[i] += 1
            sum_len[i] += ln
            max_len[i] = max(max_len[i], ln)
            if len(reservoirs[i]) < PROFILE_RESERVOIR:
                reservoirs[i].append(ln)
            else:
                j = rng.randint(1, rows)
                if j <= PROFILE_RESERVOIR:
                    reservoirs[i][j - 1] = ln
            if not unique_capped[i]:
                uniques[i].add(text)
                if len(uniques[i]) > UNIQUE_CAP:
                    unique_capped[i] = True
                    uniques[i].clear()

    columns = []
    duplicate_names = Counter(headers)
    for i, (h, ref) in enumerate(zip(headers, refs)):
        name = h or f"(blank header {ref})"
        avg = sum_len[i] / rows if rows else 0
        ucount = (UNIQUE_CAP + 1) if unique_capped[i] else len(uniques[i])
        columns.append({
            "ref": ref,
            "name": name,
            "duplicate_name": bool(h and duplicate_names[h] > 1),
            "nonempty": nonempty[i],
            "empty_pct": round((rows - nonempty[i]) / max(1, rows) * 100, 2),
            "unique": f">{UNIQUE_CAP}" if unique_capped[i] else ucount,
            "length": {
                "avg": round(avg, 1),
                "p50": round(percentile(reservoirs[i], 0.50), 1),
                "p90": round(percentile(reservoirs[i], 0.90), 1),
                "p99": round(percentile(reservoirs[i], 0.99), 1),
                "max": max_len[i],
            },
            "likely_role": likely_role(name, nonempty[i], ucount, unique_capped[i], avg, max_len[i]),
            "long_text_risk": max_len[i] > LONG_THRESHOLD,
        })

    return {
        "input": os.path.abspath(path),
        "format": _ext(path).lstrip("."),
        "sheets": sheets,
        "selected_sheet": chosen,
        "rows": rows,
        "columns": columns,
        "large_file": rows >= 2_000,
        "has_long_text": any(c["long_text_risk"] for c in columns),
    }


def combined_text(headers: list[str], indices: list[int], vals: list[Any]) -> str:
    parts = []
    for idx in indices:
        value = clean_text(vals[idx])
        parts.append(f"[[{headers[idx] or f'Column {idx+1}'}]]\n{value}")
    return "\n\n".join(parts)


def _token_set(text: str, cap: int = 220) -> set[str]:
    toks = WORD_RE.findall(text.casefold())
    if len(toks) <= cap:
        return set(toks)
    # deterministic spread across the token stream
    step = max(1, len(toks) // cap)
    return set(toks[::step][:cap])


def _jaccard_distance(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 0.0
    if not a or not b:
        return 1.0
    inter = len(a & b)
    union = len(a | b)
    return 1.0 - (inter / max(1, union))


def sample_rows(path: str, sheet: str | None, columns: list[str], count: int, seed: int = 23, strategy: str = "diverse", context_columns: list[str] | None = None, exclude_rows: list[int] | None = None) -> dict[str, Any]:
    """Select non-empty rows for discovery/coverage/preview support.

    This function never classifies. It only chooses varied examples using
    deterministic lexical/length/position diversity so the model sees more
    than the first or longest rows.
    """
    if count < 1 or count > 80:
        die("SAMPLE_COUNT_INVALID", "use 1..80")
    if strategy not in {"diverse", "length"}:
        die("SAMPLE_STRATEGY_INVALID", strategy)
    headers, refs = table_headers(path, sheet)
    primary_idxs = resolve_columns(headers, refs, columns)
    context_idxs = resolve_columns(headers, refs, context_columns or []) if context_columns else []
    context_idxs = [i for i in context_idxs if i not in primary_idxs]
    idxs = primary_idxs + context_idxs
    rng = random.Random(seed)
    excluded = {int(x) for x in (exclude_rows or [])}
    reservoir: list[dict[str, Any]] = []
    nonempty_seen = 0

    for hs, rs, row_num, vals in iter_table(path, sheet):
        if row_num in excluded:
            continue
        if not any(clean_text(vals[i]).strip() for i in primary_idxs):
            continue
        text = combined_text(headers, idxs, vals)
        nonempty_seen += 1
        rec = {
            "row_num": row_num,
            "length": len(text),
            "text_for_similarity": text[:8000],
        }
        if len(reservoir) < SAMPLE_RESERVOIR:
            reservoir.append(rec)
        else:
            j = rng.randint(1, nonempty_seen)
            if j <= SAMPLE_RESERVOIR:
                reservoir[j - 1] = rec

    if not reservoir:
        return {"rows": [], "columns": [refs[i] for i in idxs], "note": "No non-empty source rows"}

    # Remove exact duplicates for sampling only; original duplicates remain in the data.
    deduped = []
    seen_hashes = set()
    for r in reservoir:
        h = hashlib.sha256(r["text_for_similarity"].strip().casefold().encode("utf-8")).hexdigest()
        if h in seen_hashes:
            continue
        seen_hashes.add(h)
        r["tokens"] = _token_set(r["text_for_similarity"])
        deduped.append(r)
    pool = deduped or reservoir

    if strategy == "length":
        pool = sorted(pool, key=lambda r: (r["length"], r["row_num"]))
        chosen = []
        for i in range(min(count, len(pool))):
            idx = 0 if count == 1 else round(i * (len(pool) - 1) / max(1, min(count, len(pool)) - 1))
            if pool[idx] not in chosen:
                chosen.append(pool[idx])
    else:
        # Candidate cap keeps selection fast on very large files.
        if len(pool) > 1200:
            rng.shuffle(pool)
            pool = pool[:1200]
        pool.sort(key=lambda r: r["row_num"])
        max_len = max(r["length"] for r in pool) or 1
        min_row = min(r["row_num"] for r in pool)
        max_row = max(r["row_num"] for r in pool)
        span = max(1, max_row - min_row)

        # Start with a central row, then greedily maximize novelty + position + length spread.
        chosen = [pool[len(pool)//2]]
        while len(chosen) < min(count, len(pool)):
            best = None
            best_score = -1.0
            chosen_ids = {x["row_num"] for x in chosen}
            for r in pool:
                if r["row_num"] in chosen_ids:
                    continue
                semantic_novelty = min(_jaccard_distance(r.get("tokens", set()), c.get("tokens", set())) for c in chosen)
                position_novelty = min(abs(r["row_num"] - c["row_num"]) / span for c in chosen)
                length_novelty = min(abs(r["length"] - c["length"]) / max_len for c in chosen)
                score = 0.72 * semantic_novelty + 0.18 * position_novelty + 0.10 * length_novelty
                if score > best_score:
                    best_score, best = score, r
            if best is None:
                break
            chosen.append(best)

    chosen_nums = [r["row_num"] for r in chosen]
    chosen_set = set(chosen_nums)
    found: dict[int, dict[str, Any]] = {}
    for hs, rs, row_num, vals in iter_table(path, sheet):
        if row_num not in chosen_set:
            continue
        fields = []
        for idx in idxs:
            val = clean_text(vals[idx])
            cap = 4000
            fields.append({
                "ref": refs[idx],
                "name": headers[idx] or f"Column {idx+1}",
                "role": "source" if idx in primary_idxs else "context",
                "text": val if len(val) <= cap else val[:cap] + "…",
                "length": len(val),
                "display_truncated": len(val) > cap,
            })
        found[row_num] = {"row_key": f"r{row_num:08d}", "source_row": row_num, "fields": fields}
        if len(found) == len(chosen_set):
            break

    ordered = [found[n] for n in chosen_nums if n in found]
    return {
        "rows": ordered,
        "columns": [refs[i] for i in primary_idxs],
        "context_columns": [refs[i] for i in context_idxs],
        "strategy": strategy,
        "seed": seed,
        "nonempty_seen": nonempty_seen,
        "sampled_unique_candidates": len(pool),
        "excluded_rows": len(excluded),
    }


def validate_config(cfg: dict[str, Any], headers: list[str], refs: list[str]) -> dict[str, Any]:
    if not isinstance(cfg, dict):
        die("CONFIG_INVALID", "root must be object")
    targets = cfg.get("targets")
    if not isinstance(targets, list) or not targets:
        die("CONFIG_INVALID", "targets must be a non-empty array")
    out_cols = set(headers)
    names = set()
    canonical_targets = []
    for ti, target in enumerate(targets, start=1):
        if not isinstance(target, dict):
            die("CONFIG_INVALID", f"target {ti} must be object")
        name = normalize_label(target.get("name", ""))
        if not name:
            die("CONFIG_INVALID", f"target {ti} name missing")
        if name.casefold() in {x.casefold() for x in names}:
            die("CONFIG_INVALID", f"duplicate target name {name}")
        names.add(name)
        purpose = clean_text(target.get("purpose", "")).strip()

        source_cols = target.get("source_columns")
        if not isinstance(source_cols, list) or not source_cols:
            die("CONFIG_INVALID", f"{name}: source_columns missing")
        source_idxs = resolve_columns(headers, refs, [str(x) for x in source_cols])
        source_refs = [refs[i] for i in source_idxs]
        source_names = [headers[i] or f"Column {i+1}" for i in source_idxs]

        context_cols = target.get("context_columns", [])
        if context_cols is None:
            context_cols = []
        if not isinstance(context_cols, list):
            die("CONFIG_INVALID", f"{name}: context_columns must be array")
        context_idxs = resolve_columns(headers, refs, [str(x) for x in context_cols]) if context_cols else []
        # Do not repeat primary columns as context.
        context_idxs = [i for i in context_idxs if i not in source_idxs]
        context_refs = [refs[i] for i in context_idxs]
        context_names = [headers[i] or f"Column {i+1}" for i in context_idxs]

        output_col = normalize_label(target.get("output_column", "")) or f"{name}_label"
        if output_col in out_cols:
            die("OUTPUT_COLUMN_CONFLICT", output_col)
        out_cols.add(output_col)

        label_source = str(target.get("label_source", "")).strip().lower()
        if label_source not in {"user", "proposed", "freeform"}:
            die("CONFIG_INVALID", f"{name}: label_source")
        cardinality = str(target.get("cardinality", "")).strip().lower()
        if cardinality not in {"single", "multi"}:
            die("CONFIG_INVALID", f"{name}: cardinality")

        labels_raw = target.get("labels", [])
        labels = []
        if label_source != "freeform":
            if not isinstance(labels_raw, list) or not labels_raw:
                die("CONFIG_INVALID", f"{name}: fixed labels required")
            seen = set()
            for item in labels_raw:
                if isinstance(item, str):
                    label_name = normalize_label(item)
                    definition = ""
                    include, exclude, examples = [], [], []
                elif isinstance(item, dict):
                    label_name = normalize_label(item.get("name", ""))
                    definition = clean_text(item.get("definition", "")).strip()
                    include = [clean_text(x).strip() for x in item.get("include", []) if clean_text(x).strip()]
                    exclude = [clean_text(x).strip() for x in item.get("exclude", []) if clean_text(x).strip()]
                    examples = [clean_text(x).strip() for x in item.get("examples", []) if clean_text(x).strip()]
                else:
                    die("CONFIG_INVALID", f"{name}: invalid label")
                if not label_name:
                    die("CONFIG_INVALID", f"{name}: empty label")
                key = label_name.casefold()
                if key in seen:
                    die("CONFIG_INVALID", f"{name}: duplicate label {label_name}")
                seen.add(key)
                labels.append({"name": label_name, "definition": definition, "include": include, "exclude": exclude, "examples": examples})

        canonical_targets.append({
            "id": f"t{ti:03d}",
            "name": name,
            "purpose": purpose,
            "source_columns": source_refs,
            "source_column_names": source_names,
            "context_columns": context_refs,
            "context_column_names": context_names,
            "output_column": output_col,
            "label_source": label_source,
            "cardinality": cardinality,
            "labels": labels,
        })
    return {"version": str(cfg.get("version", "2.0")), "targets": canonical_targets}


def split_long(text: str, target: int = SEGMENT_TARGET, overlap: int = SEGMENT_OVERLAP) -> list[str]:
    if len(text) <= target:
        return [text]
    boundaries = [0]
    for m in SENT_BOUNDARY.finditer(text):
        boundaries.append(m.end())
    if boundaries[-1] != len(text):
        boundaries.append(len(text))
    segments: list[tuple[int, int]] = []
    start = 0
    while start < len(text):
        desired = min(len(text), start + target)
        # choose latest natural boundary within a useful window
        candidates = [b for b in boundaries if start + max(500, target // 2) <= b <= desired]
        end = max(candidates) if candidates else desired
        if end <= start:
            end = min(len(text), start + target)
        segments.append((start, end))
        if end >= len(text):
            break
        start = max(start + 1, end - overlap)
    return [text[s:e] for s, e in segments]


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def append_jsonl(path: Path, obj: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    out = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                out.append(json.loads(line))
    return out


def indexed_jsonl(path: Path, key: str) -> dict[str, dict[str, Any]]:
    return {str(x[key]): x for x in read_jsonl(path)}


def target_rule_for_agent(t: dict[str, Any]) -> dict[str, Any]:
    return {
        "target_id": t["id"],
        "target_name": t["name"],
        "purpose": t.get("purpose", ""),
        "source_columns": t["source_column_names"],
        "context_columns": t.get("context_column_names", []),
        "cardinality": t["cardinality"],
        "label_source": t["label_source"],
        "labels": t["labels"],
        "semantic_contract": {
            "classify_by_meaning": True,
            "keyword_matching_is_not_sufficient": True,
            "taxonomy_gap_must_not_be_hidden_as_review": True,
        },
    }


def db_path(jd: Path) -> Path:
    return jd / "state.sqlite3"


def db_connect(jd: Path):
    import sqlite3
    db = sqlite3.connect(db_path(jd))
    db.row_factory = sqlite3.Row
    return db


def init_db(jd: Path) -> None:
    db = db_connect(jd)
    db.executescript("""
    PRAGMA journal_mode=WAL;
    PRAGMA synchronous=NORMAL;
    CREATE TABLE work (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        unit_id TEXT UNIQUE NOT NULL,
        target_id TEXT NOT NULL,
        row_key TEXT NOT NULL,
        source_row INTEGER NOT NULL,
        fields_json TEXT NOT NULL,
        text TEXT NOT NULL,
        text_length INTEGER NOT NULL,
        is_long INTEGER NOT NULL,
        content_hash TEXT NOT NULL
    );
    CREATE INDEX idx_work_target ON work(target_id);
    CREATE INDEX idx_work_hash ON work(target_id, content_hash);
    CREATE TABLE results (
        unit_id TEXT PRIMARY KEY,
        target_id TEXT NOT NULL,
        row_key TEXT NOT NULL,
        labels_json TEXT NOT NULL,
        state TEXT NOT NULL,
        review_reason TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX idx_results_target ON results(target_id);
    CREATE TABLE segment_results (
        unit_id TEXT PRIMARY KEY,
        parent_unit_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        labels_json TEXT NOT NULL,
        note TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX idx_segments_parent ON segment_results(parent_unit_id);
    CREATE TABLE consolidation (
        target_id TEXT NOT NULL,
        raw_label TEXT NOT NULL,
        canonical_label TEXT NOT NULL,
        PRIMARY KEY(target_id, raw_label)
    );
    CREATE TABLE preview (
        unit_id TEXT PRIMARY KEY,
        target_id TEXT NOT NULL,
        rank INTEGER NOT NULL
    );
    """)
    db.commit(); db.close()


def init_job(input_path: str, sheet: str | None, job_dir: str, config_path: str, setup_approval_source: str) -> dict[str, Any]:
    if setup_approval_source != "ask_user_question":
        die("SETUP_APPROVAL_REQUIRED", "approval must come from ask_user_question")
    jd = Path(job_dir)
    if jd.exists() and any(jd.iterdir()):
        die("JOB_DIR_NOT_EMPTY", str(jd))
    jd.mkdir(parents=True, exist_ok=True)
    headers, refs = table_headers(input_path, sheet)
    raw_cfg = load_json(Path(config_path))
    cfg = validate_config(raw_cfg, headers, refs)
    selected_sheet = sheet or (list_sheets(input_path)[0] if _ext(input_path) in {".xlsx", ".xlsm"} else "CSV")
    meta = {
        "input": os.path.abspath(input_path),
        "input_sha256": file_sha256(input_path),
        "format": _ext(input_path).lstrip("."),
        "sheet": selected_sheet,
        "headers": headers,
        "refs": refs,
        "rows": 0,
        "long_units": 0,
        "phase": "DRAFT",
        "setup_approval_source": setup_approval_source,
        "preview_approval_source": None,
    }
    (jd / "config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    (jd / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    init_db(jd)

    source_indices = {t["id"]: resolve_columns(headers, refs, t["source_columns"]) for t in cfg["targets"]}
    context_indices = {t["id"]: resolve_columns(headers, refs, t.get("context_columns", [])) if t.get("context_columns") else [] for t in cfg["targets"]}
    db = db_connect(jd)
    rows = 0; long_units = 0
    try:
        for hs, rs, row_num, vals in iter_table(input_path, sheet):
            rows += 1
            row_key = f"r{row_num:08d}"
            for t in cfg["targets"]:
                src_idxs = source_indices[t["id"]]
                ctx_idxs = context_indices[t["id"]]
                fields = []
                for i in src_idxs:
                    fields.append({"ref": refs[i], "name": headers[i] or f"Column {i+1}", "role": "source", "text": clean_text(vals[i])})
                for i in ctx_idxs:
                    fields.append({"ref": refs[i], "name": headers[i] or f"Column {i+1}", "role": "context", "text": clean_text(vals[i])})
                text = "\n\n".join(f"[[{f['role'].upper()}: {f['name']}]]\n{f['text']}" for f in fields)
                actual_nonempty = any(clean_text(vals[i]).strip() for i in src_idxs)
                uid = f"{t['id']}:{row_key}"
                is_long = int(bool(actual_nonempty and len(text) > LONG_THRESHOLD))
                content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
                db.execute(
                    "INSERT INTO work(unit_id,target_id,row_key,source_row,fields_json,text,text_length,is_long,content_hash) VALUES(?,?,?,?,?,?,?,?,?)",
                    (uid,t["id"],row_key,row_num,json.dumps(fields,ensure_ascii=False,separators=(",",":")),text,len(text),is_long,content_hash)
                )
                if not actual_nonempty:
                    db.execute(
                        "INSERT INTO results(unit_id,target_id,row_key,labels_json,state,review_reason) VALUES(?,?,?,?,?,?)",
                        (uid,t["id"],row_key,"[]","EMPTY","")
                    )
                elif is_long:
                    long_units += 1
            if rows % 1000 == 0:
                db.commit()
        db.commit()
    finally:
        db.close()
    meta["rows"] = rows; meta["long_units"] = long_units
    (jd / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"job_dir": str(jd.resolve()), "rows": rows, "targets": len(cfg["targets"]), "long_units": long_units}


def load_job(jd: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    if not (jd / "meta.json").exists() or not db_path(jd).exists():
        die("JOB_NOT_FOUND", str(jd))
    return load_json(jd / "config.json"), load_json(jd / "meta.json")


def _next_work_internal(jd: Path, text_budget: int, max_items: int, preview_only: bool) -> dict[str, Any]:
    cfg, meta = load_job(jd)
    targets = {t["id"]: t for t in cfg["targets"]}
    db = db_connect(jd)
    items=[]; used=0; relevant=set(); seen_content_hashes=set()
    try:
        if preview_only:
            rows = db.execute("""
                SELECT w.* FROM work w
                JOIN preview p ON p.unit_id=w.unit_id
                LEFT JOIN results r ON r.unit_id=w.unit_id
                WHERE r.unit_id IS NULL
                ORDER BY p.rank, w.seq
                LIMIT 200
            """).fetchall()
        else:
            if meta.get("phase") != "APPROVED":
                die("PREVIEW_NOT_APPROVED")
            rows = db.execute("""
                SELECT w.* FROM work w
                LEFT JOIN results r ON r.unit_id=w.unit_id
                WHERE r.unit_id IS NULL
                ORDER BY w.seq
                LIMIT 200
            """).fetchall()
        for rec in rows:
            uid=rec["unit_id"]; t=targets[rec["target_id"]]; relevant.add(t["id"])
            if not rec["is_long"]:
                if rec["content_hash"] in seen_content_hashes:
                    continue
                seen_content_hashes.add(rec["content_hash"])
                cost=max(1,rec["text_length"])
                if items and (used+cost>text_budget or len(items)>=max_items): break
                items.append({"mode":"row","unit_id":uid,"target_id":t["id"],"source_row":rec["source_row"],"fields":json.loads(rec["fields_json"]),"source_length":rec["text_length"]})
                used+=cost
                if len(items)>=max_items: break
                continue
            segs=split_long(rec["text"])
            existing={r["unit_id"]:r for r in db.execute("SELECT unit_id,labels_json,note FROM segment_results WHERE parent_unit_id=?",(uid,)).fetchall()}
            missing=[]
            for i,seg in enumerate(segs,1):
                sid=f"{uid}:s{i:04d}"
                if sid not in existing: missing.append((sid,i,seg))
            if missing:
                for sid,i,seg in missing:
                    cost=len(seg)
                    if items and (used+cost>text_budget or len(items)>=max_items): break
                    items.append({"mode":"segment","unit_id":sid,"parent_unit_id":uid,"target_id":t["id"],"source_row":rec["source_row"],"segment_index":i,"segment_count":len(segs),"text":seg,"source_length":rec["text_length"]})
                    used+=cost
                    if len(items)>=max_items: break
                if items: break
            else:
                signals=[]
                for i in range(1,len(segs)+1):
                    sid=f"{uid}:s{i:04d}"; sr=existing[sid]
                    signals.append({"segment_index":i,"labels":json.loads(sr["labels_json"]),"note":sr["note"]})
                items.append({"mode":"aggregate","unit_id":uid,"target_id":t["id"],"source_row":rec["source_row"],"source_length":rec["text_length"],"segment_signals":signals})
                break
        if preview_only:
            remaining=db.execute("SELECT COUNT(*) FROM preview p LEFT JOIN results r ON r.unit_id=p.unit_id WHERE r.unit_id IS NULL").fetchone()[0]
        else:
            remaining=db.execute("SELECT COUNT(*) FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id WHERE r.unit_id IS NULL").fetchone()[0]
    finally:
        db.close()
    return {"work_items":items,"target_rules":[target_rule_for_agent(targets[x]) for x in sorted(relevant)],"remaining":remaining,"preview":preview_only}


def next_work(jd: Path, text_budget: int, max_items: int) -> dict[str, Any]:
    return _next_work_internal(jd, text_budget, max_items, False)


def preview_start(jd: Path, count: int, source_rows: list[int] | None = None) -> dict[str, Any]:
    if count < 1 or count > 10:
        die("PREVIEW_COUNT_INVALID", "use 1..10")
    cfg, meta = load_job(jd)
    if meta.get("phase") != "DRAFT":
        die("JOB_NOT_DRAFT")
    db = db_connect(jd)
    selected=[]
    try:
        db.execute("DELETE FROM preview")
        rank=0
        requested = [int(x) for x in (source_rows or [])]
        for t in cfg["targets"]:
            seen_hashes=set()
            rows=[]
            if requested:
                qmarks=",".join("?" for _ in requested)
                rows=db.execute(f"""
                    SELECT w.* FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id
                    WHERE w.target_id=? AND w.source_row IN ({qmarks}) AND r.unit_id IS NULL
                    ORDER BY w.source_row
                """, [t["id"], *requested]).fetchall()
            if not rows:
                # Pull a bounded set across length distribution, then keep distinct contents.
                total=db.execute("SELECT COUNT(*) FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id WHERE w.target_id=? AND r.unit_id IS NULL",(t["id"],)).fetchone()[0]
                if total==0:
                    continue
                offsets=[]
                probe=max(count*4, min(40,total))
                for i in range(probe):
                    offsets.append(0 if probe==1 else round(i*(total-1)/(probe-1)))
                for off in offsets:
                    r=db.execute("""
                        SELECT w.* FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id
                        WHERE w.target_id=? AND r.unit_id IS NULL
                        ORDER BY w.text_length,w.seq LIMIT 1 OFFSET ?
                    """,(t["id"],off)).fetchone()
                    if r:
                        rows.append(r)
            for row in rows:
                if row["content_hash"] in seen_hashes:
                    continue
                seen_hashes.add(row["content_hash"])
                rank+=1
                db.execute("INSERT INTO preview(unit_id,target_id,rank) VALUES(?,?,?)",(row["unit_id"],row["target_id"],rank))
                selected.append({"unit_id":row["unit_id"],"target_id":row["target_id"],"source_row":row["source_row"],"source_length":row["text_length"]})
                if len([x for x in selected if x["target_id"]==t["id"]]) >= count:
                    break
        db.commit()
    finally: db.close()
    return {"selected":selected,"count":len(selected)}


def preview_next(jd: Path, text_budget: int, max_items: int) -> dict[str, Any]:
    cfg, meta = load_job(jd)
    if meta.get("phase") != "DRAFT":
        die("JOB_NOT_DRAFT")
    db=db_connect(jd)
    try:
        n=db.execute("SELECT COUNT(*) FROM preview").fetchone()[0]
    finally: db.close()
    if n==0: die("PREVIEW_NOT_STARTED")
    return _next_work_internal(jd,text_budget,max_items,True)


def preview_results(jd: Path) -> dict[str, Any]:
    cfg,meta=load_job(jd); db=db_connect(jd); tmap={t["id"]:t for t in cfg["targets"]}; out=[]
    try:
        rows=db.execute("""
            SELECT p.rank,w.unit_id,w.target_id,w.source_row,w.fields_json,w.text_length,r.labels_json,r.state,r.review_reason
            FROM preview p JOIN work w ON w.unit_id=p.unit_id
            LEFT JOIN results r ON r.unit_id=w.unit_id
            ORDER BY p.rank
        """).fetchall()
        for r in rows:
            fields=json.loads(r["fields_json"])
            display=[]
            for f in fields:
                text=f["text"]
                display.append({"name":f["name"],"text":text if len(text)<=1200 else text[:1200]+"…","full_length":len(text),"display_truncated":len(text)>1200})
            out.append({"target":tmap[r["target_id"]]["name"],"unit_id":r["unit_id"],"source_row":r["source_row"],"source_preview":display,"labels":json.loads(r["labels_json"]) if r["labels_json"] is not None else None,"state":r["state"]})
    finally: db.close()
    return {"preview_results":out,"complete":all(x["state"] is not None for x in out) and bool(out)}


def _propagate_exact_duplicates(db, target_id: str, content_hash: str, source_unit_id: str) -> int:
    src = db.execute("SELECT labels_json,state,review_reason FROM results WHERE unit_id=?", (source_unit_id,)).fetchone()
    if not src:
        return 0
    rows = db.execute("""
        SELECT w.unit_id,w.row_key FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id
        WHERE w.target_id=? AND w.content_hash=? AND r.unit_id IS NULL
    """, (target_id, content_hash)).fetchall()
    n=0
    for r in rows:
        db.execute("INSERT INTO results(unit_id,target_id,row_key,labels_json,state,review_reason) VALUES(?,?,?,?,?,?)",
                   (r["unit_id"],target_id,r["row_key"],src["labels_json"],src["state"],src["review_reason"]))
        n+=1
    return n


def approve_preview(jd: Path, approval_source: str) -> dict[str, Any]:
    if approval_source != "ask_user_question":
        die("PREVIEW_APPROVAL_REQUIRED", "approval must come from ask_user_question")
    cfg,meta=load_job(jd)
    if meta.get("phase") != "DRAFT": die("JOB_NOT_DRAFT")
    db=db_connect(jd)
    propagated=0
    try:
        n=db.execute("SELECT COUNT(*) FROM preview").fetchone()[0]
        pending=db.execute("SELECT COUNT(*) FROM preview p LEFT JOIN results r ON r.unit_id=p.unit_id WHERE r.unit_id IS NULL").fetchone()[0]
        if n==0: die("PREVIEW_NOT_STARTED")
        if pending: die("PREVIEW_INCOMPLETE",str(pending))
        # Once the user approves the preview, exact duplicate rows may safely reuse those decisions.
        rows=db.execute("""
            SELECT p.unit_id,w.target_id,w.content_hash FROM preview p JOIN work w ON w.unit_id=p.unit_id
        """).fetchall()
        for r in rows:
            propagated += _propagate_exact_duplicates(db,r["target_id"],r["content_hash"],r["unit_id"])
        db.commit()
    finally: db.close()
    meta["phase"]="APPROVED"
    meta["preview_approval_source"]=approval_source
    (jd/"meta.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
    return {"approved":True,"preview_rows":n,"duplicate_results_reused":propagated}


def _validate_labels(labels: Any, target: dict[str, Any], final: bool) -> list[str]:
    if labels is None: labels=[]
    if not isinstance(labels,list): die("DECISION_INVALID","labels must be an array")
    labels=dedupe_preserve([clean_text(x) for x in labels])
    if target["label_source"]!="freeform":
        allowed={x["name"].casefold():x["name"] for x in target["labels"]}
        fixed=[]
        for lab in labels:
            if lab.casefold() not in allowed: die("UNKNOWN_LABEL",f"{target['name']}: {lab}")
            fixed.append(allowed[lab.casefold()])
        labels=fixed
    if final and target["cardinality"]=="single" and len(labels)>1:
        die("CARDINALITY_VIOLATION",target["name"])
    return labels


def submit(jd: Path, payload: Any) -> dict[str, Any]:
    cfg, meta=load_job(jd); targets={t["id"]:t for t in cfg["targets"]}
    decisions=payload if isinstance(payload,list) else payload.get("decisions") if isinstance(payload,dict) else None
    if not isinstance(decisions,list) or not decisions: die("DECISION_INVALID","expected non-empty array")
    db=db_connect(jd); committed=0; propagated=0
    try:
        for d in decisions:
            if not isinstance(d,dict): die("DECISION_INVALID","decision must be object")
            uid=clean_text(d.get("unit_id")).strip()
            if not uid: die("DECISION_INVALID","unit_id missing")
            is_seg=bool(re.search(r":s\d{4}$",uid))
            if is_seg:
                if db.execute("SELECT 1 FROM segment_results WHERE unit_id=?",(uid,)).fetchone(): die("DUPLICATE_DECISION",uid)
                parent=uid.rsplit(":s",1)[0]
                rec=db.execute("SELECT * FROM work WHERE unit_id=?",(parent,)).fetchone()
                if not rec or not rec["is_long"]: die("UNKNOWN_UNIT",uid)
                target=targets[rec["target_id"]]; segs=split_long(rec["text"])
                try: seg_num=int(uid.rsplit(":s",1)[1])
                except Exception: die("UNKNOWN_UNIT",uid)
                if seg_num<1 or seg_num>len(segs): die("UNKNOWN_UNIT",uid)
                labels=_validate_labels(d.get("labels",[]),target,False)
                note=clean_text(d.get("note","")).strip()[:400]
                db.execute("INSERT INTO segment_results(unit_id,parent_unit_id,target_id,labels_json,note) VALUES(?,?,?,?,?)",(uid,parent,target["id"],json.dumps(labels,ensure_ascii=False,separators=(",",":")),note))
                committed+=1; continue

            if db.execute("SELECT 1 FROM results WHERE unit_id=?",(uid,)).fetchone(): die("DUPLICATE_DECISION",uid)
            rec=db.execute("SELECT * FROM work WHERE unit_id=?",(uid,)).fetchone()
            if not rec: die("UNKNOWN_UNIT",uid)
            target=targets[rec["target_id"]]
            if rec["is_long"]:
                segs=split_long(rec["text"])
                n=db.execute("SELECT COUNT(*) FROM segment_results WHERE parent_unit_id=?",(uid,)).fetchone()[0]
                if n<len(segs): die("LONG_ROW_INCOMPLETE",uid)

            review=bool(d.get("review",False))
            taxonomy_gap=bool(d.get("taxonomy_gap",False))
            if review and taxonomy_gap:
                die("DECISION_INVALID", "review and taxonomy_gap cannot both be true")
            if taxonomy_gap:
                labels=[]; state="TAXONOMY_GAP"; reason=clean_text(d.get("gap_reason",d.get("review_reason",""))).strip()[:500]
                if not reason: reason="Meaning is clear but approved labels do not cover it"
            elif review:
                labels=[]; state="REVIEW"; reason=clean_text(d.get("review_reason","")).strip()[:500]
                if not reason: reason="Genuinely ambiguous or insufficient information"
            else:
                labels=_validate_labels(d.get("labels",[]),target,True)
                if not labels: die("FINAL_LABEL_MISSING",uid)
                state="LABELED"; reason=""
            db.execute("INSERT INTO results(unit_id,target_id,row_key,labels_json,state,review_reason) VALUES(?,?,?,?,?,?)",(uid,target["id"],rec["row_key"],json.dumps(labels,ensure_ascii=False,separators=(",",":")),state,reason))
            committed+=1

            # Reuse exact-identical content only after preview approval. This is deterministic and safe.
            if meta.get("phase") == "APPROVED":
                propagated += _propagate_exact_duplicates(db,target["id"],rec["content_hash"],uid)
        db.commit()
    finally: db.close()
    return {"committed":committed,"duplicate_results_reused":propagated}


def status(jd: Path) -> dict[str, Any]:
    cfg,meta=load_job(jd); db=db_connect(jd); out=[]
    try:
        for t in cfg["targets"]:
            tid=t["id"]
            rows=db.execute("SELECT COUNT(*) FROM work WHERE target_id=?",(tid,)).fetchone()[0]
            completed=db.execute("SELECT COUNT(*) FROM results WHERE target_id=?",(tid,)).fetchone()[0]
            labeled=db.execute("SELECT COUNT(*) FROM results WHERE target_id=? AND state='LABELED'",(tid,)).fetchone()[0]
            review=db.execute("SELECT COUNT(*) FROM results WHERE target_id=? AND state='REVIEW'",(tid,)).fetchone()[0]
            gaps=db.execute("SELECT COUNT(*) FROM results WHERE target_id=? AND state='TAXONOMY_GAP'",(tid,)).fetchone()[0]
            empty=db.execute("SELECT COUNT(*) FROM results WHERE target_id=? AND state='EMPTY'",(tid,)).fetchone()[0]
            long_rows=db.execute("SELECT COUNT(*) FROM work WHERE target_id=? AND is_long=1",(tid,)).fetchone()[0]
            out.append({"target":t["name"],"rows":rows,"completed":completed,"labeled":labeled,"review":review,"taxonomy_gap":gaps,"empty":empty,"pending":rows-completed,"long_rows":long_rows,"label_source":t["label_source"]})
    finally: db.close()
    return {"phase":meta.get("phase","UNKNOWN"),"targets":out}


def raw_freeform_counts(jd: Path, target_id: str) -> Counter:
    db=db_connect(jd); c=Counter()
    try:
        rows=db.execute("SELECT labels_json FROM results WHERE target_id=? AND state='LABELED'",(target_id,)).fetchall()
        for r in rows:
            for lab in json.loads(r["labels_json"]): c[lab]+=1
    finally: db.close()
    return c


def consolidation_next(jd: Path, limit: int) -> dict[str, Any]:
    cfg,meta=load_job(jd); db=db_connect(jd)
    try:
        for t in cfg["targets"]:
            if t["label_source"]!="freeform": continue
            counts=raw_freeform_counts(jd,t["id"])
            mapped={r["raw_label"] for r in db.execute("SELECT raw_label FROM consolidation WHERE target_id=?",(t["id"],)).fetchall()}
            remaining=[(lab,n) for lab,n in counts.most_common() if lab not in mapped]
            if remaining:
                take=remaining[:limit]
                return {"groups":[{"target_id":t["id"],"target_name":t["name"],"cardinality":t["cardinality"],"labels":[{"raw_label":lab,"count":n} for lab,n in take],"remaining_after_this":max(0,len(remaining)-len(take))}]}
    finally: db.close()
    return {"groups":[]}


def consolidation_submit(jd: Path, payload: Any) -> dict[str, Any]:
    cfg,meta=load_job(jd); targets={t["id"]:t for t in cfg["targets"]}
    mappings=payload if isinstance(payload,list) else payload.get("mappings") if isinstance(payload,dict) else None
    if not isinstance(mappings,list) or not mappings: die("CONSOLIDATION_INVALID","expected non-empty array")
    db=db_connect(jd); added=0
    try:
        counts_cache={}
        for m in mappings:
            tid=clean_text(m.get("target_id")).strip(); raw=normalize_label(m.get("raw_label",'')); canon=normalize_label(m.get("canonical_label",''))
            if tid not in targets or targets[tid]["label_source"]!="freeform": die("CONSOLIDATION_INVALID",f"invalid target {tid}")
            if not raw or not canon: die("CONSOLIDATION_INVALID","labels cannot be blank")
            if tid not in counts_cache: counts_cache[tid]=raw_freeform_counts(jd,tid)
            if raw not in counts_cache[tid]: die("CONSOLIDATION_INVALID",f"unknown raw label {raw}")
            try:
                db.execute("INSERT INTO consolidation(target_id,raw_label,canonical_label) VALUES(?,?,?)",(tid,raw,canon))
            except Exception:
                die("CONSOLIDATION_DUPLICATE",f"{tid}:{raw}")
            added+=1
        db.commit()
    finally: db.close()
    return {"mappings_added":added}


def quality_report(jd: Path, sample_limit: int = 12) -> dict[str, Any]:
    cfg,meta=load_job(jd); db=db_connect(jd); reports=[]
    try:
        for t in cfg["targets"]:
            tid=t["id"]
            total=db.execute("SELECT COUNT(*) FROM work WHERE target_id=?",(tid,)).fetchone()[0]
            nonempty=db.execute("SELECT COUNT(*) FROM work w JOIN results r ON r.unit_id=w.unit_id WHERE w.target_id=? AND r.state!='EMPTY'",(tid,)).fetchone()[0]
            review=db.execute("SELECT COUNT(*) FROM results WHERE target_id=? AND state='REVIEW'",(tid,)).fetchone()[0]
            gaps=db.execute("SELECT COUNT(*) FROM results WHERE target_id=? AND state='TAXONOMY_GAP'",(tid,)).fetchone()[0]
            labeled=db.execute("SELECT COUNT(*) FROM results WHERE target_id=? AND state='LABELED'",(tid,)).fetchone()[0]
            label_counts=Counter()
            for r in db.execute("SELECT labels_json FROM results WHERE target_id=? AND state='LABELED'",(tid,)).fetchall():
                for lab in json.loads(r["labels_json"]): label_counts[lab]+=1
            reasons=[]
            for r in db.execute("""
                SELECT w.source_row,w.fields_json,r.state,r.review_reason FROM results r JOIN work w ON w.unit_id=r.unit_id
                WHERE r.target_id=? AND r.state IN ('REVIEW','TAXONOMY_GAP') ORDER BY w.source_row LIMIT ?
            """,(tid,sample_limit)).fetchall():
                fields=json.loads(r["fields_json"])
                preview=" | ".join(clean_text(f.get("text",""))[:300] for f in fields if f.get("role")=="source")
                reasons.append({"source_row":r["source_row"],"state":r["state"],"reason":r["review_reason"],"source_preview":preview})
            reports.append({
                "target":t["name"],
                "total_rows":total,
                "nonempty_completed":nonempty,
                "labeled":labeled,
                "review":review,
                "taxonomy_gap":gaps,
                "review_rate_pct":round(review/max(1,nonempty)*100,2),
                "taxonomy_gap_rate_pct":round(gaps/max(1,nonempty)*100,2),
                "label_distribution":dict(label_counts.most_common()),
                "problem_samples":reasons,
            })
    finally: db.close()
    return {"phase":meta.get("phase"),"targets":reports}


def validate_job(jd: Path) -> dict[str, Any]:
    cfg,meta=load_job(jd); targets={t["id"]:t for t in cfg["targets"]}; errors=[]
    if meta.get("setup_approval_source") != "ask_user_question":
        errors.append("SETUP_APPROVAL_SOURCE_INVALID")
    if meta.get("preview_approval_source") != "ask_user_question":
        errors.append("PREVIEW_APPROVAL_SOURCE_INVALID")
    if meta.get("phase") != "APPROVED":
        errors.append("PREVIEW_NOT_APPROVED")
    db=db_connect(jd)
    try:
        pending=db.execute("SELECT w.unit_id AS unit_id FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id WHERE r.unit_id IS NULL LIMIT 201").fetchall()
        errors += [f"MISSING_FINAL:{r['unit_id']}" for r in pending[:200]]
        unknown=db.execute("SELECT r.unit_id FROM results r LEFT JOIN work w ON w.unit_id=r.unit_id WHERE w.unit_id IS NULL LIMIT 200").fetchall()
        errors += [f"UNKNOWN_FINAL:{r['unit_id']}" for r in unknown]
        labeled=db.execute("SELECT r.*,w.is_long,w.text,w.target_id AS wtid FROM results r JOIN work w ON w.unit_id=r.unit_id").fetchall()
        for r in labeled:
            t=targets[r["target_id"]]; labels=json.loads(r["labels_json"]); state=r["state"]
            if state not in {"LABELED","REVIEW","EMPTY","TAXONOMY_GAP"}: errors.append(f"STATE_INVALID:{r['unit_id']}")
            if state=="TAXONOMY_GAP":
                errors.append(f"TAXONOMY_GAP:{r['unit_id']}")
            if state=="LABELED":
                if not labels: errors.append(f"LABEL_MISSING:{r['unit_id']}")
                if t["cardinality"]=="single" and len(labels)>1: errors.append(f"CARDINALITY:{r['unit_id']}")
                if t["label_source"]!="freeform":
                    allowed={x["name"] for x in t["labels"]}; bad=[x for x in labels if x not in allowed]
                    if bad: errors.append(f"UNKNOWN_LABEL:{r['unit_id']}:{','.join(bad)}")
            elif labels: errors.append(f"NONLABELED_HAS_LABELS:{r['unit_id']}")
            if r["is_long"] and state=="LABELED":
                need=len(split_long(r["text"])); got=db.execute("SELECT COUNT(*) FROM segment_results WHERE parent_unit_id=?",(r["unit_id"],)).fetchone()[0]
                if got<need:
                    # Exact duplicate reuse is valid when an identical source+context row under the same target
                    # has already had every long-text segment analyzed.
                    wrec=db.execute("SELECT target_id,content_hash FROM work WHERE unit_id=?",(r["unit_id"],)).fetchone()
                    donor_ok=False
                    if wrec:
                        donors=db.execute("""
                            SELECT w2.unit_id,w2.text FROM work w2 JOIN results r2 ON r2.unit_id=w2.unit_id
                            WHERE w2.target_id=? AND w2.content_hash=? AND w2.unit_id!=? AND r2.state='LABELED'
                        """,(wrec["target_id"],wrec["content_hash"],r["unit_id"])).fetchall()
                        for d in donors:
                            dneed=len(split_long(d["text"])); dgot=db.execute("SELECT COUNT(*) FROM segment_results WHERE parent_unit_id=?",(d["unit_id"],)).fetchone()[0]
                            if dgot>=dneed:
                                donor_ok=True; break
                    if not donor_ok:
                        errors.append(f"LONG_SEGMENT_MISSING:{r['unit_id']}")
        if not Path(meta["input"]).exists(): errors.append("SOURCE_MISSING")
        elif file_sha256(meta["input"])!=meta["input_sha256"]: errors.append("SOURCE_CHANGED")
        for t in cfg["targets"]:
            if t["label_source"]!="freeform": continue
            counts=raw_freeform_counts(jd,t["id"])
            mapped={r["raw_label"] for r in db.execute("SELECT raw_label FROM consolidation WHERE target_id=?",(t["id"],)).fetchall()}
            for raw in counts:
                if raw not in mapped: errors.append(f"UNMAPPED_FREEFORM:{t['id']}:{raw}")
        total_errors=len(errors)
    finally: db.close()
    return {"ok":not errors,"error_count":total_errors,"errors":errors[:200],"truncated_errors":total_errors>200,"status":status(jd),"quality":quality_report(jd)}


def export_job(jd: Path, out_path: str) -> dict[str, Any]:
    validation=validate_job(jd)
    if not validation["ok"]: die("VALIDATION_FAILED",f"{validation['error_count']} error(s)")
    cfg,meta=load_job(jd); out_path=str(Path(out_path).resolve())
    if Path(out_path).suffix.lower() not in {".xlsx",".xlsm"}: die("OUTPUT_FORMAT_INVALID","use .xlsx")
    if load_workbook is None or Workbook is None: die("MISSING_DEPENDENCY","openpyxl")
    db=db_connect(jd)
    try:
        map_rows=db.execute("SELECT target_id,raw_label,canonical_label FROM consolidation").fetchall()
        mappings={(r["target_id"],r["raw_label"]):r["canonical_label"] for r in map_rows}
        row_to_outputs=defaultdict(dict)
        rows=db.execute("SELECT w.source_row,w.target_id,r.labels_json,r.state FROM work w JOIN results r ON r.unit_id=w.unit_id ORDER BY w.seq").fetchall()
        tmap={t["id"]:t for t in cfg["targets"]}
        for r in rows:
            t=tmap[r["target_id"]]
            if r["state"]=="EMPTY": value=""
            elif r["state"]=="REVIEW": value="REVIEW"
            else:
                labs=json.loads(r["labels_json"])
                if t["label_source"]=="freeform": labs=dedupe_preserve([mappings[(t["id"],x)] for x in labs])
                value=LABEL_JOIN.join(labs)
            row_to_outputs[r["source_row"]][t["id"]]=value
    finally: db.close()
    input_path=meta["input"]; ext=_ext(input_path)
    if ext == ".xlsm" and Path(out_path).suffix.lower() != ".xlsm":
        die("OUTPUT_FORMAT_INVALID", "use .xlsm to preserve macros")
    if ext in {".xlsx",".xlsm"}:
        wb=load_workbook(input_path,data_only=False,keep_vba=(ext==".xlsm")); ws=wb[meta["sheet"]]
        existing=[clean_text(c.value).strip() for c in ws[1]]
        for t in cfg["targets"]:
            if t["output_column"] in existing: wb.close(); die("OUTPUT_COLUMN_CONFLICT",t["output_column"])
        start=ws.max_column+1
        for off,t in enumerate(cfg["targets"]): ws.cell(row=1,column=start+off,value=t["output_column"])
        for row_num,outputs in row_to_outputs.items():
            for off,t in enumerate(cfg["targets"]): ws.cell(row=row_num,column=start+off,value=outputs.get(t["id"],""))
        wb.save(out_path); wb.close()
    else:
        delim="\t" if ext==".tsv" else ","
        with open(input_path,"r",encoding="utf-8-sig",newline="") as f: reader=list(csv.reader(f,delimiter=delim))
        if not reader: die("EMPTY_INPUT")
        wb=Workbook(); ws=wb.active; ws.title="Labeled Data"
        ws.append(list(reader[0])+[t["output_column"] for t in cfg["targets"]])
        for source_row,row in enumerate(reader[1:],2):
            outputs=row_to_outputs.get(source_row,{})
            ws.append(list(row)+[outputs.get(t["id"],"") for t in cfg["targets"]])
        wb.save(out_path); wb.close()
    return {"output":out_path,"rows":meta["rows"],"targets":[t["output_column"] for t in cfg["targets"]]}


def main() -> None:
    p = argparse.ArgumentParser(prog="excel_labeling")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("inspect")
    s.add_argument("input")
    s.add_argument("--sheet")

    s = sub.add_parser("sample")
    s.add_argument("input")
    s.add_argument("--sheet")
    s.add_argument("--columns", nargs="+", required=True)
    s.add_argument("--context-columns", nargs="*")
    s.add_argument("--exclude-rows", nargs="*", type=int)
    s.add_argument("--count", type=int, default=5)
    s.add_argument("--seed", type=int, default=23)
    s.add_argument("--strategy", choices=["diverse","length"], default="diverse")

    s = sub.add_parser("init")
    s.add_argument("input")
    s.add_argument("--sheet")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--config", required=True)
    s.add_argument("--setup-approval-source", required=True)

    s = sub.add_parser("preview-start")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--count", type=int, default=5)
    s.add_argument("--rows", nargs="*", type=int)

    s = sub.add_parser("preview-next")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--text-budget", type=int, default=NEXT_TEXT_BUDGET)
    s.add_argument("--max-items", type=int, default=NEXT_MAX_ITEMS)

    s = sub.add_parser("preview-results")
    s.add_argument("--job-dir", required=True)

    s = sub.add_parser("approve-preview")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--approval-source", required=True)

    s = sub.add_parser("next")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--text-budget", type=int, default=NEXT_TEXT_BUDGET)
    s.add_argument("--max-items", type=int, default=NEXT_MAX_ITEMS)

    s = sub.add_parser("submit")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--stdin", action="store_true")

    s = sub.add_parser("status")
    s.add_argument("--job-dir", required=True)

    s = sub.add_parser("consolidation-next")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--limit", type=int, default=80)

    s = sub.add_parser("consolidation-submit")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--stdin", action="store_true")

    s = sub.add_parser("quality-report")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--sample-limit", type=int, default=12)

    s = sub.add_parser("validate")
    s.add_argument("--job-dir", required=True)

    s = sub.add_parser("export")
    s.add_argument("--job-dir", required=True)
    s.add_argument("--out", required=True)

    a = p.parse_args()

    if a.cmd == "inspect":
        dump(inspect_file(a.input, a.sheet))
    elif a.cmd == "sample":
        dump(sample_rows(a.input, a.sheet, a.columns, a.count, a.seed, a.strategy, a.context_columns, a.exclude_rows))
    elif a.cmd == "init":
        dump(init_job(a.input, a.sheet, a.job_dir, a.config, a.setup_approval_source))
    elif a.cmd == "preview-start":
        dump(preview_start(Path(a.job_dir), a.count, a.rows))
    elif a.cmd == "preview-next":
        if a.text_budget < 2_000:
            die("TEXT_BUDGET_TOO_SMALL")
        dump(preview_next(Path(a.job_dir), a.text_budget, a.max_items))
    elif a.cmd == "preview-results":
        dump(preview_results(Path(a.job_dir)))
    elif a.cmd == "approve-preview":
        dump(approve_preview(Path(a.job_dir), a.approval_source))
    elif a.cmd == "next":
        if a.text_budget < 2_000:
            die("TEXT_BUDGET_TOO_SMALL")
        dump(next_work(Path(a.job_dir), a.text_budget, a.max_items))
    elif a.cmd == "submit":
        dump(submit(Path(a.job_dir), read_stdin_json()))
    elif a.cmd == "status":
        dump(status(Path(a.job_dir)))
    elif a.cmd == "consolidation-next":
        dump(consolidation_next(Path(a.job_dir), a.limit))
    elif a.cmd == "consolidation-submit":
        dump(consolidation_submit(Path(a.job_dir), read_stdin_json()))
    elif a.cmd == "quality-report":
        dump(quality_report(Path(a.job_dir), a.sample_limit))
    elif a.cmd == "validate":
        result = validate_job(Path(a.job_dir))
        dump(result)
        if not result["ok"]:
            raise SystemExit(2)
    elif a.cmd == "export":
        dump(export_job(Path(a.job_dir), a.out))


if __name__ == "__main__":
    main()
