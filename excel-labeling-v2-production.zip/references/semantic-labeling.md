# Semantic Labeling Contract

## Meaning over words
Classification must follow the meaning of the complete source + approved context.

Never implement semantic labeling as ad-hoc:
- keyword matching
- substring matching
- regex rules
- phrase lookup tables

Keywords may be evidence, but they are never the decision rule by themselves.

The absence of an expected word is not evidence that a label does not apply.
The presence of a word is not sufficient evidence that a label applies.

Examples:
- “Sipariş ertesi gün elimdeydi” can mean Delivery even without the word “kargo”.
- “Kargo firması değil, ürünün kendisi kırık çıktı” should not automatically become Delivery merely because “kargo” appears.
- “Harika, sadece on gün bekledim” may express negative sentiment despite a positive-looking word.
- “Teşekkür ederim ama sorun çözülmedi” can be negative/unresolved despite polite wording.

## REVIEW vs TAXONOMY_GAP
Use `REVIEW` only when the row itself is genuinely unresolved:
- meaning is ambiguous;
- essential context is missing;
- source is unintelligible;
- two choices remain materially indistinguishable after applying definitions.

Use `TAXONOMY_GAP` when:
- the row meaning is clear;
- but no approved label covers that meaning.

A taxonomy gap is a setup problem, not a row-quality problem. Do not export it as REVIEW.

## Empty rows
If all primary source columns are empty, leave output blank. Do not mark REVIEW.

## Single label
Choose the single best-supported label according to the target purpose and definitions.

## Multi label
Return every materially supported label, but do not add weakly related labels just because a term appears.

## Context columns
Context may disambiguate source meaning but must not override an explicit source statement without reason.
