# Interaction and UX

## User experience goal
A branch/office user should feel they are answering business questions, not configuring an AI system.

Ideal mental model:
1. “What do I want to learn from these rows?”
2. “Do these labels/examples look right?”
3. “Give me the file.”

## Mandatory MCP gates
Use the real `ask_user_question` tool for required decisions. Do not substitute ordinary prose questions.

Required when not already explicit:
- ambiguous sheet;
- labeling dimension/target when user only says “label/classify this”;
- source/context columns when ambiguous (otherwise approve them in the setup card);
- Path A/B/C only when the default/explicit path needs a user choice or change;
- single vs multi for every target;
- setup approval;
- preview approval — always required;
- decision after rejected preview;
- material taxonomy/consolidation change;
- reusable prompt offer.

If the MCP tool is unavailable at a required gate, stop there rather than inventing approval.

## Ask fewer, better questions
Do not ask one question per implementation field.
When the MCP schema supports it, combine closely related choices into one clear interaction.

Good example:
“Bu veriyi hangi açılardan etiketleyelim?” with multi-select for Topic, Sentiment, Intent.

Avoid:
- taxonomy
- cardinality
- batch/chunk
- tokens
- schema
- row keys
- JSON
- confidence thresholds

## Skip redundant questions
If the user says “yorum sütununa duygu etiketi ekle, olumlu/olumsuz/nötr, tek etiket olsun”, do not ask those choices again. Still show the mandatory preview and ask for preview approval.

## Keep explanations short
Do not narrate sampling, coverage, long-text segmentation, duplicate reuse, or validation unless the user asks how it works or a problem requires explanation.


## Fast default path
If the user provides no label list and does not request free-form labeling, default to data-proposed labels (Path B) and show that choice in setup approval. This avoids asking “how should labels be sourced?” when the answer is already implied by the request.
