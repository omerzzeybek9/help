# Quality Gates

## Before user setup approval — coverage audit
For Path B, test proposed labels on a second, different varied sample.
Look for:
- recurring meanings with no label;
- labels that overlap too much;
- vague boundaries;
- labels driven by rare wording rather than useful concepts.

Do not bother the user with this internal iteration.

## Preview quality
Preview should contain informative examples, not only easy ones.
Prefer a mix of normal, boundary, multi-label-looking, long/complex, and semantically varied rows.

If the preview exposes a taxonomy problem, repair setup before full labeling.

## After full labeling — structural + semantic QA
Run `quality-report` and inspect:
- review rate;
- taxonomy-gap count;
- label distribution;
- problem samples.

Then spot-check a varied set of labeled rows, focusing on:
- rare labels;
- dominant labels;
- boundary cases;
- long rows;
- negation/irony-like phrasing;
- rows close to label boundaries.

## Blocking conditions
- Any `TAXONOMY_GAP` for a fixed-label target blocks export until resolved.
- Validation errors block export.
- Suspiciously high REVIEW requires investigation before claiming success.

There is no universal percentage threshold for REVIEW; interpret it relative to the task. A high rate may be legitimate, but it must have a clear reason.

## Repair loop
If QA reveals a material setup issue:
1. diagnose whether it is a label definition problem, missing label, or source/context issue;
2. if business meaning changes, obtain user approval through MCP;
3. re-preview the affected target;
4. rerun affected labeling work;
5. re-audit.

Do not silently rewrite approved business rules to improve metrics.
