# Label Discovery and Design

## Path A — user-provided labels
Use the user's list as the starting vocabulary.
Do not research or rename labels by default.
Flag only overlaps/ambiguities that would materially harm consistency.

## Path B — propose from the data
Do not infer a taxonomy from only 3–5 rows.

Use two different varied samples:
1. discovery sample to identify candidate concepts;
2. coverage sample to test whether important concepts remain uncovered.

A proposed label set should satisfy:
- **coverage**: important recurring meanings are represented;
- **distinctness**: labels are not near-duplicates;
- **consistency**: boundaries can be applied repeatedly;
- **usefulness**: labels answer the user's actual business goal;
- **parsimony**: do not create a label for every wording variant.

If the coverage sample reveals a meaningful missing concept, refine and audit again before showing the user.

## Internal label specification
For fixed labels, keep enough semantics to classify consistently:
- name
- short definition
- include: representative semantic situations
- exclude: nearby meanings that belong elsewhere
- examples: only where useful

These are semantic guides, not keyword lists.

## Path C — free-form + consolidation
During raw labeling, create concise semantic noun phrases without forcing a fixed vocabulary.
Afterward merge synonyms/trivial wording variants.
Do not merge materially different concepts just to reduce label count.

If a new canonical concept materially changes what the user will receive, ask for approval; trivial synonym normalization does not need another user interruption.
