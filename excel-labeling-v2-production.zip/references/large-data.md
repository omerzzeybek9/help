# Large Data and Long Text

## Large files
Never load the full dataset into conversational context.
Use bounded runtime work retrieval.
Do not ask the user to choose internal work sizes.

## Exact duplicates
Exact-identical source + context content under the same target may safely reuse an already approved semantic decision. The runtime handles this using content hashes.
Do not apply approximate/fuzzy duplicate reuse automatically.

## Long text
Never silently truncate text used for final classification.
Long work is segmented internally. Segment outputs are semantic signals, not final row labels.
Finalize only after every required segment has been processed and an aggregate work item is available.

Preview excerpts/summaries are display-only.

## Stable row identity
Map results using deterministic runtime row IDs, never by re-matching copied text.

## Performance principle
Optimize deterministic transport and duplicate reuse, not semantic shortcuts.
Do not replace LLM meaning-based classification with keyword rules to gain speed.
