---
name: excel-labeling
description: Semantically labels, classifies, categorizes, tags, or codes rows in Excel/CSV data. Use when the user asks to label a spreadsheet, classify comments/tickets/records, create labels from data, apply an existing label list, run sentiment/topic/intent or other row-level labeling, or add one or more label columns. Supports multiple labeling dimensions, user-provided/data-proposed/free-form labels, ask_user_question approvals, large files, long text, quality checks, and safe export. Do not use for simple filtering, formulas, formatting, sorting, or non-semantic spreadsheet edits.
---

# Excel Labeling

Version: 2.0

## Mission
Help non-technical employees label tabular data quickly and accurately without making them configure AI or data-processing details.

The user should experience three simple stages:
1. Decide **what the labels should mean**.
2. Check a few examples.
3. Receive the labeled file.

The agent owns semantic understanding and user interaction. The runtime owns deterministic file handling, row identity, bounded data access, exact-duplicate reuse, long-text handling, validation, quality metrics, and export.

## Critical rules
- Use the real `ask_user_question` MCP tool for every required user decision or approval gate.
- Never replace a required MCP interaction with an ordinary chat question.
- If the user only says “label this”, do **not** assume a single labeling dimension. First determine which angle(s) they want, such as topic, sentiment, intent, urgency, status, risk, or another data-appropriate dimension.
- Support multiple independent labeling targets in the same file.
- Never full-label before the preview is explicitly approved through `ask_user_question`.
- Semantic classification must be based on meaning, not keyword/substring/regex rules.
- Never hide a clearly missing category as `REVIEW`; treat it as a taxonomy gap and repair the setup before export.
- Never silently truncate text used for final classification.
- Never put an entire large dataset into conversational context at once.
- Preserve original workbook data and row order.
- External research is not part of the default labeling flow.
- Prefer quality over superficial speed, while using safe deterministic optimizations such as exact-duplicate reuse.

Read these references only when needed:
- `references/interaction.md` — MCP gates and non-technical UX
- `references/dimensions.md` — deciding what angle(s) to label
- `references/label-discovery.md` — Path A/B/C and data-driven label discovery
- `references/semantic-labeling.md` — semantic decision rules and REVIEW vs taxonomy gap
- `references/quality.md` — preview, coverage audit, final QA, repair loop
- `references/large-data.md` — large files, long text, exact duplicates
- `references/security.md` — enterprise data/research boundaries

# Workflow

## 1. Inspect the input
For Excel/CSV files, inspect before asking questions:

```bash
python scripts/excel_labeling.py inspect INPUT [--sheet SHEET]
```

Learn the sheets, row count, column names, likely roles, missingness, text lengths, and long-text risk.

Do not ask the user for facts the file already reveals.

If several sheets are plausibly relevant and the task does not identify one, select the sheet through `ask_user_question`.

For very large pasted datasets, warn the user that uploading Excel/CSV is more reliable before they paste hundreds of rows. Small pasted datasets may be handled in chat.

## 2. Determine the labeling goal(s)
A **target** is one independent meaning the user wants assigned to each row. Examples: topic, sentiment, intent, urgency, risk category, request type, root cause.

If the user already explicitly states the target(s), use them and do not ask redundantly.

If the request is ambiguous, inspect a small varied sample from the likely source column(s) and propose only data-relevant target options. Then use `ask_user_question` with multi-select when supported.

Examples of user-facing wording:
- “Bu veriyi hangi açıdan etiketlemek istersiniz?”
- “Konu/tema”
- “Duygu”
- “Müşteri niyeti”
- “Başka bir açı”

Do not present a fixed generic menu when the data suggests more useful domain-specific dimensions.

See `references/dimensions.md`.

## 3. Resolve columns for each target
For each target, identify:
- primary source column(s): the content that determines the label;
- optional context column(s): supporting context only;
- output column: where the final label will be written.

Recommend likely columns from the file. If the choice is ambiguous, resolve it through `ask_user_question`. If it is obvious, include the proposed source/context columns in the later setup-approval card so the user still gives column-level approval without an extra interruption.

Do not silently use all columns.

## 4. Resolve label source for each target
Every target uses one path:

- **Path A — User labels:** the user already has labels. Respect them.
- **Path B — Propose from data:** discover a concise label set from varied data, audit its coverage on different rows, then show it to the user.
- **Path C — Free-form:** create semantic labels during labeling, then consolidate synonyms/near-duplicates.

Choose the path with minimal friction:
- if the user supplied a label list or explicitly says they have one, use Path A;
- if the user explicitly asks for open/free-form labels, use Path C;
- otherwise use Path B by default and make that clear in the setup approval.

The setup approval must let the user change this choice. If a separate choice is needed, use `ask_user_question` with plain options equivalent to:
- “Hazır etiketlerim var”
- “Veriye göre öner”
- “Serbestçe oluştur, benzerleri sonra birleştir”

See `references/label-discovery.md`.

## 5. Resolve single-label vs multi-label
This decision must be asked for every target unless the user already stated it.

Use `ask_user_question` with plain choices:
- “Her satırda tek etiket”
- “Bir satırda birden fazla etiket olabilir”

Do not infer this purely from the data. When several targets are selected and the MCP schema supports multiple questions in one call, ask the single/multi choice for all targets together instead of interrupting the user repeatedly.

## 6. Build a high-quality target setup
For Path B, do not derive the label set from only 3–5 easy rows.

Use a varied internal discovery sample:

```bash
python scripts/excel_labeling.py sample INPUT \
  --columns SOURCE_COL1 [SOURCE_COL2 ...] \
  [--context-columns CONTEXT_COL1 ...] \
  --count 24 \
  --strategy diverse \
  --seed 23 \
  [--sheet SHEET]
```

Then use a different, preferably disjoint sample for a coverage audit. Exclude the discovery rows when practical:

```bash
python scripts/excel_labeling.py sample INPUT \
  --columns SOURCE_COL1 [SOURCE_COL2 ...] \
  [--context-columns CONTEXT_COL1 ...] \
  [--exclude-rows DISCOVERY_ROW1 DISCOVERY_ROW2 ...] \
  --count 16 \
  --strategy diverse \
  --seed 91 \
  [--sheet SHEET]
```

Internally evaluate whether important concepts are missing, labels overlap, or definitions are too vague. Refine before showing the proposal to the user.

For fixed labels, represent each label internally with:
- name;
- short definition;
- useful inclusion cues;
- useful exclusion/boundary cues;
- a few semantic examples when they materially improve consistency.

Do not show all internal detail unless the user needs it. User-facing setup should stay concise.

## 7. Obtain setup approval
Show the user a short plan per target containing only:
- what will be labeled;
- source column(s);
- output column;
- single/multi rule;
- label list with short definitions for Path A/B.

Then use `ask_user_question`.

Useful choices are equivalent to:
- “Uygun, devam et”
- “Etiketleri/kuralları değiştireceğim”
- “Bu sütun için araştır”

Research policy:
- approved target → continue without research;
- user correction → apply it without research unless research is explicitly requested;
- explicit research request → tell the user research will be performed, research only that unresolved target, and do not expose row-level customer data externally.

## 8. Initialize only after MCP setup approval
Create the internal config and initialize:

```bash
python scripts/excel_labeling.py init INPUT \
  --job-dir JOB \
  --config CONFIG.json \
  --setup-approval-source ask_user_question \
  [--sheet SHEET]
```

The config may contain multiple targets. The user must never be asked to edit JSON/config/runtime parameters.

## 9. Create a meaningful preview
Preview should test the setup, not merely show easy examples.

Prefer 5–7 rows across the job that include:
- ordinary cases;
- at least one boundary/ambiguous-looking case when available;
- a multi-label-looking case for multi-label targets;
- a long/complex case when relevant;
- varied semantic themes.

When useful, choose explicit source row numbers from discovery/coverage analysis:

```bash
python scripts/excel_labeling.py preview-start --job-dir JOB --count 5 --rows ROW1 ROW2 ROW3
```

Otherwise:

```bash
python scripts/excel_labeling.py preview-start --job-dir JOB --count 5
```

Retrieve work and submit semantic decisions:

```bash
python scripts/excel_labeling.py preview-next --job-dir JOB
python scripts/excel_labeling.py submit --job-dir JOB --stdin
python scripts/excel_labeling.py preview-results --job-dir JOB
```

If preview text is long, show only a short excerpt or 1–2 sentence display summary. The final label must still come from complete-source processing.

Then use `ask_user_question` for mandatory preview approval.

Only explicit approval may unlock full work:

```bash
python scripts/excel_labeling.py approve-preview \
  --job-dir JOB \
  --approval-source ask_user_question
```

If the user rejects the preview, revise the affected target(s) and run a new preview. Do not continue with the old setup.

## 10. Full semantic labeling
After approval:

```bash
python scripts/excel_labeling.py next --job-dir JOB
```

Classify work items using the target rules returned by the runtime.

For normal rows, return only unit ID + decision. Do not copy source text back into the output.

For long rows, process every required segment and then aggregate before deciding the final row label.

Submit decisions:

```bash
python scripts/excel_labeling.py submit --job-dir JOB --stdin
```

Decision semantics:
- `labels`: approved/final semantic labels;
- `review: true`: meaning is genuinely ambiguous or insufficient to decide;
- `taxonomy_gap: true`: meaning is clear but the approved label set does not cover it.

Do not use `review` merely because an expected keyword is absent.
Do not use `taxonomy_gap` for an ambiguous row.

See `references/semantic-labeling.md` and `references/large-data.md`.

## 11. Consolidate Path C
After free-form labeling, retrieve raw labels and map synonymous/near-equivalent wording to stable canonical labels:

```bash
python scripts/excel_labeling.py consolidation-next --job-dir JOB
python scripts/excel_labeling.py consolidation-submit --job-dir JOB --stdin
```

Do not collapse materially different meanings.

If consolidation creates materially new business categories rather than merely merging wording variants, show a concise summary and use `ask_user_question` before finalization.

## 12. Run quality audit before export
Always inspect quality metrics:

```bash
python scripts/excel_labeling.py quality-report --job-dir JOB
```

Then run semantic QA on a small varied spot-check of completed rows, especially:
- boundary cases;
- review rows;
- rare labels;
- dominant labels;
- long rows;
- negation/irony-like language when present.

A high `REVIEW` rate is a signal to investigate, not a successful completion statistic.
Any `TAXONOMY_GAP` is blocking for fixed-label targets: repair the taxonomy/setup, obtain any necessary user approval, and re-preview affected changes before export.

Do not silently change approved business meaning merely to make metrics look better.

See `references/quality.md`.

## 13. Validate and export
Validate:

```bash
python scripts/excel_labeling.py validate --job-dir JOB
```

Validation must reject missing work, illegal labels, single/multi violations, incomplete long-text processing, changed source files, missing MCP approval provenance, unmapped free-form labels, and unresolved taxonomy gaps.

Export only after validation passes:

```bash
python scripts/excel_labeling.py export --job-dir JOB --out OUTPUT.xlsx
```

Default export behavior:
- preserve original rows, columns, order, values, and other workbook sheets;
- append one output column per target;
- join multi-label values with `; `;
- leave truly empty source rows blank;
- use `REVIEW` only for genuinely unresolved rows;
- never expose internal row IDs, hashes, segments, debug columns, or runtime state.

## 14. Finish simply
Tell the user, briefly:
- which dimensions were labeled;
- number of rows completed;
- number requiring review, only if non-zero;
- where the output file is.

Then use `ask_user_question` to offer a reusable prompt for the approved labeling setup.

The reusable prompt should contain business rules only: source columns, target meanings, labels/definitions, single/multi rules, important boundaries, expected output columns, and preview approval. Do not include runtime mechanics.
