# Commands and response formats

Normal execution uses `agent_io.py`. This adapter makes no semantic decisions: it records the model's decisions and returns the next action. There is no need to drop to the low-level next/submit/audit commands.

All commands run from the skill directory, so `scripts/...` resolves. If the working directory is elsewhere, use the skill's absolute path for both the script and `INPUT`.

## Start in one call

Format example only — fill every value from the user's actual approved choices. Each target carries its own `source_columns` and a one-sentence `purpose` (required; the runtime rejects a blank one). `label_source`: user/proposed/freeform. `cardinality`: single/multi. For the freeform path `labels` may be empty.

`discovery_strategy` may be omitted; the runtime derives it from `target_type` and `label_source` (sentiment → `fixed`, topic/intent → `taxonomy_discovery`, freeform root cause → `open_code_then_group`, any user-supplied vocabulary → `fixed`). Set it explicitly only to override that default.

```bash
python scripts/agent_io.py start INPUT --stdin --approval-source ask_user_question <<'JSON'
{"targets":[
 {"name":"Konu","target_type":"topic","purpose":"Kaydın ana konusunu belirle","source_columns":["yorum"],"context_columns":["kanal"],"output_column":"Konu","label_source":"proposed","cardinality":"single","labels":[{"name":"Teslimat","definition":"Teslimat deneyimi"}]},
 {"name":"Duygu","target_type":"sentiment","purpose":"Kaydın genel değerlendirme yönünü belirle","source_columns":["yorum"],"output_column":"Duygu","label_source":"proposed","cardinality":"single","labels":[{"name":"Olumlu","definition":"Maddi olumlu değerlendirme"},{"name":"Olumsuz","definition":"Şikâyet veya olumsuz sonuç"},{"name":"Nötr","definition":"Belirgin değerlendirme yok"},{"name":"Karışık","definition":"Maddi olumlu ve olumsuz değerlendirme birlikte"}]}
]}
JSON
```

A proposed sentiment target must keep the four-way positive/negative/neutral/mixed distinction; the runtime rejects a shorter proposed scale. A scale the user supplied themselves is authoritative — send it with `label_source: "user"`.

Get the label/column proposal approved through the real ask_user_question first; this command is not an approval tool. Do not write a separate config file. `start` validates the setup, creates the private work area and returns the first preview tasks. The returned `job_dir` is the JOB value for every later command. Do not call `start` again afterwards; continue from the work/answer path. If a setup is rejected at start, correct the stdin payload from the user's existing choices and rerun the same command.

If the user selected a different sheet, header row or scope, pass `--sheet`, `--header-row` or `--row-scope` on `start`. After an interruption in an existing job, use `work --refresh` with the returned job_dir; do not restart completed work.

## Label answers

Fill the **entire** `answer_format` from the `work` response; `request_id` and every `ref` are preserved verbatim:

```
python scripts/agent_io.py answer --job-dir JOB --stdin --next <<'JSON'
{"request_id":"RETURNED_ID","answers":[{"ref":"1","labels":["Etiket"]}]}
JSON
```

Do not copy the record count from this example; answer every record in the real template. `--next` saves the submission and returns the next work in the same response, so do not insert a separate `work` call between them.

- Ordinary row: read the source in `row_fields` and answer each target under its own `source_refs`/`context_refs` and rules.
- Long segment: read `text` completely. `text_ref` points at the identical text of another ref in the same response. Each target decides separately. Write a short `note` preserving the relevant facts, negation and outcome; limit 1200 characters. When every segment is done, decide the final label from all signals in the aggregate task.
- Audit/repair: `items` are flat tasks; use the evidence in `fields`/`text`/`segment_signals`. Production decisions are hidden during audit; do not reproduce your earlier answers.
- Consolidation: the template carries `canonical_label` instead of `labels`.
- Genuine ambiguity: empty `labels`, `review=true` and a `review_reason`. If the meaning is clear but no approved label covers it, `taxonomy_gap=true` and `gap_reason`. Never combine the two.

## Preview table

`action=approve_preview` → `python scripts/agent_io.py preview --job-dir JOB`.

If summaries are requested, fill the **entire** returned `summary_format`:

```
python scripts/agent_io.py preview --job-dir JOB --stdin <<'JSON'
{"summaries":[{"source_row":2,"summary":"Kısa, kaynağa sadık özet."}]}
JSON
```

`source_row` is the real spreadsheet row. Summaries carry no request_id/answers/ref, and are never sent to `answer`. Show the returned markdown verbatim in the message and call the real MCP tool named in `required_tool` with its `question` text (use the tool's actual schema); do not add a question to the normal message. Once the answer arrives, pass that table's `preview_id` to the `approve` command.

## Next action

| action | Do |
| --- | --- |
| answer | Decide from the complete source; submit the template |
| start_preview | `excel_labeling.py preview-start --job-dir JOB --count 5` |
| approve_preview | The table above, then real approval |
| diagnose_audit | Inspect a few mismatches with the returned diagnostic command; [quality.md](quality.md) |
| resolve_input / resolve_taxonomy / investigate_reviews | Resolve the named concrete gap; not an output approval |
| finish | `agent_io.py finish --job-dir JOB --out OUTPUT.xlsx`, then deliver the two files |

Correct the current submission on a missing field or wrong format. After an uncertain tool result, `work --refresh` returns the saved job and its rules. Use a single writer per job; never start a new job and discard accepted decisions.

Every work response carries `progress`: real filled/blank counts, completed/remaining labeling rows and the current task count. `stage_percent` belongs to the current stage; completing a segment is not yet completing a row. No remaining rows to label does not mean the audit is finished — continue from the returned `action`. Do not repeat this internal feedback in chat or re-plan after every call. File size is not a reason to change method.

`plan_update` arrives only on stage changes; update the same plan when a real plan tool exists. `EXPORTED` means the file is ready; mark delivery complete only once the real file sharing has happened. Never share internal JSON files. The `deliverables` list in the finish result contains exactly two real full paths — pass those to the publishing tool verbatim. The delivery folder must be outside the private job folder.
