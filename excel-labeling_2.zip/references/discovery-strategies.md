# Target-Aware Discovery Strategies

## Purpose
Choose the semantic workflow from the **target's business question**, not from one universal labeling recipe.

## Strategy table

| Target type | Default strategy | Why |
|---|---|---|
| Sentiment | fixed | Stable small vocabulary; discovery usually adds noise |
| Topic / Category | taxonomy_discovery | Needs coverage across recurring themes |
| Root Cause / Reason | open_code_then_group | Understand the specific cause before compressing into groups |
| Intent | taxonomy_discovery or fixed | Depends on whether a business taxonomy already exists |
| Priority / Risk / Status | fixed | Usually business-defined semantics |
| Custom | taxonomy_discovery | Choose from the approved business purpose |

The runtime applies this table itself when `discovery_strategy` is omitted, so no target reaches semantic work as `auto`. A user-supplied vocabulary (`label_source: user`) always resolves to `fixed`. Set the field explicitly only to override the derived default.

## `fixed`
Use when the user supplied labels or the target has a well-defined business vocabulary.
Do not invent extra labels. A clear uncovered meaning is `TAXONOMY_GAP`.

## `taxonomy_discovery`
1. Take a diverse discovery sample.
2. Identify recurring semantic concepts.
3. Create a parsimonious candidate taxonomy.
4. Test a fresh coverage sample.
5. Refine material recurring gaps.
6. Show the user the final proposal once.

Do not build the taxonomy from 3–5 convenient rows.

## `open_code_then_group`
Use mainly for root cause/reason analysis when actionable detail matters.
1. First label each row with a concise fine-grained cause, without forcing a category list.
2. Consolidate/group those fine labels semantically.
3. Preserve the detail label and grouped label when useful.
4. Test coverage and split over-broad/catch-all groups.

This prevents premature categories from flattening the real cause.

## `freeform`
Use when the user explicitly wants open semantic codes without a fixed grouped vocabulary. Consolidate trivial wording variants afterward.

## Strategy selection rules
- User-provided taxonomy wins unless they ask to redesign it.
- Do not force root-cause open coding onto Sentiment.
- Do not use open coding when a regulated/business enum must remain exact.
- Never use fuzzy string matching to force model output into a semantically different label.
- Never force an uncovered meaning into the "nearest" category; use `TAXONOMY_GAP` or an approved catch-all.
