# Conversation flow, plan and delivery

## First question screen

Ask only what is genuinely missing through the real ask_user_question MCP. Normally that is one question: which dimensions to label. Add a second only when it is real missing information — for example a ready label list the user mentioned but has not shared.

Do not ask the user to set label source or single/multi as a blanket preference across every dimension. Those belong to the per-target structure you propose in the setup approval, because the right answer differs by target: a row can carry several topics but only one sentiment, and a user-supplied vocabulary is fixed while a discovered one is not. A preference the user states explicitly ("use my own list", "label freely", "more than one per row") is authoritative — keep it and never re-ask it.

Never re-ask an answered preference, and never treat a general label approval as the answer to a question that was never asked.

If the MCP call limit truncates the set, complete the remaining first questions in the immediately following call; do not move on to label proposals or file preparation in between. Do not present question text in a normal message and act as though approval was obtained without the real MCP. Do not ask for technical tools, endpoints, API keys or config files.

## What the approvals mean

The user sees exactly two approvals:

1. Short label definitions, the source/output columns to be used, and the per-target single/multi choice, shown together in one table. Answering *"Bu yapıyla örnekleri hazırlayayım mı?"* approves that structure. There is no separate technical setup approval.
2. A genuinely rendered, completed sample table. Approving those samples authorizes processing the whole file.

If the label/column structure was already explicitly approved, do not ask again. If an internal file's format is wrong, fix it from the existing answers; do not ask the user to re-decide. If the structure changes, clarify only what changed. Asking for a label list the user has not yet shared is a missing-information question, not technical setup.

## Samples and delivery

One table: real spreadsheet row, a 1–2 sentence summary, and the labels for each chosen dimension. The summary preserves negation and mixed outcomes; the label decision rests on the complete original text. Actually render the table in the message, then request the real MCP approval in the same turn. Do not narrate the rows before the table, and do not stop with only "awaiting approval".

After sample approval, continue the existing job. Update the plan only when stages change; do not wait for a progress bar or extra interface. At the end, deliver the Excel and the automatically generated reuse prompt through the real file tool; never deliver internal JSON or the job folder.

## Task plan

Show these steps once at the start:

1. Dosyayı ve etiket tercihlerini netleştir
2. Örnekleri göster ve onay al
3. Tüm satırları etiketle
4. Sonuçları kontrol et
5. Excel ve tekrar kullanım metnini sun

If a real native plan/task tool is exposed, use its actual schema and update that same plan. Otherwise use a short checklist. No progress bar, HTML asset or renderer installation is required; do not invent a tool. Questions and approvals still use the real ask_user_question MCP.

`JOB/plan.json` records the current steps, and work responses include `plan_update` only on stage changes. Complete stage 1 after real setup approval, stage 2 after real preview approval, stage 3 after labeling and any required consolidation, and stage 4 after the quality gate passes. Stage 5 stays in progress until both files are actually attached; an export receipt alone does not prove attachment.

Without a plan tool, show each newly completed stage once, for example "✓ Örnekler onaylandı", and continue with the next tool immediately in the same turn. Do not repeat the full checklist on every update, and do not add one message per row. If a correction or repair reopens a stage, reflect the current state rather than claiming the finished work still holds. A plan update is not a final response.

## Uninterrupted authorized work

Never simulate a background worker or promise progress after ending a turn. Continue authorized work through export and actual attachment. Only a genuine user decision, a user stop request, or a concrete unrecoverable tool/input problem justifies stopping. Required approvals and the audit/export guards remain in force throughout.

Existing job files stay valid across a resumed session: do not re-init an existing job or discard labels in order to "upgrade" it. New jobs use `agent_io start`, whose private config and state live in a system temporary directory. Do not choose a job folder inside the host's attachment/delivery directory, and publish only the two paths in `finish.deliverables`.

The skill cannot change the host model's real limits or guarantee that a host keeps executing indefinitely. Native plan rendering, real MCP answers and file attachment behaviour must be verified in the actual host interface; local fixture tests do not exercise it.

## Research and ready dimensions

Ask the user or propose from the data first. For a genuinely unresolved abstract business concept, give a short heads-up before researching; never carry customer text into external research.

Meanwhile continue preparing samples for the other dimensions. If one dimension must wait for a full decision, get the ready dimensions' label/column structure and samples approved and produce one verified intermediate output. Then process the remaining dimensions from that file in a new job, preserving the existing columns and rows and taking that job's own sample approval. Never present the intermediate file to the user as the final result; deliver once every requested dimension is complete. Do not modify the active job's source file.
