> Normal workflow uses agent_io.py and agent-protocol.md. Before approval render the complete current table with adapter preview; use its exact preview_id. Low-level commands below are retained for engineering diagnostics.

# Backend Runtime Contract

For normal semantic execution use `agent_io.py` as defined in `agent-protocol.md`; this reference documents the underlying commands.

## Contents
- Phase order
- Configuration schema
- Setup and preview
- Payload keys and row numbering
- Production loop
- Free-form consolidation
- Audit and repair
- Validation/export
- Provenance rules

## Phase order
State progression:
`SETUP_APPROVED → PREVIEWING → PREVIEW_APPROVED → LABELING → [CONSOLIDATING] → AUDITING → AUDIT_PASSED → VALIDATED → EXPORTED`

Failed audit enters `AUDIT_FAILED` / `REPAIRING`, then returns to labeling and requires a fresh audit.

Use:
```bash
python scripts/excel_labeling.py contract
```
when exact syntax is uncertain. Do not ask the user to debug runtime syntax.

## Configuration schema
For new jobs, `agent_io.py start INPUT --stdin --approval-source ask_user_question` receives the approved targets structure and creates the private config/job itself. Direct init is a backend diagnostic, not a second user workflow.

A job config contains `targets`; each target requires source_columns, output_column, label_source, cardinality and a non-empty one-sentence `purpose`, plus labels for a fixed taxonomy.

Validation rejects, with an actionable error, any target that: omits `purpose`; is a `proposed` sentiment target with fewer than four labels (the positive/negative/neutral/mixed distinction); pairs `open_code_then_group` with a non-freeform label source; or pairs `fixed` with a freeform one. A blank or omitted `discovery_strategy` is not an error — it is derived from `target_type` and `label_source` and never stays `auto`. There is no separate user-response file or preference-check command. The user approval of the displayed labels/column mapping is the setup approval used by init; never ask a second technical setup approval. Internal file-format fixes do not invalidate unchanged user choices.

Fixed/topic example:
```json
{
  "targets": [{
    "name": "Konu",
    "target_type": "topic",
    "purpose": "Kaydın ana konusunu belirle",
    "source_columns": ["yorum"],
    "context_columns": ["kanal"],
    "output_column": "Konu",
    "label_source": "proposed",
    "discovery_strategy": "taxonomy_discovery",
    "cardinality": "multi",
    "labels": [
      {"name":"Kart İşlemleri","definition":"Kart kullanım ve işlem sorunları","include":[],"exclude":[],"examples":[]}
    ]
  }]
}
```

Hierarchical root-cause example:
```json
{
  "targets": [{
    "name": "Kök Neden",
    "target_type": "root_cause",
    "purpose": "Belirtilen sonucun temel sebebini çıkar",
    "source_columns": ["aciklama"],
    "context_columns": [],
    "raw_output_column": "Sebep Detay",
    "output_column": "Sebep Grup",
    "label_source": "freeform",
    "discovery_strategy": "open_code_then_group",
    "cardinality": "single",
    "taxonomy_quality": {
      "enabled": true,
      "catch_all_label": "Diğer",
      "max_catch_all_pct": 10,
      "max_group_pct": 45,
      "thin_group_pct": 1
    }
  }]
}
```

`raw_output_column` is valid only for `freeform` targets with `cardinality: single`. It stores the raw/fine label; `output_column` stores the canonical consolidated label. Multiple labels are supported without a separate raw output column. Resolve an incompatible requested combination before setup approval.

Supported `target_type`: `topic`, `sentiment`, `root_cause`, `intent`, `priority`, `risk`, `status`, `custom`.

Supported `discovery_strategy`: `auto`, `fixed`, `taxonomy_discovery`, `open_code_then_group`, `freeform`.


### Optional row filters
Use deterministic row filters when the user explicitly scopes labeling to a subset. Supported operators:
- `equals` / `not_equals`
- `in` / `not_in`
- `empty` / `nonempty`

Example:
```json
"row_filters": [
  {"column":"durum","operator":"equals","value":"Şikayet"}
]
```

Filters are case-insensitive by default; set `case_sensitive:true` only when needed. Multiple filters are ANDed. Rows outside the subset do not enter semantic work and remain unchanged in export.

## Corrections and diagnostics
Normal preview, production, consolidation, audit finalization and export use the adapter in [agent-protocol.md](agent-protocol.md). Do not mix a second backend execution loop into it.

Persist a correction within the existing label list:
```bash
python scripts/excel_labeling.py preview-results --job-dir JOB
python scripts/excel_labeling.py preview-correct --job-dir JOB --approval-source ask_user_question --stdin
```
The first command supplies real unit IDs for the correction; its excerpts are not the user-facing preview. Return to adapter preview to regenerate the table and obtain its approval.

For audit failure only:
```bash
python scripts/excel_labeling.py audit-results --job-dir JOB --mismatch-limit 5
python scripts/excel_labeling.py repair-start --job-dir JOB --mode progressive
python scripts/agent_io.py work --job-dir JOB
```
Inspect disagreements first. If business meaning changed, obtain that decision and a fresh preview. Otherwise repair the affected scope and let the adapter run a fresh audit. A second failed repair is a concrete blocker, not authorization to bypass validation.

`source_row` is the actual spreadsheet row, including the header offset. Do not derive it from a list index. The adapter carries leases/hashes; preserve request_id and every ref in answer_format.

Use `--help` for an unfamiliar diagnostic argument. Output conflicts use `--on-conflict error|overwrite|suffix`; choose a new output name unless the user authorized overwrite. An advanced workbook override still requires explicit approval.

## Preview correction payload
`preview-correct --job-dir JOB --approval-source ask_user_question --stdin` accepts `{"corrections":[{"unit_id":"<from preview-results>","labels":["<approved label>"],"reason":"<user correction>"}]}`. Show corrected preview and obtain approval again.
