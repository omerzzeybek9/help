# Komut ve yanıt biçimleri

Normal akışta `agent_io.py` kullan. Bu araç karar vermez; modelin verdiği kararları kaydeder ve sonraki eylemi döndürür. Alt seviye next/submit/audit komutlarına geçmek gerekmez.

## Tek çağrıyla başlangıç
Bu yalnız biçim örneğidir; bütün değerleri mevcut kullanıcı tercihleriyle doldur. Her boyutta source_columns bulunur. `label_source`: user/proposed/freeform; `cardinality`: single/multi. Serbest yolda labels boş olabilir.
```bash
python scripts/agent_io.py start INPUT --stdin --approval-source ask_user_question <<'JSON'
{"targets":[
 {"name":"Konu","target_type":"topic","source_columns":["yorum"],"context_columns":["kanal"],"output_column":"Konu","label_source":"proposed","cardinality":"single","labels":[{"name":"Teslimat","definition":"Teslimat deneyimi"}]},
 {"name":"Duygu","target_type":"sentiment","source_columns":["yorum"],"output_column":"Duygu","label_source":"proposed","cardinality":"single","labels":[{"name":"Olumlu","definition":"Maddi olumlu değerlendirme"},{"name":"Olumsuz","definition":"Şikâyet veya olumsuz sonuç"},{"name":"Nötr","definition":"Belirgin değerlendirme yok"},{"name":"Karışık","definition":"Maddi olumlu ve olumsuz değerlendirme birlikte"}]}
]}
JSON
```
Önce etiket/sütun önerisini gerçek ask_user_question ile onaylat; bu komut onay aracı değildir. Ayrı bir config dosyası yazma. start ayarı doğrular, geçici çalışma alanını oluşturur ve ilk örnek görevlerini döndürür. Dönen job_dir sonraki komutların JOB değeridir. Bundan sonra start'ı yeniden çağırma; mevcut work/answer yolundan devam et. Hatalı ayar başlangıçta reddedilirse stdin girdisini mevcut kullanıcı tercihleriyle düzeltip aynı komutu yeniden çalıştır.

Başka sayfa/başlık/kapsam kullanıcı tarafından seçildiyse start üzerinde --sheet, --header-row veya --row-scope kullan. Mevcut işte kesinti olduğunda dönen job_dir ile work --refresh kullan; tamamlanmış işi yeniden başlatma.

## Etiket cevapları
`work` yanıtındaki **answer_format'ın tamamını** doldur; request_id ve her ref aynen korunur:
```
python scripts/agent_io.py answer --job-dir JOB --stdin --next <<'JSON'
{"request_id":"RETURNED_ID","answers":[{"ref":"1","labels":["Etiket"]}]}
JSON
```
Bu örnekteki kayıt sayısını kopyalama; gerçek şablondaki tüm kayıtları yanıtla. `--next` gönderimi kaydedip sonraki işi aynı cevapta döndürür; araya yeni work çağrısı koyma.

- Normal satır: row_fields içindeki kaynağı oku, her target'ı kendi source_refs/context_refs ve kurallarıyla yanıtla.
- Uzun parça: text'i tamamen oku. text_ref aynı yanıt içindeki başka ref'in aynı metnidir. Her boyutun kararı ayrıdır. note alanına kısa, ilgili olguları koruyan not yaz; üst sınır 1200 karakter. Sonuç/olumsuzluğu kaybetme. Bütün parçalar bitince aggregate görevindeki tüm sinyallerden nihai kararı ver.
- Kontrol/onarım: items düz görevlerdir; fields/text/segment_signals içindeki kanıtı kullan. Kontrolde üretim kararları gizlidir; önceki yanıtlarını kopyalama.
- Birleştirme: şablon labels yerine canonical_label içerir.
- Gerçek belirsizlik: labels boş, review=true ve review_reason. Anlam açık ama liste kapsamıyorsa taxonomy_gap=true ve gap_reason. İkisini birleştirme.

## Örnek tablosu
`action=approve_preview` → `python scripts/agent_io.py preview --job-dir JOB`.
Özet istenirse dönen **summary_format'ın tamamını** doldur:
```
python scripts/agent_io.py preview --job-dir JOB --stdin <<'JSON'
{"summaries":[{"source_row":2,"summary":"Kısa, kaynağa sadık özet."}]}
JSON
```
source_row gerçek Excel satırıdır. Özetlerde request_id/answers/ref yoktur. Özetleri answer'a gönderme. Dönen markdown'ı mesajda aynen göster, required_tool alanındaki gerçek MCP aracını question metniyle çağır (aracın gerçek şemasını kullan); normal mesajda soru ekleme. Cevap geldikten sonra approve komutuna bu tablonun preview_id değerini gönder.

## Sonraki eylem
| action | Uygula |
| --- | --- |
| answer | Tam kaynaktan karar ver; şablonu gönder |
| start_preview | `excel_labeling.py preview-start --job-dir JOB --count 5` |
| approve_preview | Yukarıdaki tablo ve gerçek onay |
| diagnose_audit | Dönen tanı komutuyla birkaç uyuşmazlığı incele; [quality.md](quality.md) |
| resolve_input / resolve_taxonomy / investigate_reviews | Belirtilen somut eksikliği çöz; çıktı onayı sayma |
| finish | `agent_io.py finish --job-dir JOB --out OUTPUT.xlsx`, ardından iki dosyayı sun |

Eksik alan/yanlış biçimde mevcut gönderimi düzelt. Belirsiz araç sonucunda `work --refresh` kayıtlı işi ve kuralları geri getirir. Aynı işe tek yazıcı kullan; yeni iş açarak kabul edilmiş kararları silme. İş bitmediği sürece başarılı gönderimden sonra devam et.

Her iş yanıtındaki progress gerçek dolu/boş, etiketlemede tamamlanan/kalan satırları ve o anki görev sayısını gösterir. stage_percent mevcut aşamaya aittir; parça tamamlamak henüz tam satır tamamlamak değildir. Etiketlenecek satır kalmaması denetimin bittiği anlamına gelmez; dönen action'dan devam et. Bu iç geri bildirimi sohbette tekrarlama veya her çağrıdan sonra yeniden plan yapma. Yalnız dönen görevleri değerlendirip gönder; dosyanın büyüklüğü yöntem değişikliği gerekçesi değildir.

plan_update yalnız aşama değişince gelir; varsa gerçek plan aracını güncelle. EXPORTED dosyanın hazır olduğunu söyler; gerçek dosya paylaşımı tamamlanınca teslim adımını işaretle. İç JSON dosyalarını paylaşma. finish sonucundaki deliverables yalnız iki gerçek tam dosya yolu içerir; yayınlama aracına bu yolları aynen ver. Teslim klasörü özel iş klasörünün dışında olmalıdır.
