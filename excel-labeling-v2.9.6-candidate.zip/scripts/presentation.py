"""Deterministic display and reuse artifacts; never chooses semantic labels or summaries."""
import hashlib,json,os
from pathlib import Path
import excel_labeling as rt

def write_json(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8');os.replace(tmp,path)

def ui_state(jd):
    cfg,meta=rt.load_job(jd);db=rt.db_connect(jd)
    try:
        rows=db.execute('SELECT w.unit_id,w.source_row,w.is_long,w.text,r.state FROM work w LEFT JOIN results r ON r.unit_id=w.unit_id').fetchall()
        eligible={r['source_row'] for r in rows if r['state']!='EMPTY'}
        pending={r['source_row'] for r in rows if r['state'] is None}
        segments={r[0]:r[1] for r in db.execute('SELECT parent_unit_id,COUNT(*) FROM segment_results GROUP BY parent_unit_id')}
        total=done=0
        for r in rows:
            if r['state']=='EMPTY':continue
            weight=len(rt.split_long(r['text']))+1 if r['is_long'] else 1
            total+=weight;done+=weight if r['state'] is not None else min(weight-1,segments.get(r['unit_id'],0))
        audit_rows=db.execute('SELECT w.unit_id,w.is_long,w.text,a.audited_labels_json FROM audit a JOIN work w ON w.unit_id=a.unit_id').fetchall()
        audit_segments={r[0]:r[1] for r in db.execute('SELECT parent_unit_id,COUNT(*) FROM audit_segment_results GROUP BY parent_unit_id')}
        audit_total=audit_done=0
        for r in audit_rows:
            weight=len(rt.split_long(r['text']))+1 if r['is_long'] else 1
            audit_total+=weight
            audit_done+=weight if r['audited_labels_json'] is not None else min(weight-1,audit_segments.get(r['unit_id'],0))
    finally:db.close()
    state=meta['state'];stage='Etiketleniyor';percent=int(100*done/max(1,total))
    if state in rt.PREVIEW_STATES:stage='Örnekler hazırlanıyor';percent=None
    elif state=='CONSOLIDATING':stage='Benzer etiketler birleştiriliyor';percent=None
    elif state=='AUDITING':stage='Kontrol ediliyor';percent=int(100*audit_done/max(1,audit_total))
    elif state in {'AUDIT_FAILED','REPAIRING'}:stage='Sonuçlar gözden geçiriliyor';percent=None
    elif state in {'AUDIT_PASSED','VALIDATED'}:stage='Dosya hazırlanıyor';percent=None
    elif state=='EXPORTED':stage='Dosya hazır';percent=100
    value={'key':hashlib.sha256(str(jd.resolve()).encode()).hexdigest()[:16],'stage':stage,'percent':percent,'completed_rows':len(eligible-pending),'total_rows':len(eligible),'blank_rows':meta['rows']-len(eligible),'output_ready':state=='EXPORTED'}
    path=jd/'progress.json';previous=rt.load_json(path) if path.exists() else {}
    value['revision']=previous.get('revision',0)+(int({k:v for k,v in previous.items() if k!='revision'}!=value))
    write_json(path,value);return value

def preview_signature(jd):
    db=rt.db_connect(jd)
    try:
        rows=[list(r) for r in db.execute('SELECT p.unit_id,w.content_hash,r.labels_json,r.state FROM preview p JOIN work w ON w.unit_id=p.unit_id LEFT JOIN results r ON r.unit_id=p.unit_id ORDER BY p.rank')]
    finally:db.close()
    cfg,_=rt.load_job(jd)
    return hashlib.sha256(json.dumps([cfg,rows],ensure_ascii=False,sort_keys=True).encode()).hexdigest()

def cell(s):return str(s).replace('\\','\\\\').replace('|','\\|').replace('\r',' ').replace('\n',' ')

PLAN_STEPS = [
    'Dosyayı ve etiket tercihlerini netleştir',
    'Örnekleri göster ve onay al',
    'Tüm satırları etiketle',
    'Sonuçları kontrol et',
    'Excel ve tekrar kullanım metnini sun',
]


def task_plan(jd):
    """Real phase milestones; export readiness never proves host attachment."""
    _, meta = rt.load_job(jd)
    status = rt.status(jd)
    state = meta['state']
    preview_approved = meta.get('preview_approval_source') == 'ask_user_question'
    labeled = bool(preview_approved and status['labeling_complete']
                   and status['ready_for_audit'] and state != 'REPAIRING')
    checked = state in {'AUDIT_PASSED', 'VALIDATED', 'EXPORTED'}
    done = [meta.get('setup_approval_source') == 'ask_user_question',
            preview_approved, labeled, checked, False]
    active = next((i for i, complete in enumerate(done) if not complete), 4)
    return {'steps': [{'step': label, 'status': 'completed' if done[i] else
                      ('in_progress' if i == active else 'pending')}
                     for i, label in enumerate(PLAN_STEPS)],
            'delivery_ready': state == 'EXPORTED'}


def plan_update(jd):
    """Emit only changed stages, not a status message for every work request."""
    value = task_plan(jd)
    p = jd/'plan.json'
    previous = rt.load_json(p) if p.exists() else {}
    if {k: v for k, v in previous.items() if k != 'revision'} == value:
        return None
    value['revision'] = previous.get('revision', 0) + 1
    write_json(p, value)
    return value

def preview_approval(markdown,signature,preview_id):
    return {'action':'approve_preview','markdown':markdown,'signature':signature,'preview_id':preview_id,
            'required_tool':'ask_user_question',
            'question':'Bu örneklerle tüm dosyayı etiketleyeyim mi?',
            'instruction':'Show only markdown, then call the real ask_user_question MCP with question using its actual schema. Do not append a plain-text question. This object is guidance, not a tool call or approval. Run approve only after the actual user answer.'}


def preview(jd,payload=None):
    raw=rt.preview_results(jd)
    if not raw['complete']:rt.die('PREVIEW_INCOMPLETE','Continue work; do not ask for approval yet.')
    cfg,meta=rt.load_job(jd);by_row={}
    for item in raw['preview_results']:
        row=by_row.setdefault(item['source_row'],{'source_row':item['source_row'],'labels':{},'units':[]})
        row['labels'][item['target']]=item['labels'] or [item['state']];row['units'].append(item['unit_id'])
    sig=preview_signature(jd);p=jd/'preview_display.json'
    if payload is None and p.exists():
        old=rt.load_json(p)
        if old['signature']==sig:return preview_approval(old['markdown'],sig,old['preview_id'])
    if payload is None:
        db=rt.db_connect(jd)
        try:
            for row in by_row.values():
                notes=[];excerpts=[]
                for uid in row['units']:
                    w=db.execute('SELECT fields_json,is_long FROM work WHERE unit_id=?',(uid,)).fetchone()
                    if w['is_long']:
                        notes.extend(r[0] for r in db.execute('SELECT note FROM segment_results WHERE parent_unit_id=? ORDER BY unit_id',(uid,)) if r[0])
                    else:excerpts.extend(f['text'] for f in json.loads(w['fields_json']) if f['role']=='source')
                row['display_evidence']=list(dict.fromkeys(notes+excerpts))
                del row['units']
        finally:db.close()
        return {'action':'write_preview_summaries','rows':list(by_row.values()),
                'summary_format':{'summaries':[{'source_row':n,'summary':'<1–2 sentence summary>'} for n in by_row]},
                'submit_command':'agent_io.py preview --job-dir JOB --stdin',
                'instruction':'Fill summary_format; send with preview --stdin, NOT answer. Write 1–2 faithful sentences, max420 characters. Preserve the complaint, outcome and material positive/negative facts. Do not turn courtesy thanks into praise, no other complaints into satisfaction, or a numeric rating into resolution. Summary is display-only; never relabel from it. Show only the returned markdown table, then open the real MCP preview question.'}
    summaries=payload.get('summaries',[]) if isinstance(payload,dict) else []
    if not isinstance(summaries,list) or any(not isinstance(x,dict) for x in summaries):rt.die('PREVIEW_SUMMARIES_INVALID')
    supplied={x.get('source_row'):x.get('summary') for x in summaries}
    if len(supplied)!=len(summaries) or set(supplied)!=set(by_row):rt.die('PREVIEW_SUMMARIES_MUST_COVER_ROWS','Copy summary_format from preview and fill every summary. Send with preview --stdin; do not use answer or request new labeling work.')
    if any(not isinstance(s,str) or not s.strip() or len(s)>420 for s in supplied.values()):rt.die('PREVIEW_SUMMARY_LENGTH_INVALID')
    names=[t['name'] for t in cfg['targets']]
    lines=['| Satır | Kısa özet | '+' | '.join(cell(x) for x in names)+' |','| --- | --- | '+' | '.join('---' for _ in names)+' |']
    for n,row in by_row.items():lines.append('| '+str(n)+' | '+cell(supplied[n])+' | '+' | '.join(cell('; '.join(row['labels'].get(name,['—']))) for name in names)+' |')
    markdown='\n'.join(lines)
    preview_id=hashlib.sha256(json.dumps([sig,summaries,markdown],ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:24]
    write_json(p,{'signature':sig,'summaries':summaries,'markdown':markdown,'preview_id':preview_id})
    return preview_approval(markdown,sig,preview_id)

def approve(jd,approval_source,preview_id):
    p=jd/'preview_display.json'
    if not p.exists() or rt.load_json(p)['signature']!=preview_signature(jd):rt.die('CURRENT_PREVIEW_DISPLAY_REQUIRED')
    if rt.load_json(p).get('preview_id')!=preview_id:rt.die('PREVIEW_APPROVAL_STALE')
    if not rt.preview_results(jd)['complete']:rt.die('PREVIEW_INCOMPLETE')
    return rt.approve_preview(jd,approval_source)

def reusable(jd,out):
    cfg,meta=rt.load_job(jd)
    lines=['Yeni yüklediğim Excel/CSV dosyasını aşağıdaki kurallarla etiketle.','Aşağıda belirtilen boyut, etiket kaynağı ve tek/çoklu tercihlerini tekrar sorma. Yeni dosyanın sütunlarını kontrol et; etiket ve sütun önerisini gerçek soru aracıyla bir kez onaylat. Örnekleri yalnızca kısa özetli bir tabloda göster; yine gerçek soru aracıyla onayımı alıp tüm dosyayı tamamla.','Etiketleri tam orijinal metnin anlamından belirle. Boş kaynakları boş bırak. Kaynak veriyi koruyarak yeni dosya üret. İlerlemeyi kısa planda göster; satır kararlarını sohbete yazma.','Önceki dosyanın sayfası: '+str(meta['sheet'])+'. Başlık satırı: '+str(meta.get('header_row',1))+'. Kapsam: '+str(meta.get('row_scope','all'))+'. Yeni dosyadaki karşılığını kontrol et.']
    if cfg.get('row_filters'):lines.append('Satır seçimi: '+json.dumps(cfg['row_filters'],ensure_ascii=False))
    db=rt.db_connect(jd)
    try:
        for t in cfg['targets']:
            lines+=['',t['name']+':','Amaç: '+t.get('purpose',''),'Kaynak sütunlar: '+', '.join(t['source_column_names']),'Bağlam sütunları: '+(', '.join(t.get('context_column_names',[])) or 'Yok'),'Çıktı sütunu: '+t['output_column'],'Etiket sayısı: '+('Tek' if t['cardinality']=='single' else 'Birden fazla')]
            if t.get('raw_output_column'):lines.append('Detay sütunu: '+t['raw_output_column'])
            if t['label_source']=='freeform':
                lines.append('Yol: Serbest anlamlı etiketler üret, benzer anlamları birleştir; farklı nedenleri aynı sonuca bakarak birleştirme.')
                groups=[r[0] for r in db.execute('SELECT DISTINCT canonical_label FROM consolidation WHERE target_id=? ORDER BY canonical_label',(t['id'],))]
                if groups:lines.append('Önceki dosyada oluşan gruplar (yeni veriye uygunluğunu kontrol et): '+', '.join(groups))
            else:
                lines.append('Yol: Aşağıdaki hazır etiketleri kullan; açıkça kapsam dışı bir anlam varsa bana sor.')
                for lab in t['labels']:
                    lines.append('- '+lab['name']+': '+lab.get('definition',''))
                    for key,title in [('include','Dahil'),('exclude','Hariç')]:
                        if lab.get(key):lines.append('  '+title+': '+'; '.join(lab[key]))
        corrections=db.execute('SELECT COUNT(*) FROM approved_exemplars WHERE explicit_correction=1').fetchone()[0]
    finally:db.close()
    lines+=['','Duyguda kibar teşekkür ile gerçek olumlu sonucu ayır; karışık deneyimi nötr sayma. Puan aralıklarını ancak ayrıca onayladıysam kullan.','Sonuç dosyası ile birlikte güncel yeniden kullanım promptunu da oluştur.']
    out=Path(out);out.write_text('\n'.join(lines),encoding='utf-8')
    return {'path':str(out.resolve()),'correction_guidance_needed':bool(corrections),'instruction':'Attach automatically with output; no extra permission question. If corrections exist, add only their general, non-identifying decision rule to this prompt; never copy original customer text.'}
