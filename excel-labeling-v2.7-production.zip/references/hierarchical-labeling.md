# Hierarchical Labeling: Detail + Group

## When to use
Use hierarchical output when the business needs both:
- an actionable fine-grained reason/cause; and
- a stable grouped category for reporting.

Typical use: complaints, lost sales, appointment failure reasons, operational incidents, root-cause analysis.

Do not add a hierarchy to simple Sentiment or other targets where it creates no business value.

## Root-cause principle
Answer the approved causal question.

When text contains both cause and outcome, prefer the cause:
- "Support replied after three days, so I closed my account" → detail: **support response delay**, not **account closure**.
- "The fee was too high, so I chose a competitor" → detail: **high fee**, not **competitor choice**.

Use an outcome as the detail only when the text gives no material cause.
Never invent a hidden cause.

## Runtime representation
Use one free-form target:

```json
{
  "name": "Kök Neden",
  "target_type": "root_cause",
  "discovery_strategy": "open_code_then_group",
  "label_source": "freeform",
  "cardinality": "single",
  "source_columns": ["aciklama"],
  "raw_output_column": "Sebep Detay",
  "output_column": "Sebep Grup",
  "taxonomy_quality": {
    "enabled": true,
    "catch_all_label": "Diğer",
    "max_catch_all_pct": 10,
    "max_group_pct": 45,
    "thin_group_pct": 1
  }
}
```

During full labeling the model emits the fine/detail cause. During consolidation each raw label maps to a canonical grouped label.

Export behavior:
- `raw_output_column` receives the fine/detail label.
- `output_column` receives the canonical/group label.

## Grouping rules
- Group by shared cause/process, not shared downstream outcome.
- Preserve genuinely different causes even when they produce the same outcome.
- Merge wording variants/synonyms.
- Keep group names useful to business users.
- Do not bury recurring meaningful causes in catch-all.

## User experience
The user should not watch open-coding batches or mappings.
At setup approval, explain only the business output, for example:

"Kök neden için hem detaylı sebep hem de raporlamaya uygun sebep grubu eklememi öneriyorum."

If the user only wants grouped output, omit `raw_output_column` even if open coding is used internally.
