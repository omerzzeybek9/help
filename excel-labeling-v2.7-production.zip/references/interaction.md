# User Interaction

## Principle
The user should make business decisions, not operate the labeling pipeline.

Use the real `ask_user_question` MCP tool for required decisions/approvals. Never simulate its result in chat.

## Normal gates
Aim for three meaningful gates:
1. **Target selection** — only when the target is not already explicit.
2. **Setup approval** — labels/rules + single/multi recommendation + optional detail/group choice.
3. **Preview approval** — a small challenging sample.

Do not add a question merely because the runtime has an internal field.

## Do not mechanically ask
Avoid separate questions like:
- "Path A/B/C?"
- "Do you want AI discovery?" when the user already supplied/no taxonomy.
- "Single or multi?" when the recommendation is obvious and can be confirmed in setup.
- header/hidden row/output conflict questions when the condition does not exist.

Infer first, then expose the recommendation in setup approval so the user can change it.

## Natural wording
Prefer:
- "Kendi etiketlerinizi kullanacağım" instead of "Path A".
- "Veriden şu kategorileri öneriyorum" instead of "taxonomy induction".
- "Bir yorum birden fazla konu alabilir" instead of "cardinality=multi".
- "Hem detaylı sebep hem raporlama grubu" instead of "hierarchical open coding".

## Preview
Show 5–8 diverse/challenging rows. Include only the source excerpt needed to judge the example, target labels, and a short reason when useful.

If the user corrects a preview label, use `preview-correct`. Corrections are binding exemplars.

## Silent phase
After preview approval, do not narrate:
- row decisions;
- batches;
- queue counts;
- JSON;
- audit rows;
- repair scope;
- rules/hashes/leases.

If the user asks for progress, answer from compact `status` counters without replaying rows.

## Final response
Keep it short:
- completed;
- rows processed;
- output columns;
- relevant REVIEW count if nonzero;
- output file.
