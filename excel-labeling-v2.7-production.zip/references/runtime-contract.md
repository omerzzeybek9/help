# Runtime Contract

## Contents
- Phase order
- Configuration schema
- Setup and preview
- Production loop
- Free-form consolidation
- Audit and repair
- Validation/export
- Provenance rules

## Phase order
The runtime protocol is **2.7**.

State progression:
`SETUP_APPROVED → PREVIEWING → PREVIEW_APPROVED → LABELING → [CONSOLIDATING] → AUDITING → AUDIT_PASSED → VALIDATED → EXPORTED`

Failed audit enters `AUDIT_FAILED` / `REPAIRING`, then returns to labeling and requires a fresh audit.

Use:
```bash
python scripts/excel_labeling.py contract
```
when exact syntax is uncertain. Do not ask the user to debug runtime syntax.

## Configuration schema
A job config contains `targets`.

Fixed/topic example:
```json
{
  "targets": [{
    "name": "Konu",
    "target_type": "topic",
    "purpose": "Kaydın ana konusunu belirle",
    "source_columns": ["yorum"],
    "context_columns": ["kanal"],
    "output_column": "Konu",
    "label_source": "proposed",
    "discovery_strategy": "taxonomy_discovery",
    "cardinality": "multi",
    "labels": [
      {"name":"Kart İşlemleri","definition":"Kart kullanım ve işlem sorunları","include":[],"exclude":[],"examples":[]}
    ]
  }]
}
```

Hierarchical root-cause example:
```json
{
  "targets": [{
    "name": "Kök Neden",
    "target_type": "root_cause",
    "purpose": "Belirtilen sonucun temel sebebini çıkar",
    "source_columns": ["aciklama"],
    "context_columns": [],
    "raw_output_column": "Sebep Detay",
    "output_column": "Sebep Grup",
    "label_source": "freeform",
    "discovery_strategy": "open_code_then_group",
    "cardinality": "single",
    "taxonomy_quality": {
      "enabled": true,
      "catch_all_label": "Diğer",
      "max_catch_all_pct": 10,
      "max_group_pct": 45,
      "thin_group_pct": 1
    }
  }]
}
```

`raw_output_column` is valid only for `freeform` targets. It stores the raw/fine label; `output_column` stores the canonical consolidated label.

Supported `target_type`: `topic`, `sentiment`, `root_cause`, `intent`, `priority`, `risk`, `status`, `custom`.

Supported `discovery_strategy`: `auto`, `fixed`, `taxonomy_discovery`, `open_code_then_group`, `freeform`.


### Optional row filters
Use deterministic row filters when the user explicitly scopes labeling to a subset. Supported operators:
- `equals` / `not_equals`
- `in` / `not_in`
- `empty` / `nonempty`

Example:
```json
"row_filters": [
  {"column":"durum","operator":"equals","value":"Şikayet"}
]
```

Filters are case-insensitive by default; set `case_sensitive:true` only when needed. Multiple filters are ANDed. Rows outside the subset do not enter semantic work and remain unchanged in export.

## Setup and preview
Initialize only after setup approval:
```bash
python scripts/excel_labeling.py init INPUT --config CONFIG.json --job-dir JOB --setup-approval-source ask_user_question
```

Start preview:
```bash
python scripts/excel_labeling.py preview-start --job-dir JOB
python scripts/excel_labeling.py rules --job-dir JOB --mode preview
python scripts/excel_labeling.py preview-next --job-dir JOB
```

Submit the bounded semantic decisions through stdin using exact runtime IDs/hashes.

Persist a user semantic correction without depending on the old lease:
```bash
python scripts/excel_labeling.py preview-correct --job-dir JOB --approval-source ask_user_question --stdin
```

Approve preview:
```bash
python scripts/excel_labeling.py approve-preview --job-dir JOB --approval-source ask_user_question
```

## Production loop
Load rules once:
```bash
python scripts/excel_labeling.py rules --job-dir JOB --mode production
python scripts/excel_labeling.py status --job-dir JOB
```

Then loop:
```bash
python scripts/excel_labeling.py next --job-dir JOB --max-items N
python scripts/excel_labeling.py submit --job-dir JOB --stdin
```

Do not request repeated rules unless context/config changed.
Do not consider labeling complete until `status.labeling_complete=true`.

## Free-form consolidation
```bash
python scripts/excel_labeling.py consolidation-next --job-dir JOB
python scripts/excel_labeling.py consolidation-submit --job-dir JOB --stdin
```

For ordinary free-form targets, consolidation normalizes raw labels to canonical labels.
For `open_code_then_group`, raw label = detail and canonical label = reporting group.

## Audit and repair
```bash
python scripts/excel_labeling.py audit-start --job-dir JOB
python scripts/excel_labeling.py rules --job-dir JOB --mode audit
python scripts/excel_labeling.py audit-next --job-dir JOB
python scripts/excel_labeling.py audit-submit --job-dir JOB --stdin
python scripts/excel_labeling.py audit-finalize --job-dir JOB
```

If audit fails:
```bash
python scripts/excel_labeling.py repair-start --job-dir JOB --mode progressive
python scripts/excel_labeling.py rules --job-dir JOB --mode repair
python scripts/excel_labeling.py repair-next --job-dir JOB
python scripts/excel_labeling.py repair-submit --job-dir JOB --stdin
python scripts/excel_labeling.py repair-finalize --job-dir JOB
```
Then run a fresh audit.

## Validation and export
```bash
python scripts/excel_labeling.py quality-report --job-dir JOB
python scripts/excel_labeling.py validate --job-dir JOB
python scripts/excel_labeling.py export --job-dir JOB --out OUTPUT.xlsx
```

Output conflicts use `--on-conflict error|overwrite|suffix`; the user chooses the business action first.
Advanced workbook override is allowed only after explicit user approval.

## Provenance rules
Every semantic submit must use the work actually returned by runtime and copy exact:
- `unit_id`
- `bundle_id`
- `lease_id`
- `source_hash`

A row bundle is atomic across targets.
Never invent/reuse IDs across work items.
Never generate semantic decisions by scripts, keyword rules, fuzzy matching, or unseen-row pattern reuse.
